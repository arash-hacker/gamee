var _0x5e86 = [
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x76\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x76\x65\x72\x5F\x74\x6F\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6F\x72\x5F\x62\x75\x6C\x6C\x65\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6F\x72\x5F\x70\x61\x72\x74\x69\x63\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6F\x72\x5F\x62\x75\x6C\x6C\x65\x74\x5F\x65\x6E\x65\x6D\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6F\x72\x5F\x70\x61\x72\x74\x69\x63\x6C\x65\x5F\x65\x6E\x65\x6D\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x6F\x6F\x74\x69\x6E\x67\x5F\x65\x6E\x65\x72\x67\x79\x5F\x70\x61\x6E\x64\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x61\x72\x5F\x66\x69\x6C\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x61\x72\x5F\x66\x72\x61\x6D\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x70\x61\x72\x74\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x70\x61\x72\x74\x5F\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x70\x61\x72\x74\x5F\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x6C\x61\x62\x65\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x6C\x61\x62\x65\x6C\x5F\x73\x68\x61\x64\x6F\x77\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x61\x6C\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x61\x6C\x6C\x5F\x73\x68\x61\x64\x6F\x77\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x61\x6C\x6C\x5F\x66\x72\x61\x6D\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x61\x72\x65\x6C\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x70\x6C\x61\x73\x68\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x70\x6C\x61\x73\x68\x5F\x65\x6E\x65\x6D\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x6C\x65\x66\x74\x5F\x62\x6F\x74\x74\x6F\x6D\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x72\x69\x67\x68\x74\x5F\x62\x6F\x74\x74\x6F\x6D\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x6E\x69\x6D\x61\x63\x65\x5F\x70\x6C\x61\x79\x65\x72\x5F\x65\x78\x70\x6F\x72\x74\x5F\x33\x2F\x73\x6B\x65\x6C\x65\x74\x6F\x6E\x2E\x6A\x73\x6F\x6E",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x6E\x69\x6D\x61\x63\x65\x5F\x6F\x70\x6F\x6E\x65\x6E\x74\x5F\x65\x78\x70\x6F\x72\x74\x2F\x73\x6B\x65\x6C\x65\x74\x6F\x6E\x2E\x6A\x73\x6F\x6E",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x73\x73\x5F\x31\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x2F\x73\x6B\x65\x6C\x65\x74\x6F\x6E\x2E\x6A\x73\x6F\x6E",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x69\x65\x6C\x64\x5F\x65\x78\x70\x6F\x72\x74\x2F\x73\x6B\x65\x6C\x65\x74\x6F\x6E\x2E\x6A\x73\x6F\x6E",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x69\x65\x6C\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x78\x74\x72\x61\x5F\x70\x61\x6E\x64\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x64\x6F\x77\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6C\x65\x63\x74\x69\x62\x6C\x65\x5F\x74\x61\x72\x67\x65\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x30\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x34\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x35\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x36\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x37\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x38\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x39\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x31\x30\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x31\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x61\x62\x6C\x65\x5F\x66\x69\x72\x73\x74\x5F\x70\x6C\x61\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x64\x6F\x77\x5F\x73\x65\x63\x6F\x6E\x64\x5F\x70\x6C\x61\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x69\x65\x6C\x64\x5F\x6F\x76\x65\x72\x6C\x61\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6E\x75\x6D\x62\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x6D\x6F\x6A\x69\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x6D\x6F\x6A\x69\x5F\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x72\x72\x6F\x77\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x61\x72\x67\x65\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x31\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x62\x65\x6C\x73\x2F\x6C\x61\x62\x65\x6C\x5F\x31\x33\x2E\x70\x6E\x67",
  "\x6C\x6F\x6F\x70",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x33\x5F\x6C\x6F\x6F\x70\x2E\x6D\x70\x33",
  "\x6C\x6F\x6F\x70\x5F\x62\x6F\x73\x73",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x37\x5F\x6C\x6F\x6F\x70\x5F\x62\x6F\x73\x73\x2E\x6D\x70\x33",
  "\x72\x6F\x6C\x6C",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x72\x6F\x6C\x6C\x2E\x6D\x70\x33",
  "\x73\x68\x6F\x74",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x73\x68\x6F\x74\x2E\x6D\x70\x33",
  "\x73\x70\x6C\x61\x73\x68",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x73\x70\x6C\x61\x73\x68\x2E\x6D\x70\x33",
  "\x63\x6F\x6C\x6C\x65\x63\x74",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x63\x6F\x6C\x6C\x65\x63\x74\x30\x2E\x6D\x70\x33",
  "\x64\x65\x61\x74\x68",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x64\x65\x61\x74\x68\x2E\x6D\x70\x33",
  "\x66\x75\x6E\x6E\x79",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x66\x75\x6E\x6E\x79\x2E\x6D\x70\x33",
  "\x68\x61\x68\x61",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x68\x61\x68\x61\x2E\x6D\x70\x33",
  "\x67\x6F\x6F\x64\x6C\x75\x63\x6B",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x67\x6F\x6F\x64\x6C\x75\x63\x6B\x2E\x6D\x70\x33",
  "\x69\x6D\x70\x61\x63\x74",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x69\x6D\x70\x61\x63\x74\x2E\x6D\x70\x33",
  "\x6B\x69\x73\x73",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x6B\x69\x73\x73\x2E\x6D\x70\x33",
  "\x6F\x75\x63\x68",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x6F\x75\x63\x68\x2E\x6D\x70\x33",
  "\x74\x69\x64\x6C\x69\x64\x61\x70",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x74\x69\x64\x6C\x69\x64\x61\x70\x2E\x6D\x70\x33",
  "\x62\x69\x74\x6D\x61\x70\x73",
  "\x61\x64\x64",
  "\x6C\x6F\x61\x64\x65\x72",
  "\x70\x72\x6F\x67\x72\x65\x73\x73",
  "\x6F\x6E",
  "\x6C\x6F\x61\x64",
  "\x70\x61\x75\x73\x65",
  "\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72",
  "\x65\x6D\x69\x74\x74\x65\x72",
  "\x72\x65\x73\x75\x6D\x65",
  "\x6D\x75\x74\x65",
  "\x75\x6E\x6D\x75\x74\x65",
  "\x46\x75\x6C\x6C\x53\x63\x72\x65\x65\x6E",
  "\x73\x61\x76\x65\x53\x74\x61\x74\x65",
  "\x73\x6F\x75\x6E\x64",
  "\x70\x61\x72\x73\x65",
  "\x67\x61\x6D\x65\x49\x6E\x69\x74",
  "\x74\x75\x74\x6F\x72\x69\x61\x6C",
  "\x73\x74\x61\x72\x74",
  "\x67\x61\x6D\x65\x52\x65\x61\x64\x79",
  "\x76\x69\x65\x77",
  "\x69\x6E\x6E\x65\x72\x57\x69\x64\x74\x68",
  "\x69\x6E\x6E\x65\x72\x48\x65\x69\x67\x68\x74",
  "\x6D\x61\x72\x67\x69\x6E\x4C\x65\x66\x74",
  "\x73\x74\x79\x6C\x65",
  "\x70\x78",
  "\x77\x69\x64\x74\x68",
  "\x68\x65\x69\x67\x68\x74",
  "\x64\x65\x76\x69\x63\x65\x50\x69\x78\x65\x6C\x52\x61\x74\x69\x6F",
  "\x69\x73\x57\x65\x62\x47\x4C\x53\x75\x70\x70\x6F\x72\x74\x65\x64",
  "\x75\x74\x69\x6C\x73",
  "\x61\x70\x70\x65\x6E\x64\x43\x68\x69\x6C\x64",
  "\x67\x6D\x34\x68\x74\x6D\x6C\x35\x5F\x64\x69\x76\x5F\x69\x64",
  "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64",
  "\x61\x75\x74\x6F\x53\x74\x61\x72\x74",
  "\x74\x69\x63\x6B\x65\x72",
  "\x73\x74\x6F\x70",
  "\x73\x70\x72\x69\x74\x65\x73",
  "\x61\x64\x64\x43\x68\x69\x6C\x64",
  "\x73\x74\x61\x67\x65",
  "\x62\x67",
  "\x66\x72\x6F\x6D\x46\x72\x61\x6D\x65",
  "\x53\x70\x72\x69\x74\x65",
  "\x61\x64\x64\x43\x68\x69\x6C\x64\x5A",
  "\x64\x6F\x6F\x72\x5F\x6C\x65\x66\x74",
  "\x78",
  "\x79",
  "\x64\x6F\x6F\x72\x5F\x72\x69\x67\x68\x74",
  "\x63\x6F\x76\x65\x72\x5F\x74\x6F\x70",
  "\x62\x65\x67\x69\x6E\x46\x69\x6C\x6C",
  "\x64\x72\x61\x77\x52\x65\x63\x74",
  "\x6D\x61\x73\x6B",
  "\x64\x6F\x6F\x72\x5F\x6C\x65\x66\x74\x5F\x62\x6F\x74\x74\x6F\x6D",
  "\x64\x6F\x6F\x72\x5F\x72\x69\x67\x68\x74\x5F\x62\x6F\x74\x74\x6F\x6D",
  "\x63\x6F\x76\x65\x72",
  "\x76\x69\x73\x69\x62\x6C\x65",
  "\x73\x68\x61\x64\x6F\x77\x5F\x73\x65\x63\x6F\x6E\x64\x5F\x70\x6C\x61\x6E",
  "\x73\x65\x74",
  "\x73\x63\x61\x6C\x65",
  "\x63\x61\x62\x6C\x65\x5F\x66\x69\x72\x73\x74\x5F\x70\x6C\x61\x6E",
  "\x65\x6D\x6F\x6A\x69\x5F\x31",
  "\x61\x6E\x63\x68\x6F\x72",
  "\x70\x75\x73\x68",
  "\x72\x65\x6E\x64\x65\x72",
  "\x70\x6F\x73\x69\x74\x69\x6F\x6E",
  "\x64\x6F\x6D\x45\x6C\x65\x6D\x65\x6E\x74",
  "\x61\x62\x73\x6F\x6C\x75\x74\x65",
  "\x74\x6F\x70",
  "\x30\x70\x78",
  "\x69\x6E\x74\x65\x72\x61\x63\x74\x69\x76\x65",
  "\x70\x6F\x69\x6E\x74\x65\x72\x75\x70",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6D\x6F\x76\x65",
  "\x70\x6F\x69\x6E\x74\x65\x72\x64\x6F\x77\x6E",
  "\x6B\x65\x79\x64\x6F\x77\x6E",
  "\x6B\x65\x79\x75\x70",
  "\x63\x61\x63\x68\x65\x41\x73\x42\x69\x74\x6D\x61\x70",
  "\x73\x68\x69\x66\x74",
  "\x63\x68\x69\x6C\x64\x72\x65\x6E",
  "\x6C\x65\x6E\x67\x74\x68",
  "\x70\x6C\x61\x79",
  "\x67\x61\x6D\x65\x4F\x76\x65\x72",
  "\x74\x61\x72\x67\x65\x74",
  "\x73\x70\x69\x6E\x65\x44\x61\x74\x61",
  "\x73\x70\x69\x6E\x65\x5F\x70\x6C\x61\x79\x65\x72\x5F\x64\x61\x74\x61",
  "\x72\x65\x73\x6F\x75\x72\x63\x65\x73",
  "\x73\x70\x69\x6E\x65",
  "\x62\x75\x74\x74\x6F\x6E\x4D\x6F\x64\x65",
  "\x6C\x69\x76\x65\x73",
  "\x68\x69\x74\x43\x69\x72\x63\x6C\x65",
  "\x68\x69\x74\x42\x6F\x78",
  "\x62\x72\x65\x61\x74\x68\x69\x6E\x67",
  "\x73\x65\x74\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x73\x74\x61\x74\x65",
  "\x73\x6F\x6C\x69\x64",
  "\x74\x69\x6D\x65\x54\x6F\x4D\x6F\x76\x65",
  "\x72\x61\x6E\x64\x6F\x6D",
  "\x68\x69\x64\x65",
  "\x61\x63\x74\x69\x76\x65",
  "\x61\x72\x72\x6F\x77",
  "\x62\x6F\x77",
  "\x61\x64\x64\x54\x77\x65\x65\x6E",
  "\x6C\x61\x62\x65\x6C\x5F\x31\x33",
  "\x72\x6F\x74\x61\x74\x69\x6F\x6E",
  "\x50\x49",
  "\x72\x6F\x75\x6E\x64",
  "\x73\x70\x6C\x69\x63\x65",
  "\x66\x6C\x6F\x6F\x72",
  "\x73\x70\x69\x6E\x65\x5F\x65\x6E\x65\x6D\x79\x5F\x64\x61\x74\x61",
  "\x63\x6F\x6F\x72\x64",
  "\x64\x65\x6C\x61\x79",
  "\x7A\x4F\x66\x66\x73\x65\x74",
  "\x6D\x6F\x76\x65\x53\x70\x65\x65\x64",
  "\x73\x65\x74\x54\x6F\x53\x65\x74\x75\x70\x50\x6F\x73\x65",
  "\x73\x6B\x65\x6C\x65\x74\x6F\x6E",
  "\x75\x70\x64\x61\x74\x65\x53\x63\x6F\x72\x65",
  "\x73\x74\x72\x69\x6E\x67\x69\x66\x79",
  "\x67\x61\x6D\x65\x53\x61\x76\x65",
  "\x62\x65\x67\x69\x6E",
  "\x75\x70\x64\x61\x74\x65",
  "\x73\x6C\x69\x63\x65",
  "\x73\x68\x69\x65\x6C\x64",
  "\x6B\x69\x6E\x65\x74\x69\x63\x58",
  "\x7A",
  "\x61\x7A",
  "\x73\x70\x65\x65\x64",
  "\x7A\x4F\x72\x64\x65\x72",
  "\x73\x68\x69\x6E\x65",
  "\x72\x65\x6D\x6F\x76\x65\x43\x68\x69\x6C\x64",
  "\x70\x61\x72\x65\x6E\x74",
  "\x73\x68\x69\x65\x6C\x64\x5F\x64\x6F\x77\x6E",
  "\x74\x65\x78\x74\x75\x72\x65",
  "\x65\x6D\x6F\x6A\x69\x5F\x32",
  "\x54\x65\x78\x74\x75\x72\x65\x43\x61\x63\x68\x65",
  "\x70\x61\x6E\x64\x61\x5F\x64\x6F\x77\x6E\x5F\x62\x61\x63\x6B\x5F\x32",
  "\x6C\x69\x6E\x65\x61\x72",
  "\x64\x65\x73\x74\x72\x6F\x79",
  "\x70\x65\x72\x63\x65\x6E\x74",
  "\x69\x6E\x64\x65\x78\x4F\x66",
  "\x70\x61\x6E\x64\x61\x5F\x64\x6F\x77\x6E\x5F\x62\x61\x63\x6B\x5F\x31",
  "\x62\x72\x65\x61\x74\x68\x69\x6E\x67\x32",
  "\x61\x64\x64\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x74\x79\x70\x65",
  "\x73\x6F\x75\x72\x63\x65",
  "\x65\x61\x73\x65\x4F\x75\x74\x51\x75\x61\x64",
  "\x65\x78\x74\x72\x61\x63\x74",
  "\x65\x78\x70\x69\x72\x61\x74\x69\x6F\x6E",
  "\x61\x6C\x70\x68\x61",
  "\x65\x6A\x65\x63\x74\x65\x64",
  "\x65\x6A\x65\x63\x74",
  "\x62\x6F\x73\x73",
  "\x61\x62\x73",
  "\x6C\x65\x66\x74\x72\x69\x67\x68\x74\x5F\x77\x61\x6C\x6B",
  "\x6D\x61\x78",
  "\x6A\x75\x6D\x70",
  "\x69\x6E\x4A\x75\x6D\x70",
  "\x73\x68\x6F\x74\x73",
  "\x6D\x69\x6E",
  "\x69\x6E\x4D\x6F\x76\x65",
  "\x73\x68\x6F\x6F\x74\x69\x6E\x67\x5F\x72\x69\x67\x68\x74",
  "\x73\x68\x6F\x6F\x74\x69\x6E\x67\x5F\x6C\x65\x66\x74",
  "\x64\x69\x72\x65\x63\x74\x69\x6F\x6E\x73",
  "\x73\x70\x61\x63\x65\x73",
  "\x6C\x65\x66\x74\x5F\x77\x61\x6C\x6B\x5F\x68\x61\x74",
  "\x6C\x65\x66\x74\x5F\x77\x61\x6C\x6B",
  "\x68\x69\x74",
  "\x70\x61\x6E\x64\x61\x5F\x64\x6F\x77\x6E\x5F\x32",
  "\x70\x61\x6E\x64\x61\x5F\x64\x6F\x77\x6E\x5F\x31",
  "\x73\x6F\x72\x74\x43\x68\x69\x6C\x64\x72\x65\x6E",
  "\x65\x6E\x64",
  "\x65\x78\x74\x72\x61\x5F\x70\x61\x6E\x64\x61",
  "\x73\x70\x69\x6E\x65\x5F\x73\x68\x69\x65\x6C\x64\x5F\x64\x61\x74\x61",
  "\x6B\x69\x6E\x65\x74\x69\x63\x59",
  "\x73\x68\x69\x65\x6C\x64\x5F\x75\x70",
  "\x72\x6F\x74\x61\x74\x65",
  "\x65\x61\x73\x65\x4F\x75\x74\x45\x6C\x61\x73\x74\x69\x63",
  "\x73\x68\x69\x65\x6C\x64\x5F\x6F\x76\x65\x72\x6C\x61\x79",
  "\x62\x6C\x65\x6E\x64\x4D\x6F\x64\x65",
  "\x4F\x56\x45\x52\x4C\x41\x59",
  "\x42\x4C\x45\x4E\x44\x5F\x4D\x4F\x44\x45\x53",
  "\x73\x68\x6F\x6F\x74\x69\x6E\x67",
  "\x73\x68\x6F\x6F\x74\x69\x6E\x67\x32",
  "\x6C\x61\x62\x65\x6C\x5F",
  "\x6E\x75\x6D\x62\x65\x72",
  "\x62\x6F\x73\x73\x5F\x6C\x61\x62\x65\x6C",
  "\x73\x70\x69\x6E\x65\x5F\x62\x6F\x73\x73\x5F\x64\x61\x74\x61",
  "\x66\x72\x6F\x6E\x74\x5F\x77\x61\x6C\x6B",
  "\x61\x74\x61\x6E\x32",
  "\x63\x6F\x73",
  "\x73\x69\x6E",
  "\x62\x75\x6C\x6C\x65\x74\x5F\x65\x6E\x65\x6D\x79",
  "\x63\x6F\x6C\x6F\x72\x5F\x65\x6E\x65\x6D\x79",
  "\x63\x6F\x6C\x6F\x72",
  "\x73\x74\x61\x72\x74\x53\x70\x65\x65\x64",
  "\x61\x6E\x67\x6C\x65",
  "\x73\x74\x61\x72\x74\x41\x6C\x70\x68\x61",
  "\x6C\x69\x66\x65\x54\x69\x6D\x65",
  "\x65\x6E\x64\x41\x6C\x70\x68\x61",
  "\x73\x74\x61\x72\x74\x53\x69\x7A\x65",
  "\x65\x6E\x64\x53\x69\x7A\x65",
  "\x61\x63\x63\x65\x6C\x65\x72\x61\x74\x69\x6F\x6E",
  "\x69\x6E\x69\x74",
  "\x73\x70\x6C\x61\x73\x68\x5F\x65\x6E\x65\x6D\x79",
  "\x73\x74\x61\x72\x74\x50\x6F\x69\x6E\x74",
  "\x67\x6C\x6F\x62\x61\x6C",
  "\x64\x61\x74\x61",
  "\x63\x65\x69\x6C",
  "\x6B\x65\x79\x43\x6F\x64\x65",
  "\x61\x6E\x69\x6D\x69\x64",
  "\x72\x65\x6D\x6F\x76\x65",
  "\x70\x6F\x77",
  "\x73\x71\x72\x74",
  "\x61\x72\x72\x69\x76\x61\x6C\x4F\x72\x64\x65\x72",
  "\x63\x61\x6C\x6C",
  "\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72",
  "\x6F\x6C\x64\x5A\x4F\x72\x64\x65\x72",
  "\x73\x6F\x72\x74",
  "\x70\x72\x6F\x74\x6F\x74\x79\x70\x65",
  "\x63\x72\x65\x61\x74\x65",
  "\x5F\x70\x61\x72\x65\x6E\x74\x45\x6D\x69\x74\x74\x65\x72",
  "\x65\x6E\x64\x53\x70\x65\x65\x64",
  "\x61\x6E\x67\x75\x6C\x61\x72\x53\x70\x65\x65\x64",
  "\x73\x74\x61\x72\x74\x43\x6F\x6C\x6F\x72",
  "\x5F\x65\x6E\x64\x41\x6C\x70\x68\x61",
  "\x5F\x65\x6E\x64\x53\x69\x7A\x65",
  "\x5F\x65\x6E\x64\x43\x6F\x6C\x6F\x72",
  "\x5F\x61\x63\x63\x65\x6C\x65\x72\x61\x74\x69\x6F\x6E",
  "\x5F\x63\x6F\x6C\x6F\x72\x54\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x5F\x73\x70\x65\x65\x64\x54\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x5F\x73\x69\x7A\x65\x54\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x5F\x61\x6C\x70\x68\x61\x54\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x5F\x65\x6C\x61\x70\x73\x65\x64\x54\x69\x6D\x65",
  "\x5F\x65\x61\x73\x65",
  "\x5F\x61\x6C\x70\x68\x61",
  "\x5F\x73\x69\x7A\x65",
  "\x5F\x76\x65\x6C\x6F\x63\x69\x74\x79",
  "\x5F\x72\x6F\x74\x61\x74\x69\x6F\x6E",
  "\x72\x65\x73\x65\x74\x50\x72\x6F\x70\x73",
  "\x6B\x69\x6C\x6C",
  "\x72",
  "\x67",
  "\x62",
  "\x5F\x74\x69\x6E\x74",
  "\x61\x70\x70\x6C\x79",
  "\x74\x69\x6E\x74",
  "\x30\x78\x46\x46\x46\x46\x46\x46",
  "\x64\x65\x66\x69\x6E\x65\x50\x72\x6F\x70\x65\x72\x74\x69\x65\x73",
  "\x50\x61\x72\x74\x69\x63\x6C\x65",
  "\x73\x68\x61\x64\x6F\x77",
  "\x69\x63\x6F\x6E",
  "\x63\x6F\x6C\x6C\x65\x63\x74\x69\x62\x6C\x65\x5F\x74\x61\x72\x67\x65\x74",
  "\x5F\x7A",
  "\x64\x65\x66\x69\x6E\x65\x50\x72\x6F\x70\x65\x72\x74\x79",
  "\x77\x61\x6C\x6C\x5F\x66\x72\x61\x6D\x65",
  "\x77\x61\x6C\x6C\x5F\x73\x68\x61\x64\x6F\x77",
  "\x66\x69\x6C\x6C",
  "\x77\x61\x6C\x6C",
  "\x5F\x76\x61\x6C\x75\x65",
  "\x73\x65\x74\x50\x65\x72\x63\x65\x6E\x74",
  "\x72\x65\x64\x72\x61\x77\x4D\x61\x73\x6B",
  "\x63\x6C\x65\x61\x72",
  "\x65\x6E\x64\x46\x69\x6C\x6C",
  "\x66\x72\x61\x6D\x65",
  "\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x66\x72\x61\x6D\x65",
  "\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x66\x69\x6C\x6C",
  "\x68\x65\x61\x64",
  "\x62\x6F\x73\x73\x5F\x62\x61\x72\x5F\x68\x65\x61\x64",
  "\x62\x61\x72\x5F\x66\x72\x61\x6D\x65",
  "\x62\x61\x72\x5F\x66\x69\x6C\x6C",
  "\x70\x6F\x77\x65\x72\x5F\x63\x69\x72\x63\x6C\x65",
  "\x6D\x6F\x76\x65\x54\x6F",
  "\x61\x72\x63",
  "\x62\x75\x6C\x6C\x65\x74",
  "\x75\x73\x65\x20\x73\x74\x72\x69\x63\x74",
  "\x74\x6D\x70",
  "\x72\x75\x6E\x6E\x69\x6E\x67",
  "\x69\x73\x4F\x76\x65\x72",
  "\x69\x6E\x44\x6F\x77\x6E",
  "\x70\x75\x73\x68\x61\x62\x6C\x65",
  "\x70\x75\x73\x68\x65\x64",
  "\x74\x65\x78\x74\x75\x72\x65\x55\x70",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6F\x75\x74",
  "\x6F\x6E\x4F\x75\x74",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6F\x76\x65\x72",
  "\x6F\x6E\x4F\x76\x65\x72",
  "\x70\x6F\x69\x6E\x74\x65\x72\x75\x70\x6F\x75\x74\x73\x69\x64\x65",
  "\x6F\x6E\x55\x70",
  "\x6F\x6E\x44\x6F\x77\x6E",
  "\x69\x73\x64\x6F\x77\x6E",
  "\x75\x70",
  "\x65\x6D\x69\x74",
  "\x74\x65\x78\x74\x75\x72\x65\x44\x6F\x77\x6E",
  "\x63\x6C\x69\x63\x6B",
  "\x74\x65\x78\x74\x75\x72\x65\x4F\x76\x65\x72",
  "\x72\x65\x6C\x65\x61\x73\x65",
  "\x73\x65\x74\x45\x6E\x61\x62\x6C\x65",
  "\x74\x65\x78\x74\x75\x72\x65\x44\x69\x73\x61\x62\x6C\x65\x64",
  "\x66\x69\x6E\x69\x73\x68",
  "\x74\x77\x65\x65\x6E\x73",
  "\x5F\x74\x61\x72\x67\x65\x74",
  "\x72\x65\x73\x74\x61\x72\x74",
  "\x61\x64\x64\x46\x72\x61\x6D\x65\x54\x77\x65\x65\x6E",
  "\x54\x77\x65\x65\x6E",
  "\x5F\x70\x72\x6D\x73",
  "\x5F\x70\x72\x6F\x70\x73\x51\x75\x65\x75\x65",
  "\x5F\x70\x72\x6F\x70\x73\x53\x74\x61\x72\x74",
  "\x5F\x70\x72\x6F\x70\x73\x45\x6E\x64",
  "\x5F\x72\x75\x6E\x6E\x69\x6E\x67",
  "\x5F\x65\x6C\x61\x70\x73\x65\x64",
  "\x64\x65\x66",
  "\x73\x68\x61\x72\x65\x64",
  "\x5F\x65\x6C\x61\x70\x73\x65",
  "\x6F\x6E\x43\x6F\x6D\x70\x6C\x65\x74\x65",
  "\x6F\x6E\x53\x74\x61\x72\x74",
  "\x74\x69\x6D\x65",
  "\x74\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x74\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E\x73",
  "\x63\x6F\x6E\x73\x74\x72\x75\x63\x74\x6F\x72",
  "\x6F\x6E\x55\x70\x64\x61\x74\x65",
  "\x61\x73\x69\x6E",
  "\x65\x61\x73\x65\x4F\x75\x74\x42\x6F\x75\x6E\x63\x65",
  "\x65\x61\x73\x65\x49\x6E\x42\x6F\x75\x6E\x63\x65",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x73",
  "\x5F\x6C\x6F\x6F\x70",
  "\x5F\x66\x70\x73",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x5F\x70\x6C\x61\x79\x6C\x69\x73\x74",
  "\x63\x6F\x6E\x63\x61\x74",
  "\x72\x65\x76\x65\x72\x73\x65",
  "\x70\x6F\x70",
  "\x61\x64\x64\x4D\x75\x6C\x74\x69\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x4E\x61\x6D\x65",
  "\x67\x65\x74\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x73\x74\x6F\x70\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x61\x64\x64\x54\x6F\x50\x6C\x61\x79\x6C\x69\x73\x74",
  "\x63\x6C\x65\x61\x72\x50\x6C\x61\x79\x6C\x69\x73\x74",
  "\x67\x6F\x74\x6F\x4E\x65\x78\x74",
  "\x6E\x61\x6D\x65",
  "\x6C\x6F\x6F\x70\x73",
  "\x66\x70\x73",
  "\x72\x65\x73\x65\x74",
  "\x50\x61\x72\x73\x65\x54\x69\x6C\x65",
  "\x74\x65\x78\x74\x75\x72\x65\x73",
  "\x66\x72\x61\x6D\x65\x73",
  "\x5F",
  "\x66\x72\x61\x6D\x65\x57\x69\x64\x74\x68",
  "\x66\x72\x61\x6D\x65\x48\x65\x69\x67\x68\x74",
  "\x62\x61\x73\x65\x54\x65\x78\x74\x75\x72\x65",
  "\x63\x6C\x6F\x6E\x65",
  "\x54\x6F\x52\x47\x42",
  "\x63\x68\x61\x72\x41\x74",
  "\x23",
  "\x73\x75\x62\x73\x74\x72",
  "\x30\x78",
  "\x54\x6F\x48\x65\x78",
  "\x44\x65\x63\x54\x6F\x48\x65\x78",
];
var src = {
  bitmaps: {
    bg: _0x5e86[0],
    cover: _0x5e86[1],
    cover_top: _0x5e86[2],
    bullet: _0x5e86[3],
    color: _0x5e86[4],
    bullet_enemy: _0x5e86[5],
    color_enemy: _0x5e86[6],
    power_circle: _0x5e86[7],
    bar_fill: _0x5e86[8],
    bar_frame: _0x5e86[9],
    boss_bar_head: _0x5e86[10],
    boss_bar_fill: _0x5e86[11],
    boss_bar_frame: _0x5e86[12],
    boss_label: _0x5e86[13],
    boss_label_shadow: _0x5e86[14],
    wall: _0x5e86[15],
    wall_shadow: _0x5e86[16],
    wall_frame: _0x5e86[17],
    barell: _0x5e86[18],
    splash: _0x5e86[19],
    splash_enemy: _0x5e86[20],
    door_left: _0x5e86[21],
    door_right: _0x5e86[22],
    door_left_bottom: _0x5e86[23],
    door_right_bottom: _0x5e86[24],
    spine_player_data: _0x5e86[25],
    spine_enemy_data: _0x5e86[26],
    spine_boss_data: _0x5e86[27],
    spine_shield_data: _0x5e86[28],
    shield: _0x5e86[29],
    extra_panda: _0x5e86[30],
    shadow: _0x5e86[31],
    collectible_target: _0x5e86[32],
    label_0: _0x5e86[33],
    label_1: _0x5e86[34],
    label_2: _0x5e86[35],
    label_3: _0x5e86[36],
    label_4: _0x5e86[37],
    label_5: _0x5e86[38],
    label_6: _0x5e86[39],
    label_7: _0x5e86[40],
    label_8: _0x5e86[41],
    label_9: _0x5e86[42],
    label_10: _0x5e86[43],
    label_11: _0x5e86[44],
    cable_first_plan: _0x5e86[45],
    shadow_second_plan: _0x5e86[46],
    shield_overlay: _0x5e86[47],
    number: _0x5e86[48],
    emoji_1: _0x5e86[49],
    emoji_2: _0x5e86[50],
    arrow: _0x5e86[51],
    target: _0x5e86[52],
    label_12: _0x5e86[53],
    label_13: _0x5e86[54],
  },
  sprites: {},
};
var game = (function () {
  var _0x5a04x3 = 640;
  var _0x5a04x4 = 1137;
  var _0x5a04x5 = 0;
  var _0x5a04x6 = {
    init: function () {
      _0x5a04x3f();
    },
    test: function (_0x5a04x7, _0x5a04x8) {
      _0x5a04xa2();
    },
    mute: function () {},
    unmute: function () {},
    pause: function () {},
    resume: function () {},
    restart: function () {
      _0x5a04x64();
    },
  };
  var _0x5a04x9 = { tutorial: true };
  var _0x5a04xa;
  var _0x5a04xb = {};
  var _0x5a04xc = {};
  var _0x5a04xd = 0;
  var _0x5a04xe = 0;
  var _0x5a04xf = 0;
  var _0x5a04x10 = 0;
  var _0x5a04x11 = 0;
  var _0x5a04x12 = true;
  var _0x5a04x13 = true;
  var _0x5a04x14 = -1;
  var _0x5a04x15 = 60;
  var _0x5a04x16 = 100;
  var _0x5a04x17 = 900;
  var _0x5a04x18 = 0;
  var _0x5a04x19 = 0;
  var _0x5a04x1a = 0;
  var _0x5a04x1b = 0;
  var _0x5a04x1c = false;
  var _0x5a04x1d = false;
  var _0x5a04x1e;
  var _0x5a04x1f,
    _0x5a04x20,
    _0x5a04x21,
    _0x5a04x22,
    _0x5a04x23,
    _0x5a04x24,
    _0x5a04x25,
    _0x5a04x26,
    _0x5a04x27,
    _0x5a04x28,
    _0x5a04x29,
    _0x5a04x2a,
    _0x5a04x2b;
  var _0x5a04x2c;
  var _0x5a04x2d;
  var _0x5a04x2e;
  var _0x5a04x2f;
  var _0x5a04x30;
  var _0x5a04x31;
  var _0x5a04x32;
  var _0x5a04x33;
  var _0x5a04x34;
  var _0x5a04x35;
  var _0x5a04x36;
  var _0x5a04x37 = true;
  var _0x5a04x38 = false;
  var _0x5a04x39 = true;
  var _0x5a04x3a = false;
  var _0x5a04x3b = true;
  var _0x5a04x3c = false;
  var _0x5a04x3d = false;
  var _0x5a04x3e = 0;
  function _0x5a04x3f() {
    _0x5a04x40();
  }
  function _0x5a04x40() {
    _0x5a04xc[_0x5e86[55]] = new Howl({ src: [_0x5e86[56]] });
    _0x5a04xc[_0x5e86[57]] = new Howl({ src: [_0x5e86[58]] });
    _0x5a04xc[_0x5e86[59]] = new Howl({ src: [_0x5e86[60]] });
    _0x5a04xc[_0x5e86[61]] = new Howl({ src: [_0x5e86[62]] });
    _0x5a04xc[_0x5e86[63]] = new Howl({ src: [_0x5e86[64]] });
    _0x5a04xc[_0x5e86[65]] = new Howl({ src: [_0x5e86[66]] });
    _0x5a04xc[_0x5e86[67]] = new Howl({ src: [_0x5e86[68]] });
    _0x5a04xc[_0x5e86[69]] = new Howl({ src: [_0x5e86[70]] });
    _0x5a04xc[_0x5e86[71]] = new Howl({ src: [_0x5e86[72]] });
    _0x5a04xc[_0x5e86[73]] = new Howl({ src: [_0x5e86[74]] });
    _0x5a04xc[_0x5e86[75]] = new Howl({ src: [_0x5e86[76]] });
    _0x5a04xc[_0x5e86[77]] = new Howl({ src: [_0x5e86[78]] });
    _0x5a04xc[_0x5e86[79]] = new Howl({ src: [_0x5e86[80]] });
    _0x5a04xc[_0x5e86[81]] = new Howl({ src: [_0x5e86[82]] });
    for (var _0x5a04x41 in src[_0x5e86[83]]) {
      PIXI[_0x5e86[85]][_0x5e86[84]](_0x5a04x41, src[_0x5e86[83]][_0x5a04x41]);
    }
    PIXI[_0x5e86[85]][_0x5e86[87]](_0x5e86[86], _0x5a04xd1);
    PIXI[_0x5e86[85]][_0x5e86[88]](_0x5a04xd4);
  }
  function _0x5a04x42() {
    _0x5a04x53();
    _0x5a04x43();
  }
  function _0x5a04x43() {
    gamee[_0x5e86[91]][_0x5e86[90]](_0x5e86[89], function (_0x5a04x44) {
      _0x5a04x4c();
    });
    gamee[_0x5e86[91]][_0x5e86[90]](_0x5e86[92], function (_0x5a04x44) {
      _0x5a04x4b();
    });
    gamee[_0x5e86[91]][_0x5e86[90]](_0x5e86[93], function (_0x5a04x44) {
      _0x5a04x4a();
    });
    gamee[_0x5e86[91]][_0x5e86[90]](_0x5e86[94], function (_0x5a04x44) {
      _0x5a04x49();
    });
    gamee[_0x5e86[99]](_0x5e86[95], {}, [_0x5e86[96]], function (
      _0x5a04x45,
      _0x5a04x46
    ) {
      if (_0x5a04x45 !== null) {
        throw _0x5a04x45;
      }
      if (!_0x5a04x46[_0x5e86[97]]) {
        _0x5a04x4a();
      }
      var _0x5a04x47 = _0x5a04x46[_0x5e86[96]]
        ? JSON[_0x5e86[98]](_0x5a04x46[_0x5e86[96]])
        : {};
      _0x5a04x48(_0x5a04x47);
    });
  }
  function _0x5a04x48(_0x5a04x46) {
    for (var _0x5a04x41 in _0x5a04x46) {
      _0x5a04x9[_0x5a04x41] = _0x5a04x46[_0x5a04x41];
    }
    _0x5a04x12 = _0x5a04x9[_0x5e86[100]];
    gamee[_0x5e86[91]][_0x5e86[90]](_0x5e86[101], function () {
      _0x5a04x64();
    });
    gamee[_0x5e86[102]]();
  }
  function _0x5a04x49() {
    if (_0x5a04x38) {
      _0x5a04x38 = false;
      Howler[_0x5e86[93]](false);
    }
  }
  function _0x5a04x4a() {
    if (!_0x5a04x38) {
      _0x5a04x38 = true;
      Howler[_0x5e86[93]](true);
    }
  }
  function _0x5a04x4b() {
    _0x5a04x66();
  }
  function _0x5a04x4c() {
    _0x5a04x67();
  }
  function _0x5a04x4d() {
    var _0x5a04x4e = _0x5a04xa[_0x5e86[103]];
    var _0x5a04x4f = window[_0x5e86[104]] / _0x5a04x3;
    var _0x5a04x50 = window[_0x5e86[105]] / _0x5a04x4;
    var _0x5a04x51 = 0;
    var _0x5a04x52 = 0;
    if (_0x5a04x4f < _0x5a04x50) {
      _0x5a04x51 = _0x5a04x3 * _0x5a04x4f;
      _0x5a04x52 = _0x5a04x4 * _0x5a04x4f;
      _0x5a04x4e[_0x5e86[107]][_0x5e86[106]] = 0;
    } else {
      _0x5a04x51 = _0x5a04x3 * _0x5a04x50;
      _0x5a04x52 = _0x5a04x4 * _0x5a04x50;
      _0x5a04x4e[_0x5e86[107]][_0x5e86[106]] =
        (window[_0x5e86[104]] - _0x5a04x51) / 2 + _0x5e86[108];
    }
    _0x5a04x4e[_0x5e86[107]][_0x5e86[109]] = _0x5a04x51 + _0x5e86[108];
    _0x5a04x4e[_0x5e86[107]][_0x5e86[110]] = _0x5a04x52 + _0x5e86[108];
  }
  function _0x5a04x53(_0x5a04x54) {
    var _0x5a04x55 = window[_0x5e86[111]];
    var _0x5a04x56 = false;
    if (PIXI[_0x5e86[113]][_0x5e86[112]]() && _0x5a04x55 == 1) {
      _0x5a04x56 = true;
    }
    _0x5a04xa = new PIXI.Application(_0x5a04x3, _0x5a04x4, {
      roundPixels: false,
      resolution: 1,
      antialias: false,
      transparent: true,
    });
    document[_0x5e86[116]](_0x5e86[115])[_0x5e86[114]](_0x5a04xa[_0x5e86[103]]);
    _0x5a04xa[_0x5e86[118]][_0x5e86[117]] = false;
    _0x5a04xa[_0x5e86[118]][_0x5e86[119]]();
    _0x5a04xa[_0x5e86[118]][_0x5e86[84]](_0x5a04x7a);
    for (var _0x5a04x41 in src[_0x5e86[120]]) {
      var _0x5a04x57 = PIXI.ParseTile(src[_0x5e86[120]][_0x5a04x41]);
      _0x5a04xb[_0x5a04x41] = _0x5a04x57;
    }
    _0x5a04x1e = new _0x5a04x11c();
    _0x5a04xa[_0x5e86[122]][_0x5e86[121]](_0x5a04x1e);
    var _0x5a04x58 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[123]);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x58, 0);
    _0x5a04x25 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[127]);
    _0x5a04x25[_0x5e86[128]] = 188;
    _0x5a04x25[_0x5e86[129]] = 25;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x25, 1);
    _0x5a04x26 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[130]);
    _0x5a04x26[_0x5e86[128]] = 324;
    _0x5a04x26[_0x5e86[129]] = 25;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x26, 1);
    var _0x5a04x59 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[131]);
    _0x5a04x59[_0x5e86[129]] = 20;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x59, 2);
    _0x5a04x23 = new PIXI.Container();
    _0x5a04x23[_0x5e86[128]] = 0;
    _0x5a04x23[_0x5e86[129]] = 0;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x23, 0);
    _0x5a04x24 = new PIXI.Container();
    _0x5a04x24[_0x5e86[128]] = 0;
    _0x5a04x24[_0x5e86[129]] = 0;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x24, 0);
    var _0x5a04x5a = new PIXI.Graphics();
    _0x5a04x5a[_0x5e86[132]](0x0000ff);
    _0x5a04x5a[_0x5e86[133]](203, 102, 236, 32);
    _0x5a04x5a[_0x5e86[133]](65, 133, 510, 900);
    _0x5a04x1e[_0x5e86[121]](_0x5a04x5a);
    _0x5a04x24[_0x5e86[134]] = _0x5a04x5a;
    _0x5a04x23[_0x5e86[134]] = _0x5a04x5a;
    _0x5a04x21 = new _0x5a04x138();
    _0x5a04x21[_0x5e86[128]] = 0;
    _0x5a04x21[_0x5e86[129]] = 0;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x21, 1000);
    _0x5a04x20 = new _0x5a04x139();
    _0x5a04x20[_0x5e86[128]] = 200;
    _0x5a04x20[_0x5e86[129]] = 200;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x20, 1);
    _0x5a04x27 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[135]);
    _0x5a04x27[_0x5e86[128]] = 188;
    _0x5a04x27[_0x5e86[129]] = 1016;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x27, 1998);
    _0x5a04x28 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[136]);
    _0x5a04x28[_0x5e86[128]] = 320;
    _0x5a04x28[_0x5e86[129]] = 1016;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x28, 1999);
    var _0x5a04x5b = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[137]);
    _0x5a04x5b[_0x5e86[129]] = 1013;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x5b, 2000);
    _0x5a04x29 = new _0x5a04x137();
    _0x5a04x29[_0x5e86[138]] = false;
    _0x5a04x29[_0x5e86[128]] = 165;
    _0x5a04x29[_0x5e86[129]] = 35;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x29, 2000);
    var _0x5a04x5c = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[139]);
    _0x5a04x5c[_0x5e86[128]] = 640;
    _0x5a04x5c[_0x5e86[129]] = 371;
    _0x5a04x5c[_0x5e86[141]][_0x5e86[140]](-1);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x5c, 1990);
    var _0x5a04x5d = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[139]);
    _0x5a04x5d[_0x5e86[128]] = 0;
    _0x5a04x5d[_0x5e86[129]] = 765;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x5d, 1990);
    var _0x5a04x5e = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[142]);
    _0x5a04x5e[_0x5e86[128]] = -8;
    _0x5a04x5e[_0x5e86[129]] = -37;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x5e, 1991);
    var _0x5a04x5f = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[142]);
    _0x5a04x5f[_0x5e86[128]] = -8;
    _0x5a04x5f[_0x5e86[129]] = 872;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x5f, 1991);
    _0x5a04x2a = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[143]);
    _0x5a04x2a[_0x5e86[128]] = 540;
    _0x5a04x2a[_0x5e86[129]] = 70;
    _0x5a04x2a[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x2a, 2100);
    _0x5a04x2c = [];
    for (var _0x5a04x60 = 0; _0x5a04x60 < 5; _0x5a04x60++) {
      _0x5a04x2c[_0x5e86[145]]([]);
      for (var _0x5a04x61 = 0; _0x5a04x61 < 10; _0x5a04x61++) {
        _0x5a04x2c[_0x5a04x60][_0x5e86[145]](null);
      }
    }
    _0x5a04x62();
    _0x5a04x4d();
    _0x5a04xa[_0x5e86[146]]();
    _0x5a04xc[_0x5e86[55]][_0x5e86[55]](true);
    _0x5a04xc[_0x5e86[57]][_0x5e86[55]](true);
    stats = new Stats();
    stats[_0x5e86[148]][_0x5e86[107]][_0x5e86[147]] = _0x5e86[149];
    stats[_0x5e86[148]][_0x5e86[107]][_0x5e86[150]] = _0x5e86[151];
  }
  function _0x5a04x62() {
    _0x5a04xa[_0x5e86[122]][_0x5e86[152]] = true;
    _0x5a04xa[_0x5e86[122]][_0x5e86[87]](_0x5e86[153], function (_0x5a04x63) {
      _0x5a04xd5(_0x5a04x63);
    });
    _0x5a04xa[_0x5e86[122]][_0x5e86[87]](_0x5e86[154], function (_0x5a04x63) {
      _0x5a04xd7(_0x5a04x63);
    });
    _0x5a04xa[_0x5e86[122]][_0x5e86[87]](_0x5e86[155], function (_0x5a04x63) {
      _0x5a04xd6(_0x5a04x63);
    });
    document[_0x5e86[90]](_0x5e86[156], function (_0x5a04x63) {
      _0x5a04xe4(_0x5a04x63);
    });
    document[_0x5e86[90]](_0x5e86[157], function (_0x5a04x63) {
      _0x5a04xe5(_0x5a04x63);
    });
  }
  function _0x5a04x64() {
    _0x5a04x3a = true;
    _0x5a04x3b = false;
    _0x5a04x10b(_0x5a04x2e);
    _0x5a04x2e = [];
    _0x5a04x10b(_0x5a04x2d);
    _0x5a04x2d = [];
    _0x5a04x10b(_0x5a04x2f);
    _0x5a04x2f = [];
    _0x5a04x30 = _0x5a04x10b(_0x5a04x30);
    _0x5a04x32 = _0x5a04x10b(_0x5a04x32);
    _0x5a04x31 = _0x5a04x10b(_0x5a04x31);
    _0x5a04x33 = _0x5a04x10b(_0x5a04x33);
    _0x5a04x34 = _0x5a04x10b(_0x5a04x34);
    _0x5a04x35 = _0x5a04x10b(_0x5a04x35);
    _0x5a04x10b(_0x5a04x36);
    _0x5a04x36 = [];
    _0x5a04xd = 0;
    _0x5a04x10 = 0;
    _0x5a04x11 = 0;
    _0x5a04x1c = false;
    _0x5a04x18 = 900;
    _0x5a04x19 = 10;
    _0x5a04x1a = 0;
    _0x5a04x17 = 900;
    _0x5a04x1b = 40;
    _0x5a04x15 = 100;
    _0x5a04x16 = 200;
    _0x5a04x23[_0x5e86[158]] = false;
    while (_0x5a04x23[_0x5e86[160]][_0x5e86[161]]) {
      _0x5a04x23[_0x5e86[160]][_0x5e86[159]]();
    }
    if (_0x5a04x12) {
      _0x5a04x69();
    } else {
      _0x5a04x71();
    }
    _0x5a04x66();
    _0x5a04x76();
  }
  function _0x5a04x65() {
    _0x5a04x68();
  }
  function _0x5a04x66() {
    if (!_0x5a04x39) {
      return;
    }
    _0x5a04x39 = false;
    _0x5a04xc[_0x5e86[55]][_0x5e86[162]]();
    _0x5a04xa[_0x5e86[118]][_0x5e86[101]]();
  }
  function _0x5a04x67() {
    if (_0x5a04x39) {
      return;
    }
    _0x5a04x39 = true;
    _0x5a04xc[_0x5e86[55]][_0x5e86[89]]();
    _0x5a04xa[_0x5e86[118]][_0x5e86[119]]();
  }
  function _0x5a04x68() {
    _0x5a04x67();
    gamee[_0x5e86[163]]();
  }
  function _0x5a04x69() {
    var _0x5a04x6a = [250, 400, 310];
    for (var _0x5a04x60 = 0; _0x5a04x60 < 3; _0x5a04x60++) {
      var _0x5a04x6b = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[164]);
      _0x5a04x6b[_0x5e86[144]][_0x5e86[128]] = 0.5;
      _0x5a04x6b[_0x5e86[144]][_0x5e86[129]] = 0.25;
      _0x5a04x6b[_0x5e86[128]] = 170 + _0x5a04x60 * 150;
      _0x5a04x6b[_0x5e86[129]] = _0x5a04x6a[_0x5a04x60];
      _0x5a04x1e[_0x5e86[126]](_0x5a04x6b, _0x5a04x6b[_0x5e86[129]] - 20);
      _0x5a04x34[_0x5e86[145]](_0x5a04x6b);
    }
    var _0x5a04x1f = new PIXI[_0x5e86[168]].Spine(
      PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[166]][_0x5e86[165]]
    );
    _0x5a04x1f[_0x5e86[152]] = true;
    _0x5a04x1f[_0x5e86[169]] = true;
    _0x5a04x1f[_0x5e86[128]] = 160 + 1 * 160;
    _0x5a04x1f[_0x5e86[129]] = 900;
    _0x5a04x1f[_0x5e86[170]] = 2;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x1f, 900);
    _0x5a04x1f[_0x5e86[171]] = { x: 0, y: 0, ratio: 60 };
    _0x5a04x1f[_0x5e86[172]] = {};
    _0x5a04x1f[_0x5e86[172]][_0x5e86[128]] = 2;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[129]] = 21;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[109]] = 58;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[110]] = 50;
    _0x5a04x1f[_0x5e86[87]](_0x5e86[155], function () {
      _0x5a04x94(this);
    });
    _0x5a04x1f[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[173], true);
    _0x5a04x30[_0x5e86[145]](_0x5a04x1f);
    var _0x5a04x6c = new _0x5a04x135();
    _0x5a04x6c[_0x5e86[128]] = 370;
    _0x5a04x6c[_0x5e86[129]] = 280;
    _0x5a04x6c[_0x5e86[176]] = true;
    _0x5a04x6c[_0x5e86[177]] = 220 + Math[_0x5e86[178]]() * 500;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x6c, 255);
    _0x5a04x33[_0x5e86[145]](_0x5a04x6c);
    _0x5a04x2c[3][1] = _0x5a04x6c;
    _0x5a04x2c[4][1] = _0x5a04x6c;
    var _0x5a04x6d = new _0x5a04x135();
    _0x5a04x6d[_0x5e86[128]] = 170;
    _0x5a04x6d[_0x5e86[129]] = 480;
    _0x5a04x6d[_0x5e86[176]] = true;
    _0x5a04x6d[_0x5e86[177]] = 220 + Math[_0x5e86[178]]() * 500;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x6d, 455);
    _0x5a04x33[_0x5e86[145]](_0x5a04x6d);
    _0x5a04x2c[1][3] = _0x5a04x6d;
    _0x5a04x2c[2][3] = _0x5a04x6d;
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x33[_0x5e86[161]];
      _0x5a04x60++
    ) {
      _0x5a04x33[_0x5a04x60][_0x5e86[179]]();
      _0x5a04x33[_0x5a04x60][_0x5e86[180]] = false;
    }
    var _0x5a04x6e = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[181]);
    _0x5a04x6e[_0x5e86[144]][_0x5e86[128]] = 1;
    _0x5a04x6e[_0x5e86[144]][_0x5e86[129]] = 0.5;
    _0x5a04x6e[_0x5e86[128]] = _0x5a04x1f[_0x5e86[128]] - 50;
    _0x5a04x6e[_0x5e86[129]] = _0x5a04x1f[_0x5e86[129]] + 20;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x6e, _0x5a04x6e[_0x5e86[129]]);
    Tweener[_0x5e86[183]](
      _0x5a04x6e,
      { x: _0x5a04x6e[_0x5e86[128]] - 20 },
      { time: 50, loop: -1, transition: _0x5e86[182] }
    );
    _0x5a04x1f[_0x5e86[181]] = _0x5a04x6e;
    _0x5a04x2b = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[184]);
    _0x5a04x2b[_0x5e86[128]] = 820;
    _0x5a04x2b[_0x5e86[129]] = 540;
    _0x5a04x2b[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x2b, 2000);
    Tweener[_0x5e86[183]](
      _0x5a04x2b,
      { x: [820, 330, 328, 325], alpha: [1, 1, 1, 1] },
      { time: 80 }
    );
  }
  function _0x5a04x6f() {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x34[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x6e = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[181]);
      _0x5a04x6e[_0x5e86[144]][_0x5e86[128]] = 1;
      _0x5a04x6e[_0x5e86[144]][_0x5e86[129]] = 0.5;
      _0x5a04x6e[_0x5e86[141]][_0x5e86[140]](0.7);
      _0x5a04x6e[_0x5e86[185]] = Math[_0x5e86[186]] / 2;
      _0x5a04x6e[_0x5e86[128]] = _0x5a04x34[_0x5a04x60][_0x5e86[128]];
      _0x5a04x6e[_0x5e86[129]] = _0x5a04x34[_0x5a04x60][_0x5e86[129]] - 30;
      _0x5a04x1e[_0x5e86[126]](_0x5a04x6e, _0x5a04x6e[_0x5e86[129]]);
      Tweener[_0x5e86[183]](
        _0x5a04x6e,
        { y: _0x5a04x6e[_0x5e86[129]] - 10 },
        { time: 50, loop: -1, transition: _0x5e86[182] }
      );
      _0x5a04x34[_0x5a04x60][_0x5e86[181]] = _0x5a04x6e;
    }
  }
  function _0x5a04x70() {
    _0x5a04x12 = false;
    _0x5a04x9[_0x5e86[100]] = false;
    _0x5a04xc[_0x5e86[73]][_0x5e86[162]]();
    _0x5a04xe = 1200 + Math[_0x5e86[178]]() * 600;
    _0x5a04xf = 3;
    _0x5a04xa5(true);
    _0x5a04xa5(true);
    _0x5a04xa5(true);
    _0x5a04xa4();
    _0x5a04xa4();
    _0x5a04x77();
  }
  function _0x5a04x71() {
    _0x5a04xc[_0x5e86[73]][_0x5e86[162]]();
    _0x5a04xe = 1200 + Math[_0x5e86[178]]() * 600;
    _0x5a04xf = 3;
    var _0x5a04x72 = [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,
      22,
      23,
      24,
    ];
    for (var _0x5a04x60 = 0; _0x5a04x60 < 3; _0x5a04x60++) {
      var _0x5a04x1f = new PIXI[_0x5e86[168]].Spine(
        PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[166]][_0x5e86[165]]
      );
      _0x5a04x1f[_0x5e86[152]] = true;
      _0x5a04x1f[_0x5e86[169]] = true;
      _0x5a04x1f[_0x5e86[128]] = 160 + _0x5a04x60 * 160;
      _0x5a04x1f[_0x5e86[129]] = 900;
      _0x5a04x1f[_0x5e86[170]] = 2;
      _0x5a04x1e[_0x5e86[126]](_0x5a04x1f, 900);
      _0x5a04x1f[_0x5e86[171]] = { x: 0, y: 0, ratio: 60 };
      _0x5a04x1f[_0x5e86[172]] = {};
      _0x5a04x1f[_0x5e86[172]][_0x5e86[128]] = 2;
      _0x5a04x1f[_0x5e86[172]][_0x5e86[129]] = 21;
      _0x5a04x1f[_0x5e86[172]][_0x5e86[109]] = 58;
      _0x5a04x1f[_0x5e86[172]][_0x5e86[110]] = 50;
      _0x5a04x1f[_0x5e86[87]](_0x5e86[155], function () {
        _0x5a04x94(this);
      });
      _0x5a04x1f[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[173], true);
      _0x5a04x30[_0x5e86[145]](_0x5a04x1f);
    }
    for (var _0x5a04x60 = 0; _0x5a04x60 < 3; _0x5a04x60++) {
      p = _0x5a04x72[_0x5e86[188]](
        Math[_0x5e86[187]](
          Math[_0x5e86[178]]() * (_0x5a04x72[_0x5e86[161]] - 1)
        ),
        1
      )[0];
      var _0x5a04x73 = Math[_0x5e86[189]](p / 5);
      var _0x5a04x74 = p - Math[_0x5e86[189]](p / 5) * 5;
      var _0x5a04x75 = new PIXI[_0x5e86[168]].Spine(
        PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[190]][_0x5e86[165]]
      );
      _0x5a04x75[_0x5e86[128]] = 136 + _0x5a04x73 * 92;
      _0x5a04x75[_0x5e86[129]] = 150 + _0x5a04x74 * 88;
      _0x5a04x75[_0x5e86[170]] = 2;
      _0x5a04x75[_0x5e86[191]] = [_0x5a04x73, _0x5a04x74];
      _0x5a04x75[_0x5e86[192]] = 180;
      _0x5a04x75[_0x5e86[177]] = _0x5a04x15 + Math[_0x5e86[178]]() * _0x5a04x16;
      _0x5a04x75[_0x5e86[193]] = 15;
      _0x5a04x75[_0x5e86[194]] = _0x5a04x1b;
      _0x5a04x75[_0x5e86[196]][_0x5e86[195]]();
      _0x5a04x1e[_0x5e86[126]](_0x5a04x75, _0x5a04x75[_0x5e86[129]]);
      _0x5a04x2f[_0x5e86[145]](_0x5a04x75);
      _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[173], true);
      _0x5a04x2c[_0x5a04x73][_0x5a04x74] = _0x5a04x75;
    }
    var _0x5a04x6c = new _0x5a04x135();
    _0x5a04x6c[_0x5e86[128]] = 370;
    _0x5a04x6c[_0x5e86[129]] = 280;
    _0x5a04x6c[_0x5e86[176]] = true;
    _0x5a04x6c[_0x5e86[177]] = 220 + Math[_0x5e86[178]]() * 500;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x6c, 255);
    _0x5a04x33[_0x5e86[145]](_0x5a04x6c);
    _0x5a04x2c[3][1] = _0x5a04x6c;
    _0x5a04x2c[4][1] = _0x5a04x6c;
    var _0x5a04x6d = new _0x5a04x135();
    _0x5a04x6d[_0x5e86[128]] = 170;
    _0x5a04x6d[_0x5e86[129]] = 480;
    _0x5a04x6d[_0x5e86[176]] = true;
    _0x5a04x6d[_0x5e86[177]] = 220 + Math[_0x5e86[178]]() * 500;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x6d, 455);
    _0x5a04x33[_0x5e86[145]](_0x5a04x6d);
    _0x5a04x2c[1][3] = _0x5a04x6d;
    _0x5a04x2c[2][3] = _0x5a04x6d;
  }
  function _0x5a04x76() {
    gamee[_0x5e86[197]](_0x5a04xd);
  }
  function _0x5a04x77() {
    gamee[_0x5e86[199]](JSON[_0x5e86[198]](_0x5a04x9), false);
  }
  function _0x5a04x78(_0x5a04x79) {
    _0x5a04x3a = true;
  }
  function _0x5a04x7a(_0x5a04x7b) {
    stats[_0x5e86[200]]();
    if (!_0x5a04x37) {
      return;
    }
    _0x5a04x13d[_0x5e86[201]](_0x5a04x7b);
    var _0x5a04x7c = _0x5a04x36[_0x5e86[202]](0);
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
      _0x5a04x60++
    ) {
      if (_0x5a04x7c[_0x5a04x60][_0x5e86[201]](_0x5a04x7b) < 0) {
        _0x5a04x106(_0x5a04x36, _0x5a04x7c[_0x5a04x60]);
      }
    }
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x30[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x1f = _0x5a04x30[_0x5a04x60];
      if (_0x5a04x1f[_0x5e86[203]]) {
        let _0x5a04x7d = _0x5a04x1f[_0x5e86[203]];
        if (_0x5a04x7d[_0x5e86[204]]) {
          continue;
          var _0x5a04x7e = 1 - _0x5a04x7d[_0x5e86[204]] / 5;
          var _0x5a04x7f = (1 - _0x5a04x7e) / 2;
          _0x5a04x7d[_0x5e86[141]][_0x5e86[128]] = 1 - _0x5a04x7f;
          _0x5a04x7d[_0x5e86[141]][_0x5e86[129]] = 1 + _0x5a04x7f;
          _0x5a04x7d[_0x5e86[204]] *= 0.9;
          if (_0x5a04x7d[_0x5e86[204]] < 0.1) {
            _0x5a04x7d[_0x5e86[204]] = 0;
            _0x5a04x7d[_0x5e86[141]][_0x5e86[140]](1);
          }
        }
      }
    }
    var _0x5a04x7c = _0x5a04x2d[_0x5e86[202]](0);
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x80 = _0x5a04x7c[_0x5a04x60];
      _0x5a04x80[_0x5e86[205]] += _0x5a04x80[_0x5e86[206]];
      if (_0x5a04x80[_0x5e86[206]] < 2) {
        _0x5a04x80[_0x5e86[206]] += 0.1;
      }
      if (_0x5a04x80[_0x5e86[205]] > 0) {
        _0x5a04x80[_0x5e86[141]][_0x5e86[128]] += 0.1;
        _0x5a04x80[_0x5e86[141]][_0x5e86[129]] -= 0.1;
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[129]] < 0.5) {
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]], true);
          _0x5a04xca(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]], true);
          _0x5a04x106(_0x5a04x2d, _0x5a04x80);
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
        }
      } else {
        _0x5a04x80[_0x5e86[129]] += _0x5a04x80[_0x5e86[207]];
        _0x5a04x80[_0x5e86[208]] = _0x5a04x80[_0x5e86[129]];
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[128]] > 1) {
          _0x5a04x80[_0x5e86[141]][_0x5e86[128]] -=
            _0x5a04x80[_0x5e86[207]] / 100;
        }
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[129]] < 1) {
          _0x5a04x80[_0x5e86[141]][_0x5e86[129]] +=
            _0x5a04x80[_0x5e86[207]] / 100;
        }
        let _0x5a04x81 = false;
        for (
          var _0x5a04x61 = 0;
          _0x5a04x61 < _0x5a04x30[_0x5e86[161]];
          _0x5a04x61++
        ) {
          var _0x5a04x1f = _0x5a04x30[_0x5a04x61];
          var _0x5a04x82 = _0x5a04x119(_0x5a04x1f, _0x5a04x80);
          if (_0x5a04x82 < 25) {
            _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
            if (_0x5a04x1f[_0x5e86[203]]) {
              _0x5a04xc5(
                _0x5a04x80[_0x5e86[128]],
                _0x5a04x80[_0x5e86[129]] - 15
              );
              Tweener[_0x5e86[183]](
                _0x5a04x1f[_0x5e86[209]],
                { alpha: 0 },
                {
                  time: 20,
                  onComplete: function (_0x5a04x6b) {
                    _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                  },
                }
              );
              _0x5a04x1f[_0x5e86[203]][_0x5e86[175]][_0x5e86[174]](
                0,
                _0x5e86[212],
                false
              );
              _0x5a04x1f[_0x5e86[203]] = null;
              _0x5a04x1f[_0x5e86[209]] = null;
            } else {
              _0x5a04x1f[_0x5e86[170]]--;
              _0x5a04x2a[_0x5e86[213]] =
                PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[214]];
              Tweener[_0x5e86[183]](
                _0x5a04x2a,
                {},
                {
                  time: 30,
                  onComplete: function () {
                    _0x5a04x2a[_0x5e86[213]] =
                      PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[143]];
                  },
                }
              );
              if (_0x5a04x1f[_0x5e86[170]] <= 0) {
                _0x5a04xc[_0x5e86[67]][_0x5e86[162]]();
                _0x5a04x1f[_0x5e86[175]][_0x5e86[174]](
                  0,
                  _0x5e86[216],
                  false,
                  0
                );
                Tweener[_0x5e86[183]](
                  _0x5a04x1f,
                  {
                    y: [
                      _0x5a04x1f[_0x5e86[129]],
                      _0x5a04x1f[_0x5e86[129]] + 25,
                      _0x5a04x1f[_0x5e86[129]] + 50,
                      _0x5a04x1f[_0x5e86[129]] + 50,
                    ],
                    alpha: [1, 1, 1, 0],
                  },
                  {
                    time: 30,
                    delay: 0,
                    transition: _0x5e86[217],
                    onComplete: function (_0x5a04x6b) {
                      _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                      _0x5a04x6b[_0x5e86[218]]();
                      if (!_0x5a04x30[_0x5e86[161]]) {
                        _0x5a04x65();
                      }
                    },
                  }
                );
                if (_0x5a04x1f == _0x5a04x133[_0x5e86[164]]) {
                  _0x5a04x20[_0x5e86[219]] = 0;
                  _0x5a04x21[_0x5e86[219]] = 0;
                  _0x5a04x133[_0x5e86[164]] = null;
                }
                _0x5a04x1f[_0x5e86[152]] = false;
                _0x5a04x30[_0x5e86[188]](
                  _0x5a04x30[_0x5e86[220]](_0x5a04x1f),
                  1
                );
              } else {
                _0x5a04xc[_0x5e86[79]][_0x5e86[162]]();
                _0x5a04x1f[_0x5e86[175]][_0x5e86[174]](
                  0,
                  _0x5e86[221],
                  false,
                  0
                );
                _0x5a04x1f[_0x5e86[175]][_0x5e86[223]](
                  0,
                  _0x5e86[222],
                  true,
                  0
                );
              }
            }
            _0x5a04x106(_0x5a04x2d, _0x5a04x80);
            _0x5a04x81 = true;
            break;
          }
        }
        if (_0x5a04x81) {
          continue;
        }
        if (_0x5a04xe8(_0x5a04x80)) {
          _0x5a04xc[_0x5e86[75]][_0x5e86[162]]();
          _0x5a04xc5(
            _0x5a04x80[_0x5e86[128]],
            _0x5a04x80[_0x5e86[129]] - 15,
            true
          );
          _0x5a04x106(_0x5a04x2d, _0x5a04x80);
          continue;
        }
        if (_0x5a04xe6(_0x5a04x80)) {
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]], true);
          _0x5a04x106(_0x5a04x2d, _0x5a04x80);
          continue;
        }
        if (_0x5a04x80[_0x5e86[129]] > 1050) {
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]], true);
          _0x5a04x106(_0x5a04x2d, _0x5a04x80);
          continue;
        }
      }
    }
    var _0x5a04x7c = _0x5a04x2e[_0x5e86[202]](0);
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x80 = _0x5a04x7c[_0x5a04x60];
      _0x5a04x80[_0x5e86[205]] += _0x5a04x80[_0x5e86[206]];
      _0x5a04x80[_0x5e86[208]] = _0x5a04x80[_0x5e86[129]];
      if (_0x5a04x80[_0x5e86[206]] < 2) {
        _0x5a04x80[_0x5e86[206]] += 0.1;
      }
      if (_0x5a04x80[_0x5e86[205]] > 0) {
        _0x5a04x80[_0x5e86[141]][_0x5e86[128]] += 0.2;
        _0x5a04x80[_0x5e86[141]][_0x5e86[129]] -= 0.2;
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[129]] < 0.5) {
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]]);
          _0x5a04xca(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]]);
          _0x5a04x106(_0x5a04x2e, _0x5a04x80);
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
        }
      } else {
        _0x5a04x80[_0x5e86[129]] -= _0x5a04x80[_0x5e86[207]];
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[128]] > 1) {
          _0x5a04x80[_0x5e86[141]][_0x5e86[128]] -=
            _0x5a04x80[_0x5e86[207]] / 100;
        }
        if (_0x5a04x80[_0x5e86[141]][_0x5e86[129]] < 1) {
          _0x5a04x80[_0x5e86[141]][_0x5e86[129]] +=
            _0x5a04x80[_0x5e86[207]] / 100;
        }
        var _0x5a04x83 = _0x5a04xe7(_0x5a04x80);
        if (_0x5a04x83) {
          _0x5a04xc[_0x5e86[65]][_0x5e86[162]]();
          if (_0x5a04x83[_0x5e86[224]] == _0x5e86[203]) {
            _0x5a04x97(_0x5a04x80[_0x5e86[225]]);
          } else {
            if (_0x5a04x30[_0x5e86[161]] < 3) {
              _0x5a04xa4();
              _0x5a04x9c(11);
            }
          }
          _0x5a04x2c[_0x5a04x83[_0x5e86[191]][0]][
            _0x5a04x83[_0x5e86[191]][1]
          ] = null;
          _0x5a04x106(_0x5a04x32, _0x5a04x83, true);
          _0x5a04x106(_0x5a04x2e, _0x5a04x80);
          Tweener[_0x5e86[183]](
            _0x5a04x83,
            {
              y: _0x5a04x83[_0x5e86[129]] - 20,
              scaleX: 1.5,
              scaleY: 1.5,
              alpha: 0,
            },
            {
              time: 20,
              transition: _0x5e86[226],
              onComplete: function (_0x5a04x6b) {
                _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                _0x5a04x6b[_0x5e86[218]]();
              },
            }
          );
          continue;
        }
        if (_0x5a04xe8(_0x5a04x80)) {
          _0x5a04xc[_0x5e86[75]][_0x5e86[162]]();
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]] - 15);
          _0x5a04x106(_0x5a04x2e, _0x5a04x80);
          continue;
        }
        if (_0x5a04xe6(_0x5a04x80)) {
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]]);
          _0x5a04x106(_0x5a04x2e, _0x5a04x80);
          continue;
        }
        if (_0x5a04x80[_0x5e86[129]] < 80) {
          _0x5a04xc[_0x5e86[63]][_0x5e86[162]]();
          _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]]);
          _0x5a04x106(_0x5a04x2e, _0x5a04x80);
          continue;
        }
        if (_0x5a04x12) {
          for (
            var _0x5a04x84 = 0;
            _0x5a04x84 < _0x5a04x34[_0x5e86[161]];
            _0x5a04x84++
          ) {
            var _0x5a04x85 = _0x5a04x34[_0x5a04x84];
            var _0x5a04x82 = _0x5a04x119(_0x5a04x85, _0x5a04x80);
            if (_0x5a04x82 < 35) {
              _0x5a04xc[_0x5e86[75]][_0x5e86[162]]();
              if (_0x5a04x85[_0x5e86[181]]) {
                Tweener[_0x5e86[227]](_0x5a04x85[_0x5e86[181]]);
                _0x5a04x85[_0x5e86[181]][_0x5e86[211]][_0x5e86[210]](
                  _0x5a04x85[_0x5e86[181]]
                );
              }
              _0x5a04xc5(_0x5a04x80[_0x5e86[128]], _0x5a04x80[_0x5e86[129]]);
              _0x5a04x106(_0x5a04x34, _0x5a04x85, true);
              _0x5a04x106(_0x5a04x2e, _0x5a04x80);
              Tweener[_0x5e86[183]](
                _0x5a04x85,
                { y: _0x5a04x85[_0x5e86[129]] - 20, alpha: 0 },
                {
                  time: 20,
                  transition: _0x5e86[226],
                  onComplete: function (_0x5a04x6b) {
                    _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                    _0x5a04x6b[_0x5e86[218]]();
                  },
                }
              );
              if (!_0x5a04x34[_0x5e86[161]]) {
                _0x5a04x70();
              }
              break;
            }
          }
        }
      }
    }
    if (_0x5a04x3a) {
      if (_0x5a04x3c) {
        if (_0x5a04x133[_0x5e86[164]]) {
          _0x5a04x20[_0x5e86[219]]++;
          _0x5a04x21[_0x5e86[219]]++;
        }
      }
      if (!_0x5a04x12) {
        _0x5a04x18--;
        if (_0x5a04x18 == 0) {
          if (_0x5a04x2f[_0x5e86[161]] < 10 && !_0x5a04x1c) {
            _0x5a04xa5();
          }
          _0x5a04x18 = _0x5a04x17;
        }
        _0x5a04xe--;
        var _0x5a04x7c = _0x5a04x32[_0x5e86[202]](0);
        for (
          var _0x5a04x60 = 0;
          _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
          _0x5a04x60++
        ) {
          var _0x5a04x86 = _0x5a04x32[_0x5a04x60];
          _0x5a04x86[_0x5e86[228]]--;
          if (_0x5a04x86[_0x5e86[228]] < 0) {
            _0x5a04x2c[_0x5a04x86[_0x5e86[191]][0]][
              _0x5a04x86[_0x5e86[191]][1]
            ] = null;
            _0x5a04x106(_0x5a04x32, _0x5a04x86);
          } else {
            if (_0x5a04x86[_0x5e86[228]] < 120) {
              _0x5a04x86[_0x5e86[229]] =
                Math[_0x5e86[187]](_0x5a04x86[_0x5e86[228]] / 10) % 2;
            }
          }
        }
        if (_0x5a04xe <= 0) {
          if (_0x5a04x32[_0x5e86[161]] < 1) {
            _0x5a04x95();
          }
          _0x5a04xe = 1200 + Math[_0x5e86[178]]() * 600;
        }
      }
      var _0x5a04x7c = _0x5a04x33[_0x5e86[202]](0);
      for (
        var _0x5a04x60 = 0;
        _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
        _0x5a04x60++
      ) {
        if (_0x5a04x12) {
          break;
        }
        var _0x5a04x6c = _0x5a04x7c[_0x5a04x60];
        if (!_0x5a04x6c[_0x5e86[180]]) {
          continue;
        }
        _0x5a04x6c[_0x5e86[177]]--;
        if (_0x5a04x6c[_0x5e86[177]] <= 0) {
          if (_0x5a04x6c[_0x5e86[230]]) {
            _0x5a04x6c[_0x5e86[179]]();
          } else {
            _0x5a04x6c[_0x5e86[231]]();
          }
          _0x5a04x6c[_0x5e86[177]] = 320 + Math[_0x5e86[178]]() * 1000;
        }
      }
      var _0x5a04x7c = _0x5a04x2f[_0x5e86[202]](0);
      for (
        var _0x5a04x60 = 0;
        _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
        _0x5a04x60++
      ) {
        if (_0x5a04x12) {
          break;
        }
        var _0x5a04x75 = _0x5a04x7c[_0x5a04x60];
        _0x5a04x75[_0x5e86[177]]--;
        if (_0x5a04x75[_0x5e86[177]] <= 0) {
          if (_0x5a04x75[_0x5e86[232]]) {
            if (_0x5a04x1d) {
              _0x5a04x1d = false;
            }
            var _0x5a04x87 = _0x5a04xa7();
            var _0x5a04x6a = Math[_0x5e86[187]](
              (_0x5a04x87[_0x5e86[128]] - 136) / 92
            );
            if (Math[_0x5e86[178]]() > 0.7) {
              _0x5a04x6a = Math[_0x5e86[189]](Math[_0x5e86[178]]() * 5);
            }
            var _0x5a04x88 = Math[_0x5e86[189]](Math[_0x5e86[178]]() * 5);
            let _0x5a04x73 =
              136 + _0x5a04x6a * 92 - 30 + Math[_0x5e86[178]]() * 60;
            let _0x5a04x74 =
              150 + _0x5a04x88 * 88 - 30 + Math[_0x5e86[178]]() * 60;
            var _0x5a04x89 = 25;
            var _0x5a04x8a = 10;
            if (
              Math[_0x5e86[233]](_0x5a04x75[_0x5e86[191]][0] - _0x5a04x6a) <
                3 &&
              Math[_0x5e86[233]](_0x5a04x75[_0x5e86[191]][1] - _0x5a04x88) < 3
            ) {
              _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[234], true);
              _0x5a04x89 =
                Math[_0x5e86[235]](
                  Math[_0x5e86[233]](_0x5a04x75[_0x5e86[191]][0] - _0x5a04x6a),
                  Math[_0x5e86[233]](_0x5a04x75[_0x5e86[191]][1] - _0x5a04x88)
                ) * 60;
              _0x5a04x8a = 0;
            } else {
              _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[236], false);
              _0x5a04x75[_0x5e86[237]] = true;
            }
            _0x5a04x75[_0x5e86[191]][0] = _0x5a04x6a;
            _0x5a04x75[_0x5e86[191]][1] = _0x5a04x88;
            _0x5a04x75[_0x5e86[238]] = Math[_0x5e86[239]](1 + _0x5a04x1a, 6);
            var _0x5a04x8b = 0;
            _0x5a04x75[_0x5e86[240]] = true;
            Tweener[_0x5e86[183]](
              _0x5a04x75,
              { x: _0x5a04x73, y: _0x5a04x74 },
              {
                time: _0x5a04x89,
                delay: 5 + _0x5a04x8a,
                onUpdate: function (_0x5a04x6b) {
                  _0x5a04x6b[_0x5e86[208]] =
                    _0x5a04x6b[_0x5e86[129]] + _0x5a04x6b[_0x5e86[193]];
                },
                onComplete: function (_0x5a04x6b) {
                  if (_0x5a04x6b[_0x5e86[237]]) {
                    _0x5a04xbe();
                  }
                  _0x5a04x6b[_0x5e86[208]] =
                    _0x5a04x6b[_0x5e86[129]] + _0x5a04x6b[_0x5e86[193]];
                  _0x5a04x6b[_0x5e86[240]] = false;
                  _0x5a04x6b[_0x5e86[237]] = false;
                  if (
                    (_0x5a04x6b[_0x5e86[238]] == 1 &&
                      Math[_0x5e86[178]]() > 0.5) ||
                    _0x5a04x6b[_0x5e86[238]] % 2 == 0
                  ) {
                    _0x5a04x8b = 90;
                    _0x5a04x6b[_0x5e86[175]][_0x5e86[174]](
                      0,
                      _0x5e86[241],
                      false
                    );
                  }
                  _0x5a04x6b[_0x5e86[175]][_0x5e86[174]](
                    0,
                    _0x5e86[242],
                    false
                  );
                  Tweener[_0x5e86[183]](
                    _0x5a04x6b,
                    {},
                    {
                      time: 20,
                      onComplete: function () {
                        _0x5a04xbf(
                          _0x5a04x6b[_0x5e86[128]] + _0x5a04x8b,
                          _0x5a04x6b[_0x5e86[129]],
                          _0x5a04x6b
                        );
                      },
                    }
                  );
                },
              }
            );
            _0x5a04x75[_0x5e86[177]] =
              _0x5a04x89 + 25 + _0x5a04x8a + 20 * _0x5a04x75[_0x5e86[238]];
          } else {
            var _0x5a04x87 = _0x5a04xa7();
            var _0x5a04x6a;
            if (_0x5a04x87) {
              _0x5a04x6a = Math[_0x5e86[187]](
                (_0x5a04x87[_0x5e86[128]] - 136) / 92
              );
              if (_0x5a04x75[_0x5e86[191]][0] - _0x5a04x6a < -2) {
                _0x5a04x6a = _0x5a04x75[_0x5e86[191]][0] + 2;
              } else {
                if (_0x5a04x75[_0x5e86[191]][0] - _0x5a04x6a > 2) {
                  _0x5a04x6a = _0x5a04x75[_0x5e86[191]][0] - 2;
                }
              }
            } else {
              _0x5a04x6a = Math[_0x5e86[189]](Math[_0x5e86[178]]() * 5);
            }
            var _0x5a04x8c = _0x5a04xb8(
              _0x5a04x75[_0x5e86[191]][0],
              _0x5a04x6a
            );
            var _0x5a04x88 =
              _0x5a04x8c[
                Math[_0x5e86[189]](
                  Math[_0x5e86[178]]() * _0x5a04x8c[_0x5e86[161]]
                )
              ];
            var _0x5a04x8d = _0x5a04xab(_0x5a04x75[_0x5e86[191]], [
              _0x5a04x6a,
              _0x5a04x88,
            ]);
            _0x5a04x2c[_0x5a04x75[_0x5e86[191]][0]][
              _0x5a04x75[_0x5e86[191]][1]
            ] = null;
            if (_0x5a04x8d) {
              _0x5a04x75[_0x5e86[191]][0] = _0x5a04x8d[0];
              _0x5a04x75[_0x5e86[191]][1] = _0x5a04x8d[1];
            } else {
              var _0x5a04x8e = _0x5a04xce(
                _0x5a04x75[_0x5e86[191]][0],
                _0x5a04x75[_0x5e86[191]][1]
              );
              var _0x5a04x8f =
                _0x5a04x8e[_0x5e86[243]][
                  Math[_0x5e86[187]](
                    Math[_0x5e86[178]]() *
                      (_0x5a04x8e[_0x5e86[243]][_0x5e86[161]] - 1)
                  )
                ];
              var _0x5a04x90 =
                1 +
                Math[_0x5e86[187]](
                  Math[_0x5e86[178]]() *
                    (_0x5a04x8e[_0x5e86[244]][_0x5a04x8f] - 1)
                );
              switch (_0x5a04x8f) {
                case 0:
                  _0x5a04x75[_0x5e86[191]][0] += _0x5a04x90;
                  break;
                case 1:
                  _0x5a04x75[_0x5e86[191]][0] -= _0x5a04x90;
                  break;
                case 2:
                  _0x5a04x75[_0x5e86[191]][1] -= _0x5a04x90;
                  break;
                case 3:
                  _0x5a04x75[_0x5e86[191]][1] += _0x5a04x90;
                  break;
              }
            }
            let _0x5a04x73 =
              136 +
              _0x5a04x75[_0x5e86[191]][0] * 92 -
              30 +
              Math[_0x5e86[178]]() * 60;
            let _0x5a04x74 =
              150 +
              _0x5a04x75[_0x5e86[191]][1] * 88 -
              30 +
              Math[_0x5e86[178]]() * 60;
            _0x5a04xc[_0x5e86[59]][_0x5e86[162]]();
            if (_0x5a04x75[_0x5e86[170]] > 1) {
              _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[245], false);
              _0x5a04x75[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[173], true, 0);
            } else {
              _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[246], false);
              _0x5a04x75[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[222], true, 0);
            }
            _0x5a04x75[_0x5e86[240]] = true;
            Tweener[_0x5e86[183]](
              _0x5a04x75,
              { x: _0x5a04x73, y: _0x5a04x74 },
              {
                time: _0x5a04x75[_0x5e86[194]],
                delay: 5,
                onUpdate: function (_0x5a04x6b) {
                  _0x5a04x6b[_0x5e86[208]] =
                    _0x5a04x6b[_0x5e86[129]] + _0x5a04x6b[_0x5e86[193]];
                },
                onComplete: function (_0x5a04x6b) {
                  _0x5a04x6b[_0x5e86[240]] = false;
                  Tweener[_0x5e86[183]](
                    _0x5a04x6b,
                    {},
                    {
                      time: 20,
                      onComplete: function () {
                        _0x5a04xc1(
                          _0x5a04x6b[_0x5e86[128]],
                          _0x5a04x6b[_0x5e86[129]]
                        );
                        _0x5a04x6b[_0x5e86[208]] =
                          _0x5a04x6b[_0x5e86[129]] + _0x5a04x6b[_0x5e86[193]];
                      },
                    }
                  );
                },
              }
            );
            _0x5a04x75[_0x5e86[177]] =
              _0x5a04x15 + Math[_0x5e86[178]]() * _0x5a04x16;
            _0x5a04x2c[_0x5a04x75[_0x5e86[191]][0]][
              _0x5a04x75[_0x5e86[191]][1]
            ] = _0x5a04x75;
          }
        } else {
          var _0x5a04x91 = _0x5a04x2e[_0x5e86[202]](0);
          for (
            var _0x5a04x61 = 0;
            _0x5a04x61 < _0x5a04x91[_0x5e86[161]];
            _0x5a04x61++
          ) {
            var _0x5a04x80 = _0x5a04x91[_0x5a04x61];
            var _0x5a04x82 = _0x5a04x119(_0x5a04x75, _0x5a04x80);
            if (
              _0x5a04x75[_0x5e86[232]] &&
              _0x5a04x82 < 50 &&
              !_0x5a04x75[_0x5e86[237]]
            ) {
              _0x5a04xc[_0x5e86[65]][_0x5e86[162]]();
              _0x5a04x75[_0x5e86[170]]--;
              if (_0x5a04x75[_0x5e86[170]] <= 0) {
                _0x5a04xd++;
                _0x5a04x76();
                _0x5a04x1c = false;
                _0x5a04x1a++;
                _0x5a04x19 = 10 + 5 * _0x5a04x1a;
                _0x5a04x9e(
                  _0x5a04x75[_0x5e86[128]],
                  _0x5a04x75[_0x5e86[129]] - 70
                );
                _0x5a04x75[_0x5e86[175]][_0x5e86[174]](
                  0,
                  _0x5e86[247],
                  false,
                  0
                );
                Tweener[_0x5e86[183]](
                  _0x5a04x75,
                  {
                    y: [
                      _0x5a04x75[_0x5e86[129]],
                      _0x5a04x75[_0x5e86[129]] - 25,
                      _0x5a04x75[_0x5e86[129]] - 50,
                      _0x5a04x75[_0x5e86[129]] - 50,
                    ],
                    alpha: [1, 1, 1, 0],
                  },
                  {
                    time: 30,
                    delay: 0,
                    transition: _0x5e86[217],
                    onComplete: function (_0x5a04x6b) {
                      _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                      _0x5a04x6b[_0x5e86[218]]();
                      _0x5a04x29[_0x5e86[138]] = false;
                      _0x5a04xa5();
                      _0x5a04xa5();
                      _0x5a04xa5();
                    },
                  }
                );
                _0x5a04x2c[_0x5a04x75[_0x5e86[191]][0]][
                  _0x5a04x75[_0x5e86[191]][1]
                ] = null;
                _0x5a04x2f[_0x5e86[188]](
                  _0x5a04x2f[_0x5e86[220]](_0x5a04x75),
                  1
                );
              } else {
                _0x5a04xd++;
                _0x5a04x76();
                _0x5a04x9e(
                  _0x5a04x75[_0x5e86[128]],
                  _0x5a04x75[_0x5e86[129]] - 70
                );
                Tweener[_0x5e86[183]](
                  _0x5a04x29,
                  {
                    percent:
                      (_0x5a04x75[_0x5e86[170]] / (5 + 5 * _0x5a04x1a)) * 100,
                  },
                  { time: 50, transition: _0x5e86[226] }
                );
                _0x5a04x75[_0x5e86[175]][_0x5e86[174]](
                  0,
                  _0x5e86[247],
                  false,
                  0
                );
                _0x5a04x75[_0x5e86[175]][_0x5e86[223]](
                  0,
                  _0x5e86[234],
                  true,
                  0
                );
              }
              _0x5a04x106(_0x5a04x2e, _0x5a04x80);
            } else {
              if (_0x5a04x82 < 34 && !_0x5a04x75[_0x5e86[240]]) {
                _0x5a04xc[_0x5e86[65]][_0x5e86[162]]();
                var _0x5a04x92 = Math[_0x5e86[178]]();
                if (_0x5a04x92 > 0.8 && _0x5a04x14 != 0) {
                  _0x5a04xc[_0x5e86[77]][_0x5e86[162]]();
                  _0x5a04x14 = 0;
                } else {
                  if (_0x5a04x92 > 0.6 && _0x5a04x14 != 1) {
                    _0x5a04xc[_0x5e86[69]][_0x5e86[162]]();
                    _0x5a04x14 = 1;
                  } else {
                    if (_0x5a04x92 > 0.4 && _0x5a04x14 != 2) {
                      _0x5a04xc[_0x5e86[81]][_0x5e86[162]]();
                      _0x5a04x14 = 2;
                    } else {
                      if (_0x5a04x92 > 0.2 && _0x5a04x14 != 3) {
                        _0x5a04xc[_0x5e86[71]][_0x5e86[162]]();
                        _0x5a04x14 = 3;
                      } else {
                        _0x5a04x14 = -1;
                      }
                    }
                  }
                }
                _0x5a04x75[_0x5e86[170]]--;
                if (_0x5a04x75[_0x5e86[170]] <= 0) {
                  _0x5a04xd++;
                  _0x5a04x76();
                  _0x5a04x19--;
                  if (_0x5a04x19 == 0) {
                    _0x5a04x1c = true;
                  }
                  _0x5a04x9e(
                    _0x5a04x75[_0x5e86[128]],
                    _0x5a04x75[_0x5e86[129]] - 70
                  );
                  _0x5a04x75[_0x5e86[175]][_0x5e86[174]](
                    0,
                    _0x5e86[248],
                    false,
                    0
                  );
                  Tweener[_0x5e86[183]](
                    _0x5a04x75,
                    {
                      y: [
                        _0x5a04x75[_0x5e86[129]],
                        _0x5a04x75[_0x5e86[129]] - 25,
                        _0x5a04x75[_0x5e86[129]] - 50,
                        _0x5a04x75[_0x5e86[129]] - 50,
                      ],
                      alpha: [1, 1, 1, 0],
                    },
                    {
                      time: 30,
                      delay: 0,
                      transition: _0x5e86[217],
                      onComplete: function (_0x5a04x6b) {
                        _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                        _0x5a04x6b[_0x5e86[218]]();
                        if (!_0x5a04x2f[_0x5e86[161]]) {
                          if (!_0x5a04x1c) {
                            if (_0x5a04x19 < 2) {
                              _0x5a04xa5();
                            } else {
                              if (_0x5a04x19 < 3) {
                                _0x5a04xa5();
                                _0x5a04xa5();
                              } else {
                                _0x5a04xa5();
                                _0x5a04xa5();
                                _0x5a04xa5();
                              }
                            }
                          } else {
                            _0x5a04xa2();
                          }
                        }
                      },
                    }
                  );
                  _0x5a04x2c[_0x5a04x75[_0x5e86[191]][0]][
                    _0x5a04x75[_0x5e86[191]][1]
                  ] = null;
                  _0x5a04x2f[_0x5e86[188]](
                    _0x5a04x2f[_0x5e86[220]](_0x5a04x75),
                    1
                  );
                  if (_0x5a04x10 % 2 == 0) {
                    if (_0x5a04x1b > 20) {
                      _0x5a04x1b--;
                    }
                    if (_0x5a04x15 > 20) {
                      _0x5a04x15 -= 2;
                    }
                    if (_0x5a04x16 > 50) {
                      _0x5a04x16 -= 5;
                    }
                    if (_0x5a04x17 > 600) {
                      _0x5a04x17 -= 10;
                    }
                  }
                  _0x5a04x10++;
                  if (_0x5a04x10 == 1) {
                    _0x5a04x9c(6);
                  } else {
                    if (_0x5a04x10 == 3) {
                      _0x5a04x9c(5);
                    } else {
                      if (_0x5a04x10 % 10 == 0) {
                        _0x5a04x9c(4);
                      }
                    }
                  }
                } else {
                  _0x5a04xd++;
                  _0x5a04x76();
                  _0x5a04x9e(
                    _0x5a04x75[_0x5e86[128]],
                    _0x5a04x75[_0x5e86[129]] - 70
                  );
                  _0x5a04x75[_0x5e86[175]][_0x5e86[174]](
                    0,
                    _0x5e86[249],
                    false,
                    0
                  );
                  _0x5a04x75[_0x5e86[175]][_0x5e86[223]](
                    0,
                    _0x5e86[222],
                    true,
                    0
                  );
                }
                _0x5a04x106(_0x5a04x2e, _0x5a04x80);
              }
            }
          }
        }
      }
      _0x5a04x1e[_0x5e86[250]]();
    } else {
    }
    _0x5a04x3e++;
    if (_0x5a04x3e > 9999999999) {
      _0x5a04x3e = 0;
    }
    stats[_0x5e86[251]]();
  }
  function _0x5a04x93() {}
  function _0x5a04x94(_0x5a04x6b) {
    if (_0x5a04x12 && _0x5a04x13) {
      if (_0x5a04x6b[_0x5e86[181]]) {
        Tweener[_0x5e86[227]](_0x5a04x6b[_0x5e86[181]]);
        _0x5a04x6b[_0x5e86[181]][_0x5e86[211]][_0x5e86[210]](
          _0x5a04x6b[_0x5e86[181]]
        );
      }
      Tweener[_0x5e86[183]](
        _0x5a04x2b,
        { x: [325, -300], alpha: [1, 0] },
        {
          time: 30,
          onComplete: function (_0x5a04x6b) {
            _0x5a04x2b[_0x5e86[138]] = false;
            _0x5a04x9c(12);
            _0x5a04x6f();
          },
        }
      );
      _0x5a04x13 = false;
    }
    if (_0x5a04x133[_0x5e86[164]]) {
      _0x5a04x9b(_0x5a04x133[_0x5e86[164]]);
    }
    _0x5a04x133[_0x5e86[164]] = _0x5a04x6b;
    _0x5a04x20[_0x5e86[128]] = _0x5a04x6b[_0x5e86[128]];
    _0x5a04x20[_0x5e86[129]] = _0x5a04x6b[_0x5e86[129]] + 20;
    _0x5a04x21[_0x5e86[128]] = _0x5a04x6b[_0x5e86[128]] - 55;
    _0x5a04x21[_0x5e86[129]] = _0x5a04x6b[_0x5e86[129]] - 30;
  }
  function _0x5a04x95() {
    var _0x5a04x72 = _0x5a04xbb();
    p = _0x5a04x72[_0x5e86[188]](
      Math[_0x5e86[187]](Math[_0x5e86[178]]() * (_0x5a04x72[_0x5e86[161]] - 1)),
      1
    )[0];
    var _0x5a04x73 = Math[_0x5e86[189]](p / 5);
    var _0x5a04x74 = p - Math[_0x5e86[189]](p / 5) * 5;
    itemId = _0x5e86[203];
    if (_0x5a04x30[_0x5e86[161]] < 3 && Math[_0x5e86[178]]() > 0.7) {
      itemId = _0x5e86[252];
    }
    var _0x5a04x96 = new _0x5a04x134(itemId);
    _0x5a04x96[_0x5e86[128]] = 136 + _0x5a04x73 * 92;
    _0x5a04x96[_0x5e86[129]] = 150 + _0x5a04x74 * 88;
    _0x5a04x96[_0x5e86[191]] = [_0x5a04x73, _0x5a04x74];
    _0x5a04x96[_0x5e86[224]] = itemId;
    _0x5a04x96[_0x5e86[228]] = 1080;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x96, _0x5a04x96[_0x5e86[129]]);
    _0x5a04x32[_0x5e86[145]](_0x5a04x96);
    _0x5a04x2c[_0x5a04x73][_0x5a04x74] = _0x5a04x96;
    Tweener[_0x5e86[183]](
      _0x5a04x96,
      { z: 6 },
      { time: 70, transition: _0x5e86[182], loop: -1 }
    );
  }
  function _0x5a04x97(_0x5a04x6b) {
    if (_0x5a04x6b[_0x5e86[203]]) {
      return;
    }
    _0x5a04x9c(10);
    var _0x5a04x7d = new PIXI[_0x5e86[168]].Spine(
      PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[253]][_0x5e86[165]]
    );
    _0x5a04x7d[_0x5e86[128]] = _0x5a04x6b[_0x5e86[128]];
    _0x5a04x7d[_0x5e86[129]] = _0x5a04x6b[_0x5e86[129]] - 5;
    _0x5a04x7d[_0x5e86[204]] = 0;
    _0x5a04x7d[_0x5e86[254]] = 50;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x7d, _0x5a04x6b[_0x5e86[129]] + 1);
    _0x5a04x7d[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[255], false);
    _0x5a04x7d[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[256], true, 0);
    _0x5a04x6b[_0x5e86[203]] = _0x5a04x7d;
    Tweener[_0x5e86[183]](
      _0x5a04x7d,
      { kineticX: 0, kineticY: 0 },
      {
        time: 60,
        transition: _0x5e86[257],
        onUpdate: function (_0x5a04x6b) {
          if (_0x5a04x6b[_0x5e86[204]] > _0x5a04x6b[_0x5e86[254]]) {
            _0x5a04x6b[_0x5e86[254]] = 0;
          } else {
            _0x5a04x6b[_0x5e86[204]] = 0;
          }
          var _0x5a04x98 = (_0x5a04x6b[_0x5e86[204]] / 50) * 0.2;
          var _0x5a04x99 = (_0x5a04x6b[_0x5e86[254]] / 50) * 0.2;
          _0x5a04x6b[_0x5e86[141]][_0x5e86[128]] = 1 + _0x5a04x98 - _0x5a04x99;
          _0x5a04x6b[_0x5e86[141]][_0x5e86[129]] = 1 - _0x5a04x98 + _0x5a04x99;
        },
      }
    );
    var _0x5a04x9a = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[258]);
    _0x5a04x9a[_0x5e86[128]] = _0x5a04x6b[_0x5e86[128]];
    _0x5a04x9a[_0x5e86[129]] = _0x5a04x6b[_0x5e86[129]] - 5;
    _0x5a04x9a[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04x9a[_0x5e86[259]] = PIXI[_0x5e86[261]][_0x5e86[260]];
    _0x5a04x1e[_0x5e86[126]](_0x5a04x9a, 2);
    _0x5a04x6b[_0x5e86[209]] = _0x5a04x9a;
  }
  function _0x5a04x9b(_0x5a04x6b) {
    if (_0x5a04x6b[_0x5e86[170]] > 1) {
      _0x5a04x6b[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[262], false, 0);
      _0x5a04x6b[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[173], true, 0);
    } else {
      _0x5a04x6b[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[263], false, 0);
      _0x5a04x6b[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[222], true, 0);
    }
    _0x5a04xc2(_0x5a04x6b, _0x5a04x20[_0x5e86[219]]);
    _0x5a04x133[_0x5e86[164]] = null;
    _0x5a04x20[_0x5e86[219]] = 0;
    _0x5a04x21[_0x5e86[219]] = 0;
  }
  function _0x5a04x9c(_0x5a04x79) {
    var _0x5a04x9d = PIXI[_0x5e86[125]][_0x5e86[124]](
      _0x5e86[264] + _0x5a04x79
    );
    _0x5a04x9d[_0x5e86[128]] = 820;
    _0x5a04x9d[_0x5e86[129]] = 540;
    _0x5a04x9d[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x9d, 2000);
    Tweener[_0x5e86[183]](
      _0x5a04x9d,
      { x: [820, 330, 328, 325, 322, 320, -300], alpha: [1, 1, 1, 1, 1, 1, 0] },
      {
        time: 130,
        onComplete: function (_0x5a04x6b) {
          _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
          _0x5a04x6b[_0x5e86[218]]();
        },
      }
    );
  }
  function _0x5a04x9e(_0x5a04x9f, _0x5a04xa0) {
    var _0x5a04xa1 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[265]);
    _0x5a04xa1[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04xa1[_0x5e86[128]] = _0x5a04x9f;
    _0x5a04xa1[_0x5e86[129]] = _0x5a04xa0 + 20;
    _0x5a04xa1[_0x5e86[229]] = 0;
    _0x5a04xa1[_0x5e86[141]][_0x5e86[140]](0.2);
    _0x5a04x1e[_0x5e86[126]](_0x5a04xa1, 2000);
    Tweener[_0x5e86[183]](
      _0x5a04xa1,
      {
        y: [
          _0x5a04xa0 + 20,
          _0x5a04xa0 + 10,
          _0x5a04xa0,
          _0x5a04xa0,
          _0x5a04xa0,
        ],
        alpha: [0, 0.5, 1, 1, 1],
        scaleX: [0.2, 0.8, 1.4, 1, 1],
        scaleY: [0.2, 0.8, 1.4, 1, 1],
      },
      {
        time: 20,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x6b,
            { y: _0x5a04x6b[_0x5e86[129]] - 30, alpha: 0 },
            {
              time: 50,
              onComplete: function () {
                _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
                _0x5a04x6b[_0x5e86[218]]();
              },
            }
          );
        },
      }
    );
  }
  function _0x5a04xa2() {
    _0x5a04x1d = true;
    _0x5a04xa3();
    var _0x5a04x9d = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[266]);
    _0x5a04x9d[_0x5e86[128]] = 820;
    _0x5a04x9d[_0x5e86[129]] = 540;
    _0x5a04x9d[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04x1e[_0x5e86[126]](_0x5a04x9d, 2000);
    Tweener[_0x5e86[183]](
      _0x5a04x9d,
      { x: [820, 330, 328, 325, 322, 320, -300], alpha: [1, 1, 1, 1, 1, 1, 0] },
      {
        time: 150,
        delay: 100,
        onComplete: function (_0x5a04x6b) {
          _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
          _0x5a04x6b[_0x5e86[218]]();
        },
      }
    );
    _0x5a04x29[_0x5e86[138]] = true;
    _0x5a04x29[_0x5e86[229]] = 0;
    _0x5a04x29[_0x5e86[219]] = 0;
    Tweener[_0x5e86[183]](
      _0x5a04x29,
      { alpha: 1 },
      {
        time: 50,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x29,
            { percent: 100 },
            { time: 50, delay: 200, transition: _0x5e86[226] }
          );
        },
      }
    );
  }
  function _0x5a04xa3() {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x33[_0x5e86[161]];
      _0x5a04x60++
    ) {
      _0x5a04x33[_0x5a04x60][_0x5e86[179]]();
      _0x5a04x33[_0x5a04x60][_0x5e86[180]] = false;
    }
    _0x5a04xbc();
    var _0x5a04x72 = _0x5a04xbb();
    p = _0x5a04x72[_0x5e86[188]](
      Math[_0x5e86[187]](Math[_0x5e86[178]]() * (_0x5a04x72[_0x5e86[161]] - 1)),
      1
    )[0];
    var _0x5a04x73 = 2;
    var _0x5a04x74 = 2;
    var _0x5a04x75 = new PIXI[_0x5e86[168]].Spine(
      PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[267]][_0x5e86[165]]
    );
    _0x5a04x75[_0x5e86[128]] = 320;
    _0x5a04x75[_0x5e86[129]] = 100;
    _0x5a04x75[_0x5e86[229]] = 0;
    _0x5a04x75[_0x5e86[191]] = [_0x5a04x73, _0x5a04x74];
    _0x5a04x75[_0x5e86[232]] = true;
    _0x5a04x75[_0x5e86[192]] = 180;
    _0x5a04x75[_0x5e86[170]] = 5 + 5 * _0x5a04x1a;
    _0x5a04x75[_0x5e86[177]] = 280;
    _0x5a04x75[_0x5e86[193]] = 50;
    _0x5a04x75[_0x5e86[238]] = 1;
    _0x5a04x75[_0x5e86[196]][_0x5e86[195]]();
    _0x5a04x1e[_0x5e86[126]](_0x5a04x75, _0x5a04x75[_0x5e86[129]]);
    _0x5a04x2f[_0x5e86[145]](_0x5a04x75);
    _0x5a04x75[_0x5e86[208]] = 150 + _0x5a04x74 * 88;
    _0x5a04x75[_0x5e86[240]] = true;
    Tweener[_0x5e86[183]](
      _0x5a04x75,
      { x: 136 + _0x5a04x73 * 92, y: 150 + _0x5a04x74 * 88, alpha: 1 },
      {
        time: 37,
        delay: 20,
        onComplete: function (_0x5a04x6b) {
          _0x5a04x6b[_0x5e86[240]] = false;
          _0x5a04xbe();
          Tweener[_0x5e86[183]](
            _0x5a04x6b,
            {},
            { time: 20, onComplete: function () {} }
          );
        },
      }
    );
    _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[236], false);
    _0x5a04x75[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[173], true, 0);
  }
  function _0x5a04xa4() {
    Tweener[_0x5e86[183]](
      _0x5a04x27,
      { x: 80 },
      {
        time: 20,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x27,
            { x: 188 },
            { time: 20, delay: 30 }
          );
        },
      }
    );
    Tweener[_0x5e86[183]](
      _0x5a04x28,
      { x: 435 },
      {
        time: 20,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x28,
            { x: 320 },
            { time: 20, delay: 30 }
          );
        },
      }
    );
    var _0x5a04x1f = new PIXI[_0x5e86[168]].Spine(
      PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[166]][_0x5e86[165]]
    );
    _0x5a04x1f[_0x5e86[152]] = true;
    _0x5a04x1f[_0x5e86[169]] = true;
    _0x5a04x1f[_0x5e86[128]] = 320;
    _0x5a04x1f[_0x5e86[129]] = 1100;
    _0x5a04x1f[_0x5e86[170]] = 2;
    _0x5a04x1f[_0x5e86[229]] = 0;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x1f, 900);
    _0x5a04x1f[_0x5e86[171]] = { x: 0, y: 0, ratio: 60 };
    _0x5a04x1f[_0x5e86[172]] = {};
    _0x5a04x1f[_0x5e86[172]][_0x5e86[128]] = 2;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[129]] = 21;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[109]] = 58;
    _0x5a04x1f[_0x5e86[172]][_0x5e86[110]] = 50;
    _0x5a04x1f[_0x5e86[208]] = 900;
    _0x5a04x1f[_0x5e86[240]] = true;
    Tweener[_0x5e86[183]](
      _0x5a04x1f,
      {
        x: 160 + Math[_0x5e86[178]]() * 320,
        y: 900 - +Math[_0x5e86[178]]() * 200,
        alpha: 1,
      },
      {
        time: 27,
        delay: 10,
        onComplete: function (_0x5a04x6b) {
          _0x5a04x6b[_0x5e86[240]] = false;
          _0x5a04x6b[_0x5e86[208]] = _0x5a04x6b[_0x5e86[129]];
        },
      }
    );
    _0x5a04x1f[_0x5e86[87]](_0x5e86[155], function () {
      _0x5a04x94(this);
    });
    _0x5a04x1f[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[268], false);
    _0x5a04x1f[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[173], true, 0);
    _0x5a04x30[_0x5e86[145]](_0x5a04x1f);
  }
  function _0x5a04xa5(_0x5a04xa6) {
    _0x5a04xbc();
    var _0x5a04x72 = _0x5a04xbb();
    p = _0x5a04x72[_0x5e86[188]](
      Math[_0x5e86[187]](Math[_0x5e86[178]]() * (_0x5a04x72[_0x5e86[161]] - 1)),
      1
    )[0];
    var _0x5a04x73 = Math[_0x5e86[189]](p / 5);
    var _0x5a04x74 = p - Math[_0x5e86[189]](p / 5) * 5;
    var _0x5a04x75 = new PIXI[_0x5e86[168]].Spine(
      PIXI[_0x5e86[85]][_0x5e86[167]][_0x5e86[190]][_0x5e86[165]]
    );
    _0x5a04x75[_0x5e86[128]] = 320;
    _0x5a04x75[_0x5e86[129]] = 100;
    _0x5a04x75[_0x5e86[229]] = 0;
    _0x5a04x75[_0x5e86[191]] = [_0x5a04x73, _0x5a04x74];
    _0x5a04x75[_0x5e86[192]] = 180;
    _0x5a04x75[_0x5e86[170]] =
      _0x5a04x10 + _0x5a04x2f[_0x5e86[161]] < 7 ? 1 : 2;
    _0x5a04x75[_0x5e86[177]] = 50 + Math[_0x5e86[178]]() * _0x5a04x16;
    _0x5a04x75[_0x5e86[193]] = 15;
    _0x5a04x75[_0x5e86[194]] = _0x5a04x1b;
    _0x5a04x75[_0x5e86[196]][_0x5e86[195]]();
    _0x5a04x1e[_0x5e86[126]](_0x5a04x75, _0x5a04x75[_0x5e86[129]]);
    _0x5a04x2f[_0x5e86[145]](_0x5a04x75);
    _0x5a04x75[_0x5e86[208]] = 150 + _0x5a04x74 * 88;
    _0x5a04x75[_0x5e86[240]] = true;
    Tweener[_0x5e86[183]](
      _0x5a04x75,
      { x: 136 + _0x5a04x73 * 92, y: 150 + _0x5a04x74 * 88, alpha: 1 },
      {
        time: 37,
        delay: 10,
        onComplete: function (_0x5a04x6b) {
          _0x5a04x6b[_0x5e86[240]] = false;
          if (_0x5a04xa6) {
            return;
          }
          Tweener[_0x5e86[183]](
            _0x5a04x6b,
            {},
            {
              time: 20,
              onComplete: function () {
                _0x5a04xc1(_0x5a04x6b[_0x5e86[128]], _0x5a04x6b[_0x5e86[129]]);
              },
            }
          );
        },
      }
    );
    _0x5a04x75[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[268], false);
    if (_0x5a04x75[_0x5e86[170]] > 1) {
      _0x5a04x75[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[173], true, 0);
    } else {
      _0x5a04x75[_0x5e86[175]][_0x5e86[223]](0, _0x5e86[222], true, 0);
    }
    _0x5a04x2c[_0x5a04x73][_0x5a04x74] = _0x5a04x75;
  }
  function _0x5a04xa7() {
    return _0x5a04x30[
      Math[_0x5e86[189]](Math[_0x5e86[178]]() * _0x5a04x30[_0x5e86[161]])
    ];
  }
  function _0x5a04xa8(_0x5a04x75) {
    if (!_0x5a04x30[_0x5e86[161]]) {
      return {
        x: 160 + Math[_0x5e86[178]]() * 320,
        y: 900 - +Math[_0x5e86[178]]() * 200,
      };
    }
    var _0x5a04xa9 = 9999;
    var _0x5a04x6b = 0;
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x30[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x1f = _0x5a04x30[_0x5a04x60];
      var _0x5a04xaa = Math[_0x5e86[233]](
        _0x5a04x1f[_0x5e86[128]] - _0x5a04x75[_0x5e86[128]]
      );
      if (_0x5a04xaa < _0x5a04xa9) {
        _0x5a04xa9 = _0x5a04xaa;
        _0x5a04x6b = _0x5a04x60;
      }
    }
    return {
      x: _0x5a04x30[_0x5a04x6b][_0x5e86[128]],
      y: _0x5a04x30[_0x5a04x6b][_0x5e86[129]],
    };
  }
  function _0x5a04xab(_0x5a04xac, _0x5a04x6b) {
    var _0x5a04xad = _0x5a04x6b[0] - _0x5a04xac[0];
    var _0x5a04xae = _0x5a04x6b[1] - _0x5a04xac[1];
    var _0x5a04xaf = Math[_0x5e86[269]](_0x5a04xae, _0x5a04xad);
    var _0x5a04xb0 = _0x5a04xac[0];
    var _0x5a04xb1 = _0x5a04xac[1];
    var _0x5a04xb2 = Math[_0x5e86[270]](_0x5a04xaf);
    var _0x5a04xb3 = Math[_0x5e86[271]](_0x5a04xaf);
    var _0x5a04xb4 =
      Math[_0x5e86[233]](_0x5a04xb2) > Math[_0x5e86[233]](_0x5a04xb3)
        ? Math[_0x5e86[233]](_0x5a04xad / _0x5a04xb2) * 10
        : Math[_0x5e86[233]](_0x5a04xae / _0x5a04xb3) * 10;
    var _0x5a04xb5 = [_0x5a04xb0, _0x5a04xb1];
    for (var _0x5a04x60 = 0; _0x5a04x60 < _0x5a04xb4; _0x5a04x60++) {
      _0x5a04xb0 += _0x5a04xb2 * 0.1;
      _0x5a04xb1 += _0x5a04xb3 * 0.1;
      let _0x5a04xb6 = Math[_0x5e86[187]](_0x5a04xb0);
      let _0x5a04xb7 = Math[_0x5e86[187]](_0x5a04xb1);
      if (_0x5a04xb6 == _0x5a04xb5[0] && _0x5a04xb7 == _0x5a04xb5[1]) {
        continue;
      }
      if (
        _0x5a04x2c[_0x5a04xb6][_0x5a04xb7] &&
        _0x5a04x2c[_0x5a04xb6][_0x5a04xb7][_0x5e86[176]] &&
        _0x5a04x2c[_0x5a04xb6][_0x5a04xb7][_0x5e86[230]]
      ) {
        if (!_0x5a04x2c[_0x5a04xb5[0]][_0x5a04xb5[1]]) {
          return _0x5a04xb5;
        } else {
          return null;
        }
      } else {
        _0x5a04xb5 = [_0x5a04xb6, _0x5a04xb7];
      }
      if (_0x5a04xb6 == _0x5a04x6b[0] && _0x5a04xb7 == _0x5a04x6b[1]) {
        break;
      }
    }
    return _0x5a04xb5;
  }
  function _0x5a04xb8(_0x5a04xb9, _0x5a04xba) {
    var _0x5a04x72 = [];
    for (var _0x5a04x60 = 0; _0x5a04x60 < 5; _0x5a04x60++) {
      var _0x5a04x73 = _0x5a04xba;
      var _0x5a04x74 = _0x5a04x60;
      if (!_0x5a04x2c[_0x5a04x73][_0x5a04x74]) {
        _0x5a04x72[_0x5e86[145]](_0x5a04x60);
      }
    }
    return _0x5a04x72;
  }
  function _0x5a04xbb() {
    var _0x5a04x72 = [];
    for (var _0x5a04x60 = 0; _0x5a04x60 < 25; _0x5a04x60++) {
      var _0x5a04x73 = Math[_0x5e86[189]](_0x5a04x60 / 5);
      var _0x5a04x74 = _0x5a04x60 - Math[_0x5e86[189]](_0x5a04x60 / 5) * 5;
      if (!_0x5a04x2c[_0x5a04x73][_0x5a04x74]) {
        _0x5a04x72[_0x5e86[145]](_0x5a04x60);
      }
    }
    return _0x5a04x72;
  }
  function _0x5a04xbc() {
    Tweener[_0x5e86[183]](
      _0x5a04x25,
      { x: 80 },
      {
        time: 20,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x25,
            { x: 188 },
            { time: 20, delay: 30 }
          );
        },
      }
    );
    Tweener[_0x5e86[183]](
      _0x5a04x26,
      { x: 435 },
      {
        time: 20,
        onComplete: function (_0x5a04x6b) {
          Tweener[_0x5e86[183]](
            _0x5a04x26,
            { x: 324 },
            { time: 20, delay: 30 }
          );
        },
      }
    );
  }
  function _0x5a04xbd() {}
  function _0x5a04xbe() {
    Tweener[_0x5e86[183]](
      _0x5a04x1e,
      { x: [0, 4, 0, -4, 0], y: [4, 0, -4, 0] },
      { time: 20 }
    );
  }
  function _0x5a04xbf(_0x5a04x9f, _0x5a04xa0, _0x5a04xc0) {
    _0x5a04xc[_0x5e86[61]][_0x5e86[162]]();
    var _0x5a04x80 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[272]);
    _0x5a04x80[_0x5e86[128]] = _0x5a04x9f - 50;
    _0x5a04x80[_0x5e86[129]] = _0x5a04xa0 + 50;
    _0x5a04x80[_0x5e86[205]] = 0;
    _0x5a04x80[_0x5e86[185]] = Math[_0x5e86[186]];
    _0x5a04x80[_0x5e86[206]] = -(1 + Math[_0x5e86[178]]() * 3);
    _0x5a04x80[_0x5e86[207]] = 12;
    _0x5a04x80[_0x5e86[144]][_0x5e86[128]] = 0.5;
    _0x5a04x80[_0x5e86[144]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[128]] = 1.5;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x80, 2);
    _0x5a04x2d[_0x5e86[145]](_0x5a04x80);
    _0x5a04xc0[_0x5e86[238]]--;
    if (_0x5a04xc0[_0x5e86[238]] && _0x5a04xc0[_0x5e86[170]]) {
      if (_0x5a04xc0[_0x5e86[238]] % 2 == 0) {
        _0x5a04xc0[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[241], false);
      } else {
        _0x5a04xc0[_0x5e86[175]][_0x5e86[174]](0, _0x5e86[242], false);
      }
      Tweener[_0x5e86[183]](
        {},
        {},
        {
          time: 25,
          onComplete: function () {
            if (_0x5a04xc0[_0x5e86[238]] % 2 == 0) {
              _0x5a04xbf(_0x5a04x9f + 90, _0x5a04xa0, _0x5a04xc0);
            } else {
              _0x5a04xbf(_0x5a04x9f - 90, _0x5a04xa0, _0x5a04xc0);
            }
          },
        }
      );
    }
  }
  function _0x5a04xc1(_0x5a04x9f, _0x5a04xa0) {
    _0x5a04xc[_0x5e86[61]][_0x5e86[162]]();
    var _0x5a04x80 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[272]);
    _0x5a04x80[_0x5e86[128]] = _0x5a04x9f - 20;
    _0x5a04x80[_0x5e86[129]] = _0x5a04xa0 + 30;
    _0x5a04x80[_0x5e86[205]] = 0;
    _0x5a04x80[_0x5e86[185]] = Math[_0x5e86[186]];
    _0x5a04x80[_0x5e86[206]] = -(1 + Math[_0x5e86[178]]() * 3);
    _0x5a04x80[_0x5e86[207]] = 12;
    _0x5a04x80[_0x5e86[144]][_0x5e86[128]] = 0.5;
    _0x5a04x80[_0x5e86[144]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[128]] = 1.5;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x80, 2);
    _0x5a04x2d[_0x5e86[145]](_0x5a04x80);
  }
  function _0x5a04xc2(_0x5a04xc3, _0x5a04xc4) {
    _0x5a04xc[_0x5e86[61]][_0x5e86[162]]();
    if (_0x5a04x1d) {
      return;
    }
    var _0x5a04x80 = new _0x5a04x13c();
    _0x5a04x80[_0x5e86[225]] = _0x5a04xc3;
    _0x5a04x80[_0x5e86[128]] = _0x5a04xc3[_0x5e86[128]] + 20;
    _0x5a04x80[_0x5e86[129]] = _0x5a04xc3[_0x5e86[129]] - 50;
    _0x5a04x80[_0x5e86[205]] = 0;
    _0x5a04x80[_0x5e86[206]] = (-_0x5a04xc4 / 100) * 4;
    _0x5a04x80[_0x5e86[207]] = 12;
    _0x5a04x80[_0x5e86[144]][_0x5e86[128]] = 0.5;
    _0x5a04x80[_0x5e86[144]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[129]] = 0.5;
    _0x5a04x80[_0x5e86[141]][_0x5e86[128]] = 1.5;
    _0x5a04x1e[_0x5e86[126]](_0x5a04x80, 10000);
    _0x5a04x2e[_0x5e86[145]](_0x5a04x80);
  }
  function _0x5a04xc5(_0x5a04x9f, _0x5a04xa0, _0x5a04xc6) {
    for (var _0x5a04xc7 = 0; _0x5a04xc7 < 20; _0x5a04xc7++) {
      var _0x5a04xc8 = new ParticleManager.Particle(
        _0x5a04xc6
          ? PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[273]]
          : PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[274]]
      );
      _0x5a04xc8[_0x5e86[128]] = _0x5a04x9f;
      _0x5a04xc8[_0x5e86[129]] = _0x5a04xa0;
      var _0x5a04xc9 = 4 + Math[_0x5e86[178]]() * 2;
      var _0x5a04xaf = Math[_0x5e86[178]]() * Math[_0x5e86[186]] * 2;
      _0x5a04xc8[_0x5e86[275]] = {
        x: Math[_0x5e86[270]](_0x5a04xaf) * _0x5a04xc9,
        y: Math[_0x5e86[271]](_0x5a04xaf) * _0x5a04xc9,
      };
      _0x5a04xc8[_0x5e86[276]] = _0x5a04xaf - Math[_0x5e86[186]] / 2;
      _0x5a04xc8[_0x5e86[277]] = 1;
      _0x5a04xc8[_0x5e86[278]] = 25;
      _0x5a04xc8[_0x5e86[279]] = 0;
      _0x5a04xc8[_0x5e86[280]] = 0.2 + Math[_0x5e86[178]]() * 0.5;
      _0x5a04xc8[_0x5e86[281]] = Math[_0x5e86[178]]() * 1;
      _0x5a04xc8[_0x5e86[282]] = { x: 0.2, y: 0.2 };
      if (_0x5a04xc6) {
        _0x5a04x1e[_0x5e86[126]](_0x5a04xc8, 50);
      } else {
        _0x5a04x1e[_0x5e86[126]](_0x5a04xc8, _0x5a04xa0);
      }
      _0x5a04x36[_0x5e86[145]](_0x5a04xc8);
      _0x5a04xc8[_0x5e86[283]]();
    }
  }
  function _0x5a04xca(_0x5a04x9f, _0x5a04xa0, _0x5a04x75) {
    var _0x5a04xcb = PIXI[_0x5e86[125]][_0x5e86[124]](
      _0x5a04x75 ? _0x5e86[284] : _0x5e86[63]
    );
    _0x5a04xcb[_0x5e86[185]] = Math[_0x5e86[178]]() * Math[_0x5e86[186]] * 2;
    _0x5a04xcb[_0x5e86[144]][_0x5e86[140]](0.5);
    _0x5a04xcb[_0x5e86[141]][_0x5e86[140]](0.2);
    _0x5a04xcb[_0x5e86[128]] = _0x5a04x9f;
    _0x5a04xcb[_0x5e86[129]] = _0x5a04xa0;
    _0x5a04xcb[_0x5e86[229]] = 0.9;
    _0x5a04x24[_0x5e86[121]](_0x5a04xcb);
    Tweener[_0x5e86[183]](
      _0x5a04xcb,
      {
        scaleX: 0.3 + Math[_0x5e86[178]]() * 0.2,
        scaleY: 0.3 + Math[_0x5e86[178]]() * 0.2,
      },
      {
        time: 5,
        transition: _0x5e86[226],
        onComplete: function (_0x5a04x6b) {
          _0x5a04xcc(_0x5a04x6b);
        },
      }
    );
  }
  function _0x5a04xcc(_0x5a04xcd) {
    _0x5a04x23[_0x5e86[158]] = false;
    _0x5a04xcd[_0x5e86[211]][_0x5e86[210]](_0x5a04xcd);
    _0x5a04x23[_0x5e86[121]](_0x5a04xcd);
    _0x5a04x23[_0x5e86[158]] = true;
  }
  function _0x5a04xce(_0x5a04x9f, _0x5a04xa0) {
    var _0x5a04x8c = [0, 0, 0, 0];
    var _0x5a04xcf = [];
    var _0x5a04xd0 = 0;
    while (
      _0x5a04x9f + _0x5a04xd0 < 4 &&
      !_0x5a04x2c[_0x5a04x9f + 1 + _0x5a04xd0][_0x5a04xa0] &&
      _0x5a04x8c[0] < 2
    ) {
      _0x5a04x8c[0]++;
      _0x5a04xd0++;
    }
    _0x5a04xd0 = 0;
    while (
      _0x5a04x9f - _0x5a04xd0 > 0 &&
      !_0x5a04x2c[_0x5a04x9f - 1 - _0x5a04xd0][_0x5a04xa0] &&
      _0x5a04x8c[1] < 2
    ) {
      _0x5a04x8c[1]++;
      _0x5a04xd0++;
    }
    _0x5a04xd0 = 0;
    while (
      _0x5a04xa0 - _0x5a04xd0 > 0 &&
      !_0x5a04x2c[_0x5a04x9f][_0x5a04xa0 - 1 - _0x5a04xd0] &&
      _0x5a04x8c[2] < 2
    ) {
      _0x5a04x8c[2]++;
      _0x5a04xd0++;
    }
    _0x5a04xd0 = 0;
    while (
      _0x5a04xa0 + _0x5a04xd0 < 4 &&
      !_0x5a04x2c[_0x5a04x9f][_0x5a04xa0 + 1 + _0x5a04xd0] &&
      _0x5a04x8c[3] < 2
    ) {
      _0x5a04x8c[3]++;
      _0x5a04xd0++;
    }
    if (_0x5a04x8c[0]) {
      _0x5a04xcf[_0x5e86[145]](0);
    }
    if (_0x5a04x8c[1]) {
      _0x5a04xcf[_0x5e86[145]](1);
    }
    if (_0x5a04x8c[2]) {
      _0x5a04xcf[_0x5e86[145]](2);
    }
    if (_0x5a04x8c[3]) {
      _0x5a04xcf[_0x5e86[145]](3);
    }
    return { directions: _0x5a04xcf, spaces: _0x5a04x8c };
  }
  function _0x5a04xd1(_0x5a04xd2, _0x5a04xd3) {}
  function _0x5a04xd4(_0x5a04xd2, _0x5a04xd3) {
    _0x5a04x42();
  }
  function _0x5a04xd5(_0x5a04x63) {
    if (_0x5a04x3b || !_0x5a04x3a || _0x5a04x39 || !_0x5a04x37) {
      return;
    }
    if (_0x5a04x3c) {
      _0x5a04x3c = false;
    }
    if (_0x5a04x133[_0x5e86[164]]) {
      _0x5a04x9b(_0x5a04x133[_0x5e86[164]]);
    }
  }
  function _0x5a04xd6(_0x5a04x63) {
    if (_0x5a04x3b || !_0x5a04x3a || _0x5a04x39 || !_0x5a04x37) {
      return;
    }
    _0x5a04x3c = true;
    _0x5a04x20[_0x5e86[219]] = 0;
    _0x5a04x21[_0x5e86[219]] = 0;
    _0x5a04x133[_0x5e86[285]][_0x5e86[128]] =
      _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[128]];
    _0x5a04x133[_0x5e86[285]][_0x5e86[129]] =
      _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[129]];
  }
  function _0x5a04xd7(_0x5a04x63) {
    if (!_0x5a04x3c || _0x5a04x3b || !_0x5a04x3a || _0x5a04x39 || !_0x5a04x37) {
      return;
    }
    if (_0x5a04x133[_0x5e86[164]]) {
      var _0x5a04xad =
        _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[128]] -
        _0x5a04x133[_0x5e86[285]][_0x5e86[128]];
      var _0x5a04xae =
        _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[129]] -
        _0x5a04x133[_0x5e86[285]][_0x5e86[129]];
      var _0x5a04xd8 = 70;
      var _0x5a04xd9 = 70;
      var _0x5a04xda = _0x5a04x133[_0x5e86[164]][_0x5e86[128]];
      var _0x5a04xdb = _0x5a04x133[_0x5e86[164]][_0x5e86[129]];
      var _0x5a04xdc = _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[128]];
      var _0x5a04xdd =
        _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[129]] - 40;
      var _0x5a04xde = _0x5a04x119(
        { x: _0x5a04xdc, y: _0x5a04xdd },
        _0x5a04x133[_0x5e86[164]]
      );
      var _0x5a04xdf = Math[_0x5e86[269]](
        _0x5a04xdb - _0x5a04xdd,
        _0x5a04xda - _0x5a04xdc
      );
      var _0x5a04xe0 = 1;
      var _0x5a04xe1 = Math[_0x5e86[288]](_0x5a04xde / _0x5a04xe0);
      var _0x5a04xe2 = {
        x: _0x5a04xda,
        y: _0x5a04xdb,
        width: _0x5a04xd8,
        height: _0x5a04xd9,
      };
      _0x5a04x133[_0x5e86[164]][_0x5e86[128]] = _0x5a04xdc;
      _0x5a04x133[_0x5e86[164]][_0x5e86[129]] = _0x5a04xdd;
      var _0x5a04xe3 = false;
      for (
        var _0x5a04x60 = 0;
        _0x5a04x60 < _0x5a04x31[_0x5e86[161]];
        _0x5a04x60++
      ) {}
      if (_0x5a04xe3) {
      } else {
      }
      if (_0x5a04x133[_0x5e86[164]][_0x5e86[128]] < 100) {
        _0x5a04x133[_0x5e86[164]][_0x5e86[128]] = 100;
      } else {
        if (_0x5a04x133[_0x5e86[164]][_0x5e86[128]] > 545) {
          _0x5a04x133[_0x5e86[164]][_0x5e86[128]] = 545;
        }
      }
      if (_0x5a04x133[_0x5e86[164]][_0x5e86[129]] < 600) {
        _0x5a04x133[_0x5e86[164]][_0x5e86[129]] = 600;
      } else {
        if (_0x5a04x133[_0x5e86[164]][_0x5e86[129]] > 1020) {
          _0x5a04x133[_0x5e86[164]][_0x5e86[129]] = 1020;
        }
      }
      _0x5a04x133[_0x5e86[164]][_0x5e86[208]] =
        _0x5a04x133[_0x5e86[164]][_0x5e86[129]];
      if (_0x5a04x133[_0x5e86[164]][_0x5e86[203]]) {
        _0x5a04x133[_0x5e86[164]][_0x5e86[209]][_0x5e86[128]] =
          _0x5a04x133[_0x5e86[164]][_0x5e86[128]];
        _0x5a04x133[_0x5e86[164]][_0x5e86[209]][_0x5e86[129]] =
          _0x5a04x133[_0x5e86[164]][_0x5e86[129]] - 5;
        _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[128]] =
          _0x5a04x133[_0x5e86[164]][_0x5e86[128]];
        _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[129]] =
          _0x5a04x133[_0x5e86[164]][_0x5e86[129]] - 5;
        _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[208]] =
          _0x5a04x133[_0x5e86[164]][_0x5e86[208]] + 1;
        _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[204]] += Math[
          _0x5e86[233]
        ](_0x5a04xda - _0x5a04xdc);
        _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[254]] += Math[
          _0x5e86[233]
        ](_0x5a04xdb - _0x5a04xdd);
        if (_0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[204]] > 50) {
          _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[204]] = 50;
        }
        if (_0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[254]] > 50) {
          _0x5a04x133[_0x5e86[164]][_0x5e86[203]][_0x5e86[254]] = 50;
        }
        Tweener[_0x5e86[183]](
          _0x5a04x133[_0x5e86[164]][_0x5e86[203]],
          { kineticX: 0, kineticY: 0 },
          {
            time: 60,
            transition: _0x5e86[257],
            onUpdate: function (_0x5a04x6b) {
              if (_0x5a04x6b[_0x5e86[204]] > _0x5a04x6b[_0x5e86[254]]) {
                _0x5a04x6b[_0x5e86[254]] = 0;
              } else {
                _0x5a04x6b[_0x5e86[204]] = 0;
              }
              var _0x5a04x98 = (_0x5a04x6b[_0x5e86[204]] / 50) * 0.2;
              var _0x5a04x99 = (_0x5a04x6b[_0x5e86[254]] / 50) * 0.2;
              _0x5a04x6b[_0x5e86[141]][_0x5e86[128]] =
                1 + _0x5a04x98 - _0x5a04x99;
              _0x5a04x6b[_0x5e86[141]][_0x5e86[129]] =
                1 - _0x5a04x98 + _0x5a04x99;
            },
          }
        );
      }
      _0x5a04x20[_0x5e86[128]] = _0x5a04x133[_0x5e86[164]][_0x5e86[128]];
      _0x5a04x20[_0x5e86[129]] = _0x5a04x133[_0x5e86[164]][_0x5e86[129]] + 20;
      _0x5a04x21[_0x5e86[128]] = _0x5a04x133[_0x5e86[164]][_0x5e86[128]] - 55;
      _0x5a04x21[_0x5e86[129]] = _0x5a04x133[_0x5e86[164]][_0x5e86[129]] - 30;
    }
    _0x5a04x133[_0x5e86[285]][_0x5e86[128]] =
      _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[128]];
    _0x5a04x133[_0x5e86[285]][_0x5e86[129]] =
      _0x5a04x63[_0x5e86[287]][_0x5e86[286]][_0x5e86[129]];
  }
  function _0x5a04xe4(_0x5a04x63) {
    if (_0x5a04x3b || !_0x5a04x3a || _0x5a04x39) {
      return;
    }
    if (!_0x5a04x3d || _0x5a04x3d != _0x5a04x63[_0x5e86[289]]) {
      _0x5a04x3d = _0x5a04x63[_0x5e86[289]];
    }
  }
  function _0x5a04xe5(_0x5a04x63) {
    if (_0x5a04x3d == _0x5a04x63[_0x5e86[289]]) {
      _0x5a04x3d = null;
    }
  }
  function _0x5a04xe6(_0x5a04xcd) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x33[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x6c = _0x5a04x33[_0x5a04x60];
      if (
        _0x5a04x6c[_0x5e86[219]] >= 50 &&
        _0x5a04xea(_0x5a04xcd, _0x5a04x6c)
      ) {
        return _0x5a04x6c;
      }
    }
  }
  function _0x5a04xe7(_0x5a04xcd) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x32[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x96 = _0x5a04x32[_0x5a04x60];
      if (_0x5a04xea(_0x5a04xcd, _0x5a04x96)) {
        return _0x5a04x96;
      }
    }
    return null;
  }
  function _0x5a04xe8(_0x5a04xcd) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x31[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04xe9 = _0x5a04x31[_0x5a04x60];
      if (_0x5a04xea(_0x5a04xcd, _0x5a04xe9)) {
        return _0x5a04xe9;
      }
    }
  }
  function _0x5a04xea(_0x5a04xeb, _0x5a04xec) {
    if (!_0x5a04xeb[_0x5e86[144]]) {
      _0x5a04xeb[_0x5e86[144]] = { x: 0, y: 0 };
    }
    if (!_0x5a04xec[_0x5e86[144]]) {
      _0x5a04xec[_0x5e86[144]] = { x: 0, y: 0 };
    }
    var _0x5a04xed = {
      x:
        _0x5a04xeb[_0x5e86[128]] -
        _0x5a04xeb[_0x5e86[109]] * _0x5a04xeb[_0x5e86[144]][_0x5e86[128]],
      y:
        _0x5a04xeb[_0x5e86[129]] -
        _0x5a04xeb[_0x5e86[110]] * _0x5a04xeb[_0x5e86[144]][_0x5e86[129]],
      width: _0x5a04xeb[_0x5e86[109]],
      height: _0x5a04xeb[_0x5e86[110]],
    };
    if (_0x5a04xeb[_0x5e86[172]]) {
      _0x5a04xed[_0x5e86[128]] += _0x5a04xeb[_0x5e86[172]][_0x5e86[128]];
      _0x5a04xed[_0x5e86[129]] += _0x5a04xeb[_0x5e86[172]][_0x5e86[129]];
      _0x5a04xed[_0x5e86[109]] = _0x5a04xeb[_0x5e86[172]][_0x5e86[109]];
      _0x5a04xed[_0x5e86[110]] = _0x5a04xeb[_0x5e86[172]][_0x5e86[110]];
    }
    var _0x5a04xee = {
      x:
        _0x5a04xec[_0x5e86[128]] -
        _0x5a04xec[_0x5e86[109]] * _0x5a04xec[_0x5e86[144]][_0x5e86[128]],
      y:
        _0x5a04xec[_0x5e86[129]] -
        _0x5a04xec[_0x5e86[110]] * _0x5a04xec[_0x5e86[144]][_0x5e86[129]],
      width: _0x5a04xec[_0x5e86[109]],
      height: _0x5a04xec[_0x5e86[110]],
    };
    if (_0x5a04xec[_0x5e86[172]]) {
      _0x5a04xee[_0x5e86[128]] += _0x5a04xec[_0x5e86[172]][_0x5e86[128]];
      _0x5a04xee[_0x5e86[129]] += _0x5a04xec[_0x5e86[172]][_0x5e86[129]];
      _0x5a04xee[_0x5e86[109]] = _0x5a04xec[_0x5e86[172]][_0x5e86[109]];
      _0x5a04xee[_0x5e86[110]] = _0x5a04xec[_0x5e86[172]][_0x5e86[110]];
    }
    if (_0x5a04xec[_0x5e86[141]][_0x5e86[128]] < 0) {
      _0x5a04xee[_0x5e86[128]] -= _0x5a04xee[_0x5e86[109]];
    }
    if (_0x5a04xec[_0x5e86[141]][_0x5e86[129]] < 0) {
      _0x5a04xee[_0x5e86[129]] -= _0x5a04xee[_0x5e86[110]];
    }
    var _0x5a04xef =
      Math[_0x5e86[233]](
        _0x5a04xed[_0x5e86[128]] +
          _0x5a04xed[_0x5e86[109]] / 2 -
          (_0x5a04xee[_0x5e86[128]] + _0x5a04xee[_0x5e86[109]] / 2)
      ) -
      (_0x5a04xed[_0x5e86[109]] / 2 + _0x5a04xee[_0x5e86[109]] / 2);
    var _0x5a04xf0 =
      Math[_0x5e86[233]](
        _0x5a04xed[_0x5e86[129]] +
          _0x5a04xed[_0x5e86[110]] / 2 -
          (_0x5a04xee[_0x5e86[129]] + _0x5a04xee[_0x5e86[110]] / 2)
      ) -
      (_0x5a04xed[_0x5e86[110]] / 2 + _0x5a04xee[_0x5e86[110]] / 2);
    if (_0x5a04xef < 0 && _0x5a04xf0 < 0) {
      return { dx: -_0x5a04xef, dy: -_0x5a04xf0 };
    } else {
      return false;
    }
  }
  function _0x5a04xf1(_0x5a04xed, _0x5a04xee) {
    return !(
      _0x5a04xee[_0x5e86[128]] >
        _0x5a04xed[_0x5e86[128]] + _0x5a04xed[_0x5e86[109]] ||
      _0x5a04xee[_0x5e86[128]] + _0x5a04xee[_0x5e86[109]] <
        _0x5a04xed[_0x5e86[128]] ||
      _0x5a04xee[_0x5e86[129]] >
        _0x5a04xed[_0x5e86[129]] + _0x5a04xed[_0x5e86[110]] ||
      _0x5a04xee[_0x5e86[129]] + _0x5a04xee[_0x5e86[110]] <
        _0x5a04xed[_0x5e86[129]]
    );
  }
  function _0x5a04xf2(
    _0x5a04xf3,
    _0x5a04xf4,
    _0x5a04xf5,
    _0x5a04xf6,
    _0x5a04xf7,
    _0x5a04xf8,
    _0x5a04xf9,
    _0x5a04xfa
  ) {
    let _0x5a04xfb = _0x5a04xfe(
      _0x5a04xf3,
      _0x5a04xf4,
      _0x5a04xf5,
      _0x5a04xf6,
      _0x5a04xf7,
      _0x5a04xf8,
      _0x5a04xf7,
      _0x5a04xf8 + _0x5a04xfa
    );
    let _0x5a04x8b = _0x5a04xfe(
      _0x5a04xf3,
      _0x5a04xf4,
      _0x5a04xf5,
      _0x5a04xf6,
      _0x5a04xf7 + _0x5a04xf9,
      _0x5a04xf8,
      _0x5a04xf7 + _0x5a04xf9,
      _0x5a04xf8 + _0x5a04xfa
    );
    let _0x5a04xfc = _0x5a04xfe(
      _0x5a04xf3,
      _0x5a04xf4,
      _0x5a04xf5,
      _0x5a04xf6,
      _0x5a04xf7,
      _0x5a04xf8,
      _0x5a04xf7 + _0x5a04xf9,
      _0x5a04xf8
    );
    let _0x5a04xfd = _0x5a04xfe(
      _0x5a04xf3,
      _0x5a04xf4,
      _0x5a04xf5,
      _0x5a04xf6,
      _0x5a04xf7,
      _0x5a04xf8 + _0x5a04xfa,
      _0x5a04xf7 + _0x5a04xf9,
      _0x5a04xf8 + _0x5a04xfa
    );
    if (_0x5a04xfb || _0x5a04x8b || _0x5a04xfc || _0x5a04xfd) {
      return true;
    }
    return false;
  }
  function _0x5a04xfe(
    _0x5a04xf3,
    _0x5a04xf4,
    _0x5a04xf5,
    _0x5a04xf6,
    _0x5a04xff,
    _0x5a04x100,
    _0x5a04x101,
    _0x5a04x102
  ) {
    let _0x5a04x103 =
      ((_0x5a04x101 - _0x5a04xff) * (_0x5a04xf4 - _0x5a04x100) -
        (_0x5a04x102 - _0x5a04x100) * (_0x5a04xf3 - _0x5a04xff)) /
      ((_0x5a04x102 - _0x5a04x100) * (_0x5a04xf5 - _0x5a04xf3) -
        (_0x5a04x101 - _0x5a04xff) * (_0x5a04xf6 - _0x5a04xf4));
    let _0x5a04x104 =
      ((_0x5a04xf5 - _0x5a04xf3) * (_0x5a04xf4 - _0x5a04x100) -
        (_0x5a04xf6 - _0x5a04xf4) * (_0x5a04xf3 - _0x5a04xff)) /
      ((_0x5a04x102 - _0x5a04x100) * (_0x5a04xf5 - _0x5a04xf3) -
        (_0x5a04x101 - _0x5a04xff) * (_0x5a04xf6 - _0x5a04xf4));
    if (
      _0x5a04x103 >= 0 &&
      _0x5a04x103 <= 1 &&
      _0x5a04x104 >= 0 &&
      _0x5a04x104 <= 1
    ) {
      return true;
    }
    return false;
  }
  function _0x5a04x105(_0x5a04x6b) {
    Tweener[_0x5e86[227]](_0x5a04x6b);
    if (_0x5a04x6b[_0x5e86[290]]) {
      _0x5a04x13d[_0x5e86[291]](_0x5a04x6b[_0x5e86[290]]);
    }
    if (_0x5a04x6b[_0x5e86[211]]) {
      _0x5a04x6b[_0x5e86[211]][_0x5e86[210]](_0x5a04x6b);
    }
    delete _0x5a04x6b;
  }
  function _0x5a04x106(_0x5a04x7c, _0x5a04x107, _0x5a04x108) {
    var _0x5a04x109 = _0x5a04x7c[_0x5e86[220]](_0x5a04x107);
    if (_0x5a04x109 > -1) {
      _0x5a04x7c[_0x5e86[188]](_0x5a04x109, 1);
      if (_0x5a04x108) {
        return;
      }
      if (_0x5a04x107[_0x5e86[211]]) {
        var _0x5a04x10a = _0x5a04x107[_0x5e86[211]];
        _0x5a04x10a[_0x5e86[210]](_0x5a04x107);
      }
    }
    _0x5a04x107[_0x5e86[218]]();
  }
  function _0x5a04x10b(_0x5a04x7c) {
    if (!_0x5a04x7c) {
      return [];
    }
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x10c = _0x5a04x7c[_0x5a04x60];
      if (_0x5a04x10c[_0x5e86[211]]) {
        _0x5a04x10c[_0x5e86[211]][_0x5e86[210]](_0x5a04x10c);
      }
      Tweener[_0x5e86[227]](_0x5a04x10c);
      _0x5a04x10c[_0x5e86[218]]();
    }
    _0x5a04x7c = [];
    return [];
  }
  function _0x5a04x10d(_0x5a04x10e, _0x5a04x10f) {
    let _0x5a04x110 = _0x5a04x10f[0] - _0x5a04x10e[0];
    let _0x5a04x111 = _0x5a04x10f[1] - _0x5a04x10e[1];
    return {
      length: Math[_0x5e86[293]](
        Math[_0x5e86[292]](_0x5a04x110, 2) + Math[_0x5e86[292]](_0x5a04x111, 2)
      ),
      angle: Math[_0x5e86[269]](_0x5a04x111, _0x5a04x110),
    };
  }
  function _0x5a04x112(_0x5a04x7c) {
    if (_0x5a04x7c[_0x5e86[161]] < 2) {
      return 0;
    }
    var _0x5a04x113 = 0;
    var _0x5a04x114 = Math[_0x5e86[269]](
      _0x5a04x7c[1][_0x5e86[129]] - _0x5a04x7c[0][_0x5e86[129]],
      _0x5a04x7c[1][_0x5e86[128]] - _0x5a04x7c[0][_0x5e86[128]]
    );
    for (
      var _0x5a04x60 = 1;
      _0x5a04x60 < _0x5a04x7c[_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x115 = _0x5a04x7c[_0x5a04x60 - 1];
      var _0x5a04x116 = _0x5a04x7c[_0x5a04x60];
      var _0x5a04x117 = Math[_0x5e86[269]](
        _0x5a04x116[_0x5e86[129]] - _0x5a04x115[_0x5e86[129]],
        _0x5a04x116[_0x5e86[128]] - _0x5a04x115[_0x5e86[128]]
      );
      var _0x5a04x118 = _0x5a04x117 - _0x5a04x114;
      _0x5a04x118 =
        ((_0x5a04x118 + Math[_0x5e86[186]]) % (Math[_0x5e86[186]] * 2)) -
        Math[_0x5e86[186]];
      _0x5a04x113 += _0x5a04x118;
      _0x5a04x114 = _0x5a04x117;
    }
    return _0x5a04x113;
  }
  function _0x5a04x119(_0x5a04x11a, _0x5a04x11b) {
    var _0x5a04xef = _0x5a04x11a[_0x5e86[128]] - _0x5a04x11b[_0x5e86[128]];
    var _0x5a04xf0 = _0x5a04x11a[_0x5e86[129]] - _0x5a04x11b[_0x5e86[129]];
    return Math[_0x5e86[293]](
      _0x5a04xef * _0x5a04xef + _0x5a04xf0 * _0x5a04xf0
    );
  }
  var _0x5a04x11c = (function () {
    const _0x5a04x11d = 1e100;
    let _0x5a04x11e = [],
      _0x5a04x11f = [];
    let _0x5a04x120 = 0;
    function _0x5a04x121(_0x5a04x122, _0x5a04x123) {
      if (_0x5a04x122[_0x5e86[208]] > _0x5a04x123[_0x5e86[208]]) {
        return 1;
      }
      if (_0x5a04x122[_0x5e86[208]] < _0x5a04x123[_0x5e86[208]]) {
        return -1;
      }
      if (_0x5a04x122[_0x5e86[294]] > _0x5a04x123[_0x5e86[294]]) {
        return 1;
      }
      if (_0x5a04x122[_0x5e86[294]] < _0x5a04x123[_0x5e86[294]]) {
        return -1;
      }
      return 0;
    }
    function _0x5a04x11c() {
      PIXI[_0x5e86[296]][_0x5e86[295]](this);
      this[_0x5e86[126]] = function (_0x5a04x10c, _0x5a04x124) {
        _0x5a04x10c[_0x5e86[208]] = _0x5a04x124 || 0;
        _0x5a04x10c[_0x5e86[297]] = _0x5a04x11d;
        _0x5a04x10c[_0x5e86[294]] = ++_0x5a04x120;
        this[_0x5e86[121]](_0x5a04x10c);
      };
      this[_0x5e86[250]] = function () {
        const _0x5a04x125 = this[_0x5e86[160]];
        let _0x5a04x126 = _0x5a04x125[_0x5e86[161]];
        for (let _0x5a04x60 = 0; _0x5a04x60 < _0x5a04x126; _0x5a04x60++) {
          const _0x5a04x127 = _0x5a04x125[_0x5a04x60];
          if (_0x5a04x127[_0x5e86[208]] !== _0x5a04x127[_0x5e86[297]]) {
            _0x5a04x11e[_0x5e86[145]](_0x5a04x127);
          } else {
            _0x5a04x11f[_0x5e86[145]](_0x5a04x127);
          }
          _0x5a04x127[_0x5e86[297]] = _0x5a04x127[_0x5e86[208]];
        }
        if (_0x5a04x11e[_0x5e86[161]] === 0) {
          _0x5a04x11f[_0x5e86[161]] = 0;
          return;
        }
        if (_0x5a04x11e[_0x5e86[161]] > 1) {
          _0x5a04x11e[_0x5e86[298]](_0x5a04x121);
        }
        let _0x5a04x61 = 0,
          _0x5a04x122 = 0,
          _0x5a04x123 = 0;
        while (
          _0x5a04x122 < _0x5a04x11e[_0x5e86[161]] &&
          _0x5a04x123 < _0x5a04x11f[_0x5e86[161]]
        ) {
          if (
            _0x5a04x121(_0x5a04x11e[_0x5a04x122], _0x5a04x11f[_0x5a04x123]) < 0
          ) {
            _0x5a04x125[_0x5a04x61++] = _0x5a04x11e[_0x5a04x122++];
          } else {
            _0x5a04x125[_0x5a04x61++] = _0x5a04x11f[_0x5a04x123++];
          }
        }
        while (_0x5a04x122 < _0x5a04x11e[_0x5e86[161]]) {
          _0x5a04x125[_0x5a04x61++] = _0x5a04x11e[_0x5a04x122++];
        }
        while (_0x5a04x123 < _0x5a04x11f[_0x5e86[161]]) {
          _0x5a04x125[_0x5a04x61++] = _0x5a04x11f[_0x5a04x123++];
        }
        _0x5a04x11e[_0x5e86[161]] = 0;
        _0x5a04x11f[_0x5e86[161]] = 0;
      };
    }
    _0x5a04x11c[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[296]][_0x5e86[299]]
    );
    return _0x5a04x11c;
  })();
  var _0x5a04x128 = (function () {
    function _0x5a04x129(_0x5a04x12a) {
      PIXI[_0x5e86[125]][_0x5e86[295]](
        this,
        PIXI[_0x5e86[113]][_0x5e86[215]][_0x5a04x12a]
      );
      this[_0x5e86[172]] = {
        x: 0,
        y: 0,
        width: this[_0x5e86[109]],
        height: this[_0x5e86[110]],
      };
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[125]][_0x5e86[299]]
    );
    return _0x5a04x129;
  })();
  var ParticleManager = (function () {
    var _0x5a04x6 = {};
    _0x5a04x6[_0x5e86[201]] = function () {};
    var _0x5a04x12c = function (_0x5a04x12a, _0x5a04x12d) {
      this[_0x5e86[301]] = _0x5a04x12d;
      this[_0x5e86[275]] = { x: 0, y: 0 };
      this[_0x5e86[302]] = { x: 0, y: 0 };
      this[_0x5e86[276]] = 0;
      this[_0x5e86[303]] = 0;
      this[_0x5e86[280]] = 1;
      this[_0x5e86[304]] = { r: 255, g: 255, b: 255 };
      this[_0x5e86[277]] = 1;
      this[_0x5e86[278]] = 100;
      this[_0x5e86[305]] = 0;
      this[_0x5e86[306]] = 1;
      this[_0x5e86[307]] = { r: 255, g: 255, b: 255 };
      this[_0x5e86[308]] = { x: 0, y: 0 };
      this[_0x5e86[309]] = false;
      this[_0x5e86[310]] = false;
      this[_0x5e86[311]] = false;
      this[_0x5e86[312]] = false;
      this[_0x5e86[313]] = 0;
      this[_0x5e86[314]] = null;
      this[_0x5e86[315]] = 1;
      this[_0x5e86[316]] = 1;
      this[_0x5e86[317]] = { x: 0, y: 0 };
      this[_0x5e86[318]] = 0;
      this[_0x5e86[283]]();
      PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
      this[_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[144]][_0x5e86[129]] = 0.5;
    };
    _0x5a04x12c[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[125]][_0x5e86[299]]
    );
    _0x5a04x12c[_0x5e86[299]][_0x5e86[283]] = function () {
      this[_0x5e86[313]] = 0;
      this[_0x5e86[317]][_0x5e86[128]] = this[_0x5e86[275]][_0x5e86[128]];
      this[_0x5e86[317]][_0x5e86[129]] = this[_0x5e86[275]][_0x5e86[129]];
      this[_0x5e86[318]] = this[_0x5e86[276]];
    };
    _0x5a04x12c[_0x5e86[299]][_0x5e86[319]] = function () {
      this[_0x5e86[313]] = 0;
      this[_0x5e86[317]][_0x5e86[128]] = this[_0x5e86[275]][_0x5e86[128]];
      this[_0x5e86[317]][_0x5e86[129]] = this[_0x5e86[275]][_0x5e86[129]];
      this[_0x5e86[318]] = this[_0x5e86[276]];
    };
    var _0x5a04x12e = function (_0x5a04x7e) {
      if (_0x5a04x7e <= 0.15) {
        return -6.666 * _0x5a04x7e + 1.0;
      }
      return _0x5a04x7e;
    };
    _0x5a04x12c[_0x5e86[299]][_0x5e86[201]] = function (_0x5a04x12f) {
      this[_0x5e86[313]] += _0x5a04x12f;
      if (this[_0x5e86[313]] >= this[_0x5e86[278]]) {
        this[_0x5e86[320]]();
        return -1;
      }
      var _0x5a04x7e = this[_0x5e86[313]] / this[_0x5e86[278]];
      if (this[_0x5e86[314]]) {
        _0x5a04x7e = this._ease(_0x5a04x7e);
      }
      if (this[_0x5e86[312]]) {
        this[_0x5e86[315]] =
          (this[_0x5e86[305]] - this[_0x5e86[277]]) * _0x5a04x7e +
          this[_0x5e86[277]];
      }
      if (this[_0x5e86[311]]) {
        this[_0x5e86[316]] =
          (this[_0x5e86[306]] - this[_0x5e86[280]]) * _0x5a04x7e +
          this[_0x5e86[280]];
      }
      if (this[_0x5e86[310]]) {
        if (
          this[_0x5e86[317]][_0x5e86[128]] < this[_0x5e86[302]][_0x5e86[128]]
        ) {
          this[_0x5e86[317]][_0x5e86[128]] +=
            this[_0x5e86[308]][_0x5e86[128]] * _0x5a04x12f;
        } else {
          if (
            this[_0x5e86[317]][_0x5e86[128]] > this[_0x5e86[302]][_0x5e86[128]]
          ) {
            this[_0x5e86[317]][_0x5e86[128]] -=
              this[_0x5e86[308]][_0x5e86[128]] * _0x5a04x12f;
          }
        }
        if (
          this[_0x5e86[317]][_0x5e86[129]] < this[_0x5e86[302]][_0x5e86[129]]
        ) {
          this[_0x5e86[317]][_0x5e86[129]] +=
            this[_0x5e86[308]][_0x5e86[129]] * _0x5a04x12f;
        } else {
          if (
            this[_0x5e86[317]][_0x5e86[129]] > this[_0x5e86[302]][_0x5e86[129]]
          ) {
            this[_0x5e86[317]][_0x5e86[129]] -=
              this[_0x5e86[308]][_0x5e86[129]] * _0x5a04x12f;
          }
        }
      }
      if (this[_0x5e86[309]]) {
        var _0x5a04x130 = _0x5a04x7e;
        var _0x5a04x92 =
          Math[_0x5e86[187]](
            (this[_0x5e86[307]][_0x5e86[321]] -
              this[_0x5e86[304]][_0x5e86[321]]) *
              _0x5a04x130
          ) + this[_0x5e86[304]][_0x5e86[321]];
        var _0x5a04x131 =
          Math[_0x5e86[187]](
            (this[_0x5e86[307]][_0x5e86[322]] -
              this[_0x5e86[304]][_0x5e86[322]]) *
              _0x5a04x130
          ) + this[_0x5e86[304]][_0x5e86[322]];
        var _0x5a04x123 =
          Math[_0x5e86[187]](
            (this[_0x5e86[307]][_0x5e86[323]] -
              this[_0x5e86[304]][_0x5e86[323]]) *
              _0x5a04x130
          ) + this[_0x5e86[304]][_0x5e86[323]];
        this[_0x5e86[324]] = ColorMath.ToHex(
          _0x5a04x92,
          _0x5a04x131,
          _0x5a04x123
        );
      }
      if (this[_0x5e86[303]]) {
        this[_0x5e86[318]] += this[_0x5e86[303]];
      }
      this[_0x5e86[325]]();
      return _0x5a04x7e;
    };
    _0x5a04x12c[_0x5e86[299]][_0x5e86[325]] = function () {
      this[_0x5e86[128]] += this[_0x5e86[317]][_0x5e86[128]];
      this[_0x5e86[129]] += this[_0x5e86[317]][_0x5e86[129]];
      this[_0x5e86[185]] = this[_0x5e86[318]];
      this[_0x5e86[229]] = this[_0x5e86[315]];
      this[_0x5e86[326]] = this[_0x5e86[324]];
      this[_0x5e86[141]][_0x5e86[128]] = this[_0x5e86[141]][
        _0x5e86[129]
      ] = this[_0x5e86[316]];
    };
    _0x5a04x12c[_0x5e86[299]][_0x5e86[320]] = function () {
      if (this[_0x5e86[211]]) {
        this[_0x5e86[211]][_0x5e86[210]](this);
      }
      this[_0x5e86[218]]();
    };
    Object[_0x5e86[328]](_0x5a04x12c[_0x5e86[299]], {
      endColor: {
        set: function (_0x5a04x132) {
          this[_0x5e86[307]] = _0x5a04x132;
          if (_0x5a04x132 != _0x5e86[327]) {
            this[_0x5e86[309]] = true;
          }
        },
      },
      acceleration: {
        get: function () {
          return this[_0x5e86[308]];
        },
        set: function (_0x5a04x132) {
          this[_0x5e86[308]] = _0x5a04x132;
          if (
            _0x5a04x132[_0x5e86[128]] != 0 ||
            _0x5a04x132[_0x5e86[129]] != 0
          ) {
            this[_0x5e86[310]] = true;
          }
        },
      },
      endSize: {
        set: function (_0x5a04x132) {
          this[_0x5e86[306]] = _0x5a04x132;
          this[_0x5e86[311]] = true;
        },
      },
      endAlpha: {
        set: function (_0x5a04x132) {
          this[_0x5e86[305]] = _0x5a04x132;
          this[_0x5e86[312]] = true;
        },
      },
    });
    _0x5a04x6[_0x5e86[329]] = _0x5a04x12c;
    return _0x5a04x6;
  })();
  var _0x5a04x133 = (function () {
    var _0x5a04x6 = { startPoint: { x: 0, y: 0 }, target: null };
    return _0x5a04x6;
  })();
  var _0x5a04x134 = (function () {
    function _0x5a04x129(_0x5a04x79) {
      PIXI[_0x5e86[296]][_0x5e86[295]](this);
      this[_0x5e86[330]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[330]);
      this[_0x5e86[330]][_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[121]](this[_0x5e86[330]]);
      this[_0x5e86[331]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5a04x79);
      this[_0x5e86[331]][_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[331]][_0x5e86[144]][_0x5e86[129]] = 1;
      this[_0x5e86[331]][_0x5e86[129]] = 10;
      this[_0x5e86[121]](this[_0x5e86[331]]);
      this[_0x5e86[164]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[332]);
      this[_0x5e86[164]][_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[164]][_0x5e86[144]][_0x5e86[129]] = 0.5;
      this[_0x5e86[164]][_0x5e86[129]] = -8;
      this[_0x5e86[121]](this[_0x5e86[164]]);
      this[_0x5e86[172]] = {};
      this[_0x5e86[172]][_0x5e86[128]] =
        -(this[_0x5e86[331]][_0x5e86[109]] + 20) / 2;
      this[_0x5e86[172]][_0x5e86[129]] = -this[_0x5e86[331]][_0x5e86[110]] * 2;
      this[_0x5e86[172]][_0x5e86[109]] = this[_0x5e86[331]][_0x5e86[109]] + 20;
      this[_0x5e86[172]][_0x5e86[110]] = this[_0x5e86[331]][_0x5e86[110]];
      this[_0x5e86[333]] = 0;
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[296]][_0x5e86[299]]
    );
    Object[_0x5e86[334]](_0x5a04x129[_0x5e86[299]], _0x5e86[205], {
      set: function (_0x5a04x132) {
        this[_0x5e86[331]][_0x5e86[129]] += this[_0x5e86[333]] - _0x5a04x132;
        this[_0x5e86[333]] = _0x5a04x132;
        this[_0x5e86[330]][_0x5e86[129]] = _0x5a04x132;
        this[_0x5e86[164]][_0x5e86[129]] =
          this[_0x5e86[331]][_0x5e86[129]] - 18;
        this[_0x5e86[164]][_0x5e86[141]][_0x5e86[140]](0.8 + _0x5a04x132 / 30);
      },
      get: function () {
        return this[_0x5e86[333]];
      },
      enumerable: true,
      configurable: true,
    });
    return _0x5a04x129;
  })();
  var _0x5a04x135 = (function () {
    function _0x5a04x129() {
      PIXI[_0x5e86[296]][_0x5e86[295]](this);
      this[_0x5e86[230]] = false;
      this[_0x5e86[180]] = true;
      var _0x5a04x136 = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[335]);
      _0x5a04x136[_0x5e86[128]] = -6;
      _0x5a04x136[_0x5e86[129]] = -22;
      this[_0x5e86[121]](_0x5a04x136);
      this[_0x5e86[330]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[336]);
      this[_0x5e86[121]](this[_0x5e86[330]]);
      this[_0x5e86[337]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[338]);
      this[_0x5e86[121]](this[_0x5e86[337]]);
      this[_0x5e86[337]][_0x5e86[134]] = new PIXI.Graphics();
      this[_0x5e86[337]][_0x5e86[121]](this[_0x5e86[337]][_0x5e86[134]]);
      this[_0x5e86[172]] = {};
      this[_0x5e86[172]][_0x5e86[128]] = 0;
      this[_0x5e86[172]][_0x5e86[129]] = -53;
      this[_0x5e86[172]][_0x5e86[109]] = 152;
      this[_0x5e86[172]][_0x5e86[110]] = 30;
      this[_0x5e86[339]] = 0;
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[296]][_0x5e86[299]]
    );
    _0x5a04x129[_0x5e86[299]][_0x5e86[231]] = function () {
      this[_0x5e86[230]] = true;
      Tweener[_0x5e86[183]](
        this,
        { percent: 100 },
        { time: 30, transition: _0x5e86[217] }
      );
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[179]] = function () {
      this[_0x5e86[230]] = false;
      Tweener[_0x5e86[183]](
        this,
        { percent: 0 },
        { time: 30, transition: _0x5e86[217] }
      );
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[340]] = function (_0x5a04x132) {
      this[_0x5e86[339]] = _0x5a04x132;
      this[_0x5e86[341]]();
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[341]] = function () {
      let _0x5a04xd8 = 152;
      let _0x5a04xd9 = 13 + (this[_0x5e86[339]] / 100) * 60;
      let _0x5a04x73 = 0;
      let _0x5a04x74 = 0;
      this[_0x5e86[337]][_0x5e86[129]] = -_0x5a04xd9;
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[342]]();
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[132]](0xff0000);
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[133]](
        _0x5a04x73,
        _0x5a04x74,
        _0x5a04xd8,
        _0x5a04xd9
      );
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[343]]();
      this[_0x5e86[330]][_0x5e86[110]] = _0x5a04xd9 - 13;
    };
    Object[_0x5e86[334]](_0x5a04x129[_0x5e86[299]], _0x5e86[219], {
      set: function (_0x5a04x132) {
        this[_0x5e86[339]] = _0x5a04x132;
        if (this[_0x5e86[339]] > 100) {
          this[_0x5e86[339]] = 100;
        }
        this[_0x5e86[341]]();
      },
      get: function () {
        return this[_0x5e86[339]];
      },
      enumerable: true,
      configurable: true,
    });
    return _0x5a04x129;
  })();
  var _0x5a04x137 = (function () {
    function _0x5a04x129() {
      PIXI[_0x5e86[296]][_0x5e86[295]](this);
      this[_0x5e86[344]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[345]);
      this[_0x5e86[121]](this[_0x5e86[344]]);
      this[_0x5e86[337]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[346]);
      this[_0x5e86[337]][_0x5e86[128]] = 15;
      this[_0x5e86[337]][_0x5e86[129]] = 10;
      this[_0x5e86[121]](this[_0x5e86[337]]);
      this[_0x5e86[347]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[348]);
      this[_0x5e86[347]][_0x5e86[128]] = -50;
      this[_0x5e86[347]][_0x5e86[129]] = -18;
      this[_0x5e86[121]](this[_0x5e86[347]]);
      this[_0x5e86[337]][_0x5e86[134]] = new PIXI.Graphics();
      this[_0x5e86[337]][_0x5e86[121]](this[_0x5e86[337]][_0x5e86[134]]);
      this[_0x5e86[339]] = 0;
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[296]][_0x5e86[299]]
    );
    _0x5a04x129[_0x5e86[299]][_0x5e86[340]] = function (_0x5a04x132) {
      this[_0x5e86[339]] = _0x5a04x132;
      this[_0x5e86[341]]();
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[341]] = function () {
      let _0x5a04xd8 = (this[_0x5e86[339]] / 100) * 290;
      let _0x5a04xd9 = 50;
      let _0x5a04x73 = 35;
      let _0x5a04x74 = 0;
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[342]]();
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[132]](0xff0000);
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[133]](
        _0x5a04x73,
        _0x5a04x74,
        _0x5a04xd8,
        _0x5a04xd9
      );
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[343]]();
    };
    Object[_0x5e86[334]](_0x5a04x129[_0x5e86[299]], _0x5e86[219], {
      set: function (_0x5a04x132) {
        this[_0x5e86[339]] = _0x5a04x132;
        if (this[_0x5e86[339]] > 100) {
          this[_0x5e86[339]] = 100;
        }
        this[_0x5e86[341]]();
      },
      get: function () {
        return this[_0x5e86[339]];
      },
      enumerable: true,
      configurable: true,
    });
    return _0x5a04x129;
  })();
  var _0x5a04x138 = (function () {
    function _0x5a04x129() {
      PIXI[_0x5e86[296]][_0x5e86[295]](this);
      this[_0x5e86[344]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[349]);
      this[_0x5e86[121]](this[_0x5e86[344]]);
      this[_0x5e86[344]][_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[344]][_0x5e86[144]][_0x5e86[129]] = 1;
      this[_0x5e86[344]][_0x5e86[129]] = 4;
      this[_0x5e86[337]] = PIXI[_0x5e86[125]][_0x5e86[124]](_0x5e86[350]);
      this[_0x5e86[121]](this[_0x5e86[337]]);
      this[_0x5e86[337]][_0x5e86[144]][_0x5e86[128]] = 0.5;
      this[_0x5e86[337]][_0x5e86[144]][_0x5e86[129]] = 1;
      this[_0x5e86[337]][_0x5e86[134]] = new PIXI.Graphics();
      this[_0x5e86[337]][_0x5e86[121]](this[_0x5e86[337]][_0x5e86[134]]);
      this[_0x5e86[339]] = 0;
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[296]][_0x5e86[299]]
    );
    _0x5a04x129[_0x5e86[299]][_0x5e86[340]] = function (_0x5a04x132) {
      this[_0x5e86[339]] = _0x5a04x132;
      this[_0x5e86[341]]();
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[341]] = function () {
      if (!this[_0x5e86[339]]) {
        this[_0x5e86[138]] = false;
        return;
      } else {
        this[_0x5e86[138]] = true;
      }
      this[_0x5e86[141]][_0x5e86[140]](0.5 + this[_0x5e86[339]] / 200);
      let _0x5a04xd8 = 25;
      let _0x5a04xd9 = (this[_0x5e86[339]] / 100) * 106;
      let _0x5a04x73 = -_0x5a04xd8 / 2;
      let _0x5a04x74 = -_0x5a04xd9;
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[342]]();
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[132]](0xff0000);
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[133]](
        _0x5a04x73,
        _0x5a04x74,
        _0x5a04xd8,
        _0x5a04xd9
      );
      this[_0x5e86[337]][_0x5e86[134]][_0x5e86[343]]();
    };
    Object[_0x5e86[334]](_0x5a04x129[_0x5e86[299]], _0x5e86[219], {
      set: function (_0x5a04x132) {
        this[_0x5e86[339]] = _0x5a04x132;
        if (this[_0x5e86[339]] > 100) {
          this[_0x5e86[339]] = 100;
        }
        this[_0x5e86[341]]();
      },
      get: function () {
        return this[_0x5e86[339]];
      },
      enumerable: true,
      configurable: true,
    });
    return _0x5a04x129;
  })();
  var _0x5a04x139 = (function () {
    function _0x5a04x129() {
      var _0x5a04x12a = PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[351]];
      PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
      this[_0x5e86[144]][_0x5e86[140]](0.5);
      this[_0x5e86[134]] = new PIXI.Graphics();
      this[_0x5e86[121]](this[_0x5e86[134]]);
      this[_0x5e86[339]] = 0;
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[125]][_0x5e86[299]]
    );
    _0x5a04x129[_0x5e86[299]][_0x5e86[340]] = function (_0x5a04x132) {
      this[_0x5e86[339]] = _0x5a04x132;
      this[_0x5e86[341]]();
    };
    _0x5a04x129[_0x5e86[299]][_0x5e86[341]] = function () {
      var _0x5a04x117 = (2 * Math[_0x5e86[186]] * this[_0x5e86[339]]) / 100;
      var _0x5a04x13a = 70 / 2;
      var _0x5a04x13b = Math[_0x5e86[293]](
        Math[_0x5e86[292]](70, 2) + Math[_0x5e86[292]](70, 2)
      );
      var _0x5a04xf3 = Math[_0x5e86[270]](0) * _0x5a04x13a;
      var _0x5a04xf4 = Math[_0x5e86[271]](0) * _0x5a04x13a;
      var _0x5a04xf5 = Math[_0x5e86[270]](_0x5a04x117) * _0x5a04x13a;
      var _0x5a04xf6 = Math[_0x5e86[271]](_0x5a04x117) * _0x5a04x13a;
      this[_0x5e86[134]][_0x5e86[342]]();
      this[_0x5e86[134]][_0x5e86[132]](0xff0000);
      this[_0x5e86[134]][_0x5e86[352]](0, 0);
      this[_0x5e86[134]][_0x5e86[353]](
        0,
        0,
        _0x5a04x13a,
        0,
        _0x5a04x117,
        false
      );
      this[_0x5e86[134]][_0x5e86[343]]();
    };
    Object[_0x5e86[334]](_0x5a04x129[_0x5e86[299]], _0x5e86[219], {
      set: function (_0x5a04x132) {
        this[_0x5e86[339]] = _0x5a04x132;
        if (this[_0x5e86[339]] > 100) {
          this[_0x5e86[339]] = 100;
        }
        this[_0x5e86[341]]();
      },
      get: function () {
        return this[_0x5e86[339]];
      },
      enumerable: true,
      configurable: true,
    });
    return _0x5a04x129;
  })();
  var _0x5a04x13c = (function () {
    function _0x5a04x129() {
      var _0x5a04x12a = PIXI[_0x5e86[113]][_0x5e86[215]][_0x5e86[354]];
      PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
    }
    _0x5a04x129[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[125]][_0x5e86[299]]
    );
    return _0x5a04x129;
  })();
  var _0x5a04x13d = (function () {
    _0x5e86[355];
    var _0x5a04x13e = {};
    var _0x5a04x6 = {
      add: function (_0x5a04x79, _0x5a04x13f, _0x5a04x140) {
        _0x5a04x13e[_0x5a04x79] = _0x5a04x13f;
        _0x5a04x13f[_0x5e86[356]] = _0x5a04x140;
      },
      remove: function (_0x5a04x79) {
        if (!_0x5a04x79 || !_0x5a04x13e[_0x5a04x79]) {
          return;
        }
        _0x5a04x13e[_0x5a04x79] = null;
        delete _0x5a04x13e[_0x5a04x79];
      },
      update: function (_0x5a04x7b) {
        for (var _0x5a04x79 in _0x5a04x13e) {
          if (
            _0x5a04x13e[_0x5a04x79] &&
            _0x5a04x13e[_0x5a04x79][_0x5e86[357]]
          ) {
            _0x5a04x13e[_0x5a04x79][_0x5e86[201]](_0x5a04x7b);
          } else {
            if (_0x5a04x13e[_0x5a04x79][_0x5e86[356]]) {
              if (_0x5a04x13e[_0x5a04x79][_0x5e86[211]]) {
                _0x5a04x13e[_0x5a04x79][_0x5e86[211]][_0x5e86[210]](
                  _0x5a04x13e[_0x5a04x79]
                );
              }
              this[_0x5e86[291]](_0x5a04x79);
            }
          }
        }
      },
    };
    return _0x5a04x6;
  })();
  var _0x5a04x141 = (function () {
    _0x5e86[355];
    function _0x5a04x141(_0x5a04x12a) {
      PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
      this[_0x5e86[152]] = true;
      this[_0x5e86[169]] = true;
      this[_0x5e86[358]] = false;
      this[_0x5e86[359]] = false;
      this[_0x5e86[360]] = false;
      this[_0x5e86[361]] = false;
      this[_0x5e86[362]] = _0x5a04x12a;
      this[_0x5e86[87]](_0x5e86[155], this[_0x5e86[369]])
        [_0x5e86[87]](_0x5e86[153], this[_0x5e86[368]])
        [_0x5e86[87]](_0x5e86[367], this[_0x5e86[368]])
        [_0x5e86[87]](_0x5e86[365], this[_0x5e86[366]])
        [_0x5e86[87]](_0x5e86[363], this[_0x5e86[364]]);
    }
    _0x5a04x141[_0x5e86[299]] = Object[_0x5e86[300]](
      PIXI[_0x5e86[125]][_0x5e86[299]]
    );
    _0x5a04x141[_0x5e86[299]][_0x5e86[368]] = function () {
      if (this[_0x5e86[360]]) {
        this[_0x5e86[361]] = !this[_0x5e86[361]];
      }
      if (!this[_0x5e86[361]]) {
        this[_0x5e86[370]] = false;
        this[_0x5e86[213]] = this[_0x5e86[362]];
      }
      this[_0x5e86[372]](_0x5e86[371]);
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[369]] = function () {
      this[_0x5e86[370]] = true;
      if (this[_0x5e86[373]]) {
        this[_0x5e86[213]] = this[_0x5e86[373]];
      }
      _0x5a04xc[_0x5e86[374]][_0x5e86[162]]();
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[366]] = function () {
      this[_0x5e86[358]] = true;
      if (this[_0x5e86[370]]) {
        return;
      }
      if (this[_0x5e86[375]]) {
        this[_0x5e86[213]] = this[_0x5e86[375]];
      }
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[364]] = function () {
      this[_0x5e86[358]] = false;
      if (this[_0x5e86[370]]) {
        return;
      }
      this[_0x5e86[213]] = this[_0x5e86[362]];
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[145]] = function () {
      this[_0x5e86[361]] = true;
      this[_0x5e86[370]] = true;
      if (this[_0x5e86[373]]) {
        this[_0x5e86[213]] = this[_0x5e86[373]];
      }
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[376]] = function () {
      if (!this[_0x5e86[360]]) {
        this[_0x5e86[361]] = false;
      }
      this[_0x5e86[368]]();
    };
    _0x5a04x141[_0x5e86[299]][_0x5e86[377]] = function (_0x5a04x132) {
      if (_0x5a04x132) {
        this[_0x5e86[213]] = this[_0x5e86[362]];
        this[_0x5e86[152]] = true;
      } else {
        this[_0x5e86[213]] = this[_0x5e86[378]] || this[_0x5e86[362]];
        this[_0x5e86[152]] = false;
      }
    };
    return _0x5a04x141;
  })();
  return _0x5a04x6;
})();
game[_0x5e86[283]]();
var Tweener = (function () {
  var Tweener = {
    tweens: [],
    loop: true,
    params: { time: 1, transition: _0x5e86[217], delay: 0 },
    fallbacks: { onStart: null, onUpdate: null, onComplete: null },
  };
  Tweener[_0x5e86[379]] = function (_0x5a04x6b) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < Tweener[_0x5e86[380]][_0x5e86[161]];
      _0x5a04x60++
    ) {
      if (Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[381]] == _0x5a04x6b) {
        Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[379]]();
        break;
      }
    }
  };
  Tweener[_0x5e86[89]] = function (_0x5a04x6b) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < Tweener[_0x5e86[380]][_0x5e86[161]];
      _0x5a04x60++
    ) {
      if (Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[381]] == _0x5a04x6b) {
        Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[89]]();
        break;
      }
    }
  };
  Tweener[_0x5e86[382]] = function (_0x5a04x6b) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < Tweener[_0x5e86[380]][_0x5e86[161]];
      _0x5a04x60++
    ) {
      if (Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[381]] == _0x5a04x6b) {
        Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[382]]();
        break;
      }
    }
  };
  Tweener[_0x5e86[227]] = function (_0x5a04x6b) {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < Tweener[_0x5e86[380]][_0x5e86[161]];
      _0x5a04x60++
    ) {
      if (Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[381]] === _0x5a04x6b) {
        Tweener[_0x5e86[380]][_0x5a04x60][_0x5e86[119]]();
        break;
      }
    }
  };
  Tweener[_0x5e86[183]] = function (_0x5a04x6b, _0x5a04x143, _0x5a04x144) {
    var _0x5a04x145 = Tweener;
    Tweener[_0x5e86[227]](_0x5a04x6b);
    var _0x5a04x146 = new _0x5a04x145.Tween(
      _0x5a04x6b,
      _0x5a04x143,
      _0x5a04x144
    );
    _0x5a04x145[_0x5e86[380]][_0x5e86[145]](_0x5a04x146);
    _0x5a04x146[_0x5e86[101]]();
  };
  Tweener[_0x5e86[383]] = function (_0x5a04x6b, _0x5a04x143, _0x5a04x144) {};
  Tweener[_0x5e86[384]] = function (_0x5a04x6b, _0x5a04x147, _0x5a04x144) {
    this[_0x5e86[381]] = _0x5a04x6b;
    this[_0x5e86[385]] = [];
    this[_0x5e86[386]] = {};
    this[_0x5e86[387]] = {};
    this[_0x5e86[388]] = {};
    this[_0x5e86[389]] = false;
    this[_0x5e86[390]] = 0;
    this[_0x5e86[391]] = {
      time: 25,
      delay: 0,
      transition: _0x5e86[217],
      onStart: null,
      onUpdate: null,
      onComplete: null,
      loop: false,
    };
    if (_0x5a04x144) {
      for (var _0x5a04x148 in this[_0x5e86[391]]) {
        this[_0x5e86[391]][_0x5a04x148] = _0x5a04x144[_0x5a04x148]
          ? _0x5a04x144[_0x5a04x148]
          : this[_0x5e86[391]][_0x5a04x148];
      }
    }
    for (var _0x5a04xc7 in _0x5a04x147) {
      this[_0x5e86[385]][_0x5e86[145]](_0x5a04xc7);
      this[_0x5e86[387]][_0x5a04xc7] = _0x5a04x6b[_0x5a04xc7];
      this[_0x5e86[386]][_0x5a04xc7] =
        _0x5a04x147[_0x5a04xc7] - _0x5a04x6b[_0x5a04xc7];
      this[_0x5e86[388]][_0x5a04xc7] = _0x5a04x147[_0x5a04xc7];
    }
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[101]] = function () {
    PIXI[_0x5e86[118]][_0x5e86[392]][_0x5e86[84]](this[_0x5e86[201]], this);
    this[_0x5e86[389]] = true;
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[119]] = function () {
    this[_0x5e86[389]] = false;
    PIXI[_0x5e86[118]][_0x5e86[392]][_0x5e86[291]](this[_0x5e86[201]], this);
    var _0x5a04x149 = Tweener[_0x5e86[380]];
    _0x5a04x149[_0x5e86[188]](_0x5a04x149[_0x5e86[220]](this), 1);
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[89]] = function () {
    if (!this[_0x5e86[389]]) {
      return;
    }
    this[_0x5e86[389]] = false;
    PIXI[_0x5e86[118]][_0x5e86[392]][_0x5e86[291]](this[_0x5e86[201]], this);
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[382]] = function () {
    if (!this[_0x5e86[389]]) {
      PIXI[_0x5e86[118]][_0x5e86[392]][_0x5e86[84]](this[_0x5e86[201]], this);
      this[_0x5e86[389]] = true;
    }
    this[_0x5e86[393]] = 0;
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[379]] = function () {
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < this[_0x5e86[385]][_0x5e86[161]];
      _0x5a04x60++
    ) {
      var _0x5a04x14a = this[_0x5e86[385]][_0x5a04x60];
      this[_0x5e86[381]][_0x5a04x14a] =
        this[_0x5e86[387]][_0x5a04x14a] + this[_0x5e86[386]][_0x5a04x14a];
    }
    if (this[_0x5e86[391]][_0x5e86[394]]) {
      this[_0x5e86[391]][_0x5e86[394]](this._target);
    }
    this[_0x5e86[119]]();
  };
  Tweener[_0x5e86[384]][_0x5e86[299]][_0x5e86[201]] = function (_0x5a04x12f) {
    var _0x5a04x145 = Tweener;
    var _0x5a04x14b = _0x5a04x12f;
    var _0x5a04x7b = this;
    if (this[_0x5e86[391]][_0x5e86[192]] > 0) {
      this[_0x5e86[391]][_0x5e86[192]] -= _0x5a04x14b;
      if (
        this[_0x5e86[391]][_0x5e86[192]] <= 0 &&
        this[_0x5e86[391]][_0x5e86[395]]
      ) {
        this[_0x5e86[391]][_0x5e86[395]](this._target);
      }
    } else {
      var _0x5a04x14c = false;
      var _0x5a04x14d = this[_0x5e86[391]][_0x5e86[396]];
      this[_0x5e86[390]] += _0x5a04x14b;
      if (this[_0x5e86[390]] < 0) {
        this[_0x5e86[390]] = 0;
      } else {
        if (
          this[_0x5e86[390]] + _0x5a04x14b / 2 >
          this[_0x5e86[391]][_0x5e86[396]]
        ) {
          this[_0x5e86[390]] = this[_0x5e86[391]][_0x5e86[396]];
        }
      }
      var _0x5a04x7e = this[_0x5e86[390]] / this[_0x5e86[391]][_0x5e86[396]];
      var _0x5a04x14e = Tweener[_0x5e86[398]][this[_0x5e86[391]][_0x5e86[397]]](
        _0x5a04x7e
      );
      for (
        var _0x5a04x60 = 0;
        _0x5a04x60 < this[_0x5e86[385]][_0x5e86[161]];
        _0x5a04x60++
      ) {
        var _0x5a04x14a = this[_0x5e86[385]][_0x5a04x60];
        if (this[_0x5e86[388]][_0x5a04x14a][_0x5e86[399]] === Array) {
          var _0x5a04x14f =
            (this[_0x5e86[388]][_0x5a04x14a][_0x5e86[161]] - 1) * _0x5a04x14e;
          var _0x5a04x150 = Math[_0x5e86[288]](_0x5a04x14f);
          var _0x5a04x151 = 1 - (_0x5a04x150 - _0x5a04x14f);
          var _0x5a04x152 =
            _0x5a04x150 > 0
              ? this[_0x5e86[388]][_0x5a04x14a][_0x5a04x150 - 1]
              : this[_0x5e86[387]][_0x5a04x14a];
          var _0x5a04x153 = this[_0x5e86[388]][_0x5a04x14a][_0x5a04x150];
          if (this[_0x5e86[381]][_0x5a04x14a] != _0x5a04x153) {
            dirty = true;
            this[_0x5e86[381]][_0x5a04x14a] =
              _0x5a04x152 + (_0x5a04x153 - _0x5a04x152) * _0x5a04x151;
          }
        } else {
          this[_0x5e86[381]][_0x5a04x14a] =
            this[_0x5e86[387]][_0x5a04x14a] +
            (this[_0x5e86[388]][_0x5a04x14a] -
              this[_0x5e86[387]][_0x5a04x14a]) *
              _0x5a04x14e;
        }
      }
      if (this[_0x5e86[391]][_0x5e86[400]]) {
        this[_0x5e86[391]][_0x5e86[400]](this._target, _0x5a04x7e);
      }
      if (this[_0x5e86[390]] >= _0x5a04x14d) {
        if (this[_0x5e86[391]][_0x5e86[55]]) {
          if (this[_0x5e86[391]][_0x5e86[55]] > 0) {
            this[_0x5e86[391]][_0x5e86[55]]--;
          }
          this[_0x5e86[390]] = 0;
          if (this[_0x5e86[391]][_0x5e86[394]]) {
            this[_0x5e86[391]][_0x5e86[394]](this._target, this);
          }
        } else {
          this[_0x5e86[119]]();
          if (this[_0x5e86[391]][_0x5e86[394]]) {
            this[_0x5e86[391]][_0x5e86[394]](this._target, this);
          }
        }
      }
    }
  };
  Tweener[_0x5e86[398]] = {
    linear: function (_0x5a04x7b) {
      return _0x5a04x7b;
    },
    easeInElastic: function (
      _0x5a04x7b,
      _0x5a04x123,
      _0x5a04x154,
      _0x5a04x155
    ) {
      var _0x5a04x156 = 1.70158;
      var _0x5a04xc7 = 0;
      var _0x5a04x122 = _0x5a04x154;
      if (_0x5a04x7b == 0) {
        return _0x5a04x123;
      }
      if ((_0x5a04x7b /= _0x5a04x155) == 1) {
        return _0x5a04x123 + _0x5a04x154;
      }
      if (!_0x5a04xc7) {
        _0x5a04xc7 = _0x5a04x155 * 0.3;
      }
      if (_0x5a04x122 < Math[_0x5e86[233]](_0x5a04x154)) {
        _0x5a04x122 = _0x5a04x154;
        var _0x5a04x156 = _0x5a04xc7 / 4;
      } else {
        var _0x5a04x156 =
          (_0x5a04xc7 / (2 * Math[_0x5e86[186]])) *
          Math[_0x5e86[401]](_0x5a04x154 / _0x5a04x122);
      }
      return (
        -(
          _0x5a04x122 *
          Math[_0x5e86[292]](2, 10 * (_0x5a04x7b -= 1)) *
          Math[_0x5e86[271]](
            ((_0x5a04x7b * _0x5a04x155 - _0x5a04x156) *
              (2 * Math[_0x5e86[186]])) /
              _0x5a04xc7
          )
        ) + _0x5a04x123
      );
    },
    bow: function (_0x5a04x7b) {
      return Math[_0x5e86[271]](_0x5a04x7b * Math[_0x5e86[186]]);
    },
    bounc: function (_0x5a04x7b) {
      return Math[_0x5e86[271]](3 * _0x5a04x7b * Math[_0x5e86[186]]);
    },
    experimental: function (_0x5a04x7b) {
      return Math[_0x5e86[271]](_0x5a04x7b * Math[_0x5e86[186]]);
    },
    easeOutSine: function (_0x5a04x7b) {
      return (
        1 * Math[_0x5e86[271]]((_0x5a04x7b / 1) * (Math[_0x5e86[186]] / 2))
      );
    },
    easeOutCubic: function (_0x5a04x7b) {
      return (
        1 * ((_0x5a04x7b = _0x5a04x7b / 1 - 1) * _0x5a04x7b * _0x5a04x7b + 1)
      );
    },
    easeOutBounce: function (_0x5a04x7b) {
      if (_0x5a04x7b < 1 / 2.75) {
        return 1 * (7.5625 * _0x5a04x7b * _0x5a04x7b);
      } else {
        if (_0x5a04x7b < 2 / 2.75) {
          _0x5a04x7b -= 1.5 / 2.75;
          return 1 * (7.5625 * _0x5a04x7b * _0x5a04x7b + 0.75);
        } else {
          if (_0x5a04x7b < 2.5 / 2.75) {
            _0x5a04x7b -= 2.25 / 2.75;
            return 1 * (7.5625 * _0x5a04x7b * _0x5a04x7b + 0.9375);
          } else {
            _0x5a04x7b -= 1.5 / 2.75;
            if (7.5625 * _0x5a04x7b * _0x5a04x7b + 0.8575 > 1) {
              return 1;
            } else {
              return 7.5625 * _0x5a04x7b * _0x5a04x7b + 0.8575;
            }
          }
        }
      }
    },
    easeInOutBack: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (
          (1 / 2) *
          (_0x5a04x7b *
            _0x5a04x7b *
            (((_0x5a04x156 *= 1.525) + 1) * _0x5a04x7b - _0x5a04x156))
        );
      }
      return (
        (1 / 2) *
        ((_0x5a04x7b -= 2) *
          _0x5a04x7b *
          (((_0x5a04x156 *= 1.525) + 1) * _0x5a04x7b + _0x5a04x156) +
          2)
      );
    },
    easeInQuad: function (_0x5a04x7b) {
      return _0x5a04x7b * _0x5a04x7b;
    },
    easeOutQuad: function (_0x5a04x7b) {
      return -1 * _0x5a04x7b * (_0x5a04x7b - 2);
    },
    easeInOutQuad: function (_0x5a04x7b) {
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (1 / 2) * _0x5a04x7b * _0x5a04x7b;
      }
      return (-1 / 2) * (--_0x5a04x7b * (_0x5a04x7b - 2) - 1);
    },
    easeInCubic: function (_0x5a04x7b) {
      return _0x5a04x7b * _0x5a04x7b * _0x5a04x7b;
    },
    easeOutCubic: function (_0x5a04x7b) {
      return (
        1 * ((_0x5a04x7b = _0x5a04x7b / 1 - 1) * _0x5a04x7b * _0x5a04x7b + 1)
      );
    },
    easeInOutCubic: function (_0x5a04x7b) {
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (1 / 2) * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b;
      }
      return (1 / 2) * ((_0x5a04x7b -= 2) * _0x5a04x7b * _0x5a04x7b + 2);
    },
    easeInQuart: function (_0x5a04x7b) {
      return _0x5a04x7b * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b;
    },
    easeOutQuart: function (_0x5a04x7b) {
      return (
        -1 *
        ((_0x5a04x7b = _0x5a04x7b / 1 - 1) *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b -
          1)
      );
    },
    easeInOutQuart: function (_0x5a04x7b) {
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (1 / 2) * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b;
      }
      return (
        (-1 / 2) *
        ((_0x5a04x7b -= 2) * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b - 2)
      );
    },
    easeInQuint: function (_0x5a04x7b) {
      return (
        1 *
        (_0x5a04x7b /= 1) *
        _0x5a04x7b *
        _0x5a04x7b *
        _0x5a04x7b *
        _0x5a04x7b
      );
    },
    easeOutQuint: function (_0x5a04x7b) {
      return (
        1 *
        ((_0x5a04x7b = _0x5a04x7b / 1 - 1) *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b +
          1)
      );
    },
    easeInOutQuint: function (_0x5a04x7b) {
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (
          (1 / 2) *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b *
          _0x5a04x7b
        );
      }
      return (
        (1 / 2) *
        ((_0x5a04x7b -= 2) * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b * _0x5a04x7b +
          2)
      );
    },
    easeInSine: function (_0x5a04x7b) {
      return (
        -1 * Math[_0x5e86[270]]((_0x5a04x7b / 1) * (Math[_0x5e86[186]] / 2)) + 1
      );
    },
    easeOutSine: function (_0x5a04x7b) {
      return (
        1 * Math[_0x5e86[271]]((_0x5a04x7b / 1) * (Math[_0x5e86[186]] / 2))
      );
    },
    easeInOutSine: function (_0x5a04x7b) {
      return (
        (-1 / 2) *
        (Math[_0x5e86[270]]((Math[_0x5e86[186]] * _0x5a04x7b) / 1) - 1)
      );
    },
    easeInExpo: function (_0x5a04x7b) {
      return _0x5a04x7b === 0
        ? 1
        : 1 * Math[_0x5e86[292]](2, 10 * (_0x5a04x7b / 1 - 1));
    },
    easeOutExpo: function (_0x5a04x7b) {
      return _0x5a04x7b === 1
        ? 1
        : 1 * (-Math[_0x5e86[292]](2, (-10 * _0x5a04x7b) / 1) + 1);
    },
    easeInOutExpo: function (_0x5a04x7b) {
      if (_0x5a04x7b === 0) {
        return 0;
      }
      if (_0x5a04x7b === 1) {
        return 1;
      }
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (1 / 2) * Math[_0x5e86[292]](2, 10 * (_0x5a04x7b - 1));
      }
      return (1 / 2) * (-Math[_0x5e86[292]](2, -10 * --_0x5a04x7b) + 2);
    },
    easeInCirc: function (_0x5a04x7b) {
      if (_0x5a04x7b >= 1) {
        return _0x5a04x7b;
      }
      return -1 * (Math[_0x5e86[293]](1 - (_0x5a04x7b /= 1) * _0x5a04x7b) - 1);
    },
    easeOutCirc: function (_0x5a04x7b) {
      return (
        1 *
        Math[_0x5e86[293]](1 - (_0x5a04x7b = _0x5a04x7b / 1 - 1) * _0x5a04x7b)
      );
    },
    easeInOutCirc: function (_0x5a04x7b) {
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (-1 / 2) * (Math[_0x5e86[293]](1 - _0x5a04x7b * _0x5a04x7b) - 1);
      }
      return (
        (1 / 2) * (Math[_0x5e86[293]](1 - (_0x5a04x7b -= 2) * _0x5a04x7b) + 1)
      );
    },
    easeInElastic: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      var _0x5a04xc7 = 0;
      var _0x5a04x122 = 1;
      if (_0x5a04x7b === 0) {
        return 0;
      }
      if ((_0x5a04x7b /= 1) == 1) {
        return 1;
      }
      if (!_0x5a04xc7) {
        _0x5a04xc7 = 1 * 0.3;
      }
      if (_0x5a04x122 < Math[_0x5e86[233]](1)) {
        _0x5a04x122 = 1;
        _0x5a04x156 = _0x5a04xc7 / 4;
      } else {
        _0x5a04x156 =
          (_0x5a04xc7 / (2 * Math[_0x5e86[186]])) *
          Math[_0x5e86[401]](1 / _0x5a04x122);
      }
      return -(
        _0x5a04x122 *
        Math[_0x5e86[292]](2, 10 * (_0x5a04x7b -= 1)) *
        Math[_0x5e86[271]](
          ((_0x5a04x7b * 1 - _0x5a04x156) * (2 * Math[_0x5e86[186]])) /
            _0x5a04xc7
        )
      );
    },
    easeOutElastic: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      var _0x5a04xc7 = 0;
      var _0x5a04x122 = 1;
      if (_0x5a04x7b === 0) {
        return 0;
      }
      if ((_0x5a04x7b /= 1) == 1) {
        return 1;
      }
      if (!_0x5a04xc7) {
        _0x5a04xc7 = 1 * 0.3;
      }
      if (_0x5a04x122 < Math[_0x5e86[233]](1)) {
        _0x5a04x122 = 1;
        _0x5a04x156 = _0x5a04xc7 / 4;
      } else {
        _0x5a04x156 =
          (_0x5a04xc7 / (2 * Math[_0x5e86[186]])) *
          Math[_0x5e86[401]](1 / _0x5a04x122);
      }
      return (
        _0x5a04x122 *
          Math[_0x5e86[292]](2, -10 * _0x5a04x7b) *
          Math[_0x5e86[271]](
            ((_0x5a04x7b * 1 - _0x5a04x156) * (2 * Math[_0x5e86[186]])) /
              _0x5a04xc7
          ) +
        1
      );
    },
    easeInOutElastic: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      var _0x5a04xc7 = 0;
      var _0x5a04x122 = 1;
      if (_0x5a04x7b === 0) {
        return 0;
      }
      if ((_0x5a04x7b /= 1 / 2) == 2) {
        return 1;
      }
      if (!_0x5a04xc7) {
        _0x5a04xc7 = 1 * (0.3 * 1.5);
      }
      if (_0x5a04x122 < Math[_0x5e86[233]](1)) {
        _0x5a04x122 = 1;
        _0x5a04x156 = _0x5a04xc7 / 4;
      } else {
        _0x5a04x156 =
          (_0x5a04xc7 / (2 * Math[_0x5e86[186]])) *
          Math[_0x5e86[401]](1 / _0x5a04x122);
      }
      if (_0x5a04x7b < 1) {
        return (
          -0.5 *
          (_0x5a04x122 *
            Math[_0x5e86[292]](2, 10 * (_0x5a04x7b -= 1)) *
            Math[_0x5e86[271]](
              ((_0x5a04x7b * 1 - _0x5a04x156) * (2 * Math[_0x5e86[186]])) /
                _0x5a04xc7
            ))
        );
      }
      return (
        _0x5a04x122 *
          Math[_0x5e86[292]](2, -10 * (_0x5a04x7b -= 1)) *
          Math[_0x5e86[271]](
            ((_0x5a04x7b * 1 - _0x5a04x156) * (2 * Math[_0x5e86[186]])) /
              _0x5a04xc7
          ) *
          0.5 +
        1
      );
    },
    easeInBack: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      return (
        1 *
        (_0x5a04x7b /= 1) *
        _0x5a04x7b *
        ((_0x5a04x156 + 1) * _0x5a04x7b - _0x5a04x156)
      );
    },
    easeOutBack: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      return (
        1 *
        ((_0x5a04x7b / 1 - 1) *
          (_0x5a04x7b / 1 - 1) *
          ((1.70158 + 1) * (_0x5a04x7b / 1 - 1) + 1.70158) +
          1)
      );
    },
    easeInOutBack: function (_0x5a04x7b) {
      var _0x5a04x156 = 1.70158;
      if ((_0x5a04x7b /= 1 / 2) < 1) {
        return (
          (1 / 2) *
          (_0x5a04x7b *
            _0x5a04x7b *
            (((_0x5a04x156 *= 1.525) + 1) * _0x5a04x7b - _0x5a04x156))
        );
      }
      return (
        (1 / 2) *
        ((_0x5a04x7b -= 2) *
          _0x5a04x7b *
          (((_0x5a04x156 *= 1.525) + 1) * _0x5a04x7b + _0x5a04x156) +
          2)
      );
    },
    easeInBounce: function (_0x5a04x7b) {
      return 1 - Tweener[_0x5e86[398]][_0x5e86[402]](1 - _0x5a04x7b);
    },
    easeOutBounce: function (_0x5a04x7b) {
      if (_0x5a04x7b < 1 / 2.75) {
        return 1 * (7.5625 * _0x5a04x7b * _0x5a04x7b);
      } else {
        _0x5a04x7b -= 1.5 / 2.75;
        if (7.5625 * _0x5a04x7b * _0x5a04x7b + 0.8575 > 1) {
          return 1;
        } else {
          return 7.5625 * _0x5a04x7b * _0x5a04x7b + 0.8575;
        }
      }
    },
    easeInOutBounce: function (_0x5a04x7b) {
      if (_0x5a04x7b < 1 / 2) {
        return easingEffects[_0x5e86[403]](_0x5a04x7b * 2) * 0.5;
      }
      return easingEffects[_0x5e86[402]](_0x5a04x7b * 2 - 1) * 0.5 + 1 * 0.5;
    },
  };
  return Tweener;
})();
function Animable(_0x5a04x12a) {
  PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
  this[_0x5e86[404]] = {};
  this[_0x5e86[405]] = 0;
  this[_0x5e86[390]] = 0;
  this[_0x5e86[406]] = 10;
  this[_0x5e86[407]] = null;
  this[_0x5e86[408]] = [];
  this[_0x5e86[357]] = false;
}
Animable[_0x5e86[299]] = Object[_0x5e86[300]](PIXI[_0x5e86[125]][_0x5e86[299]]);
Animable[_0x5e86[299]][_0x5e86[223]] = function (
  _0x5a04x41,
  _0x5a04x158,
  _0x5a04x57,
  _0x5a04x159
) {
  if (_0x5a04x57) {
    this[_0x5e86[404]][_0x5a04x41] = [];
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x57[_0x5e86[161]];
      _0x5a04x60++
    ) {
      this[_0x5e86[404]][_0x5a04x41][_0x5e86[145]](
        _0x5a04x158[_0x5a04x57[_0x5a04x60]]
      );
    }
  } else {
    this[_0x5e86[404]][_0x5a04x41] = _0x5a04x158;
  }
  if (_0x5a04x159) {
    var _0x5a04x15a = [][_0x5e86[409]](this[_0x5e86[404]][_0x5a04x41]);
    _0x5a04x15a[_0x5e86[410]]();
    this[_0x5e86[404]][_0x5a04x41][_0x5e86[411]]();
    this[_0x5e86[404]][_0x5a04x41] = this[_0x5e86[404]][_0x5a04x41][
      _0x5e86[409]
    ](_0x5a04x15a);
  }
};
Animable[_0x5e86[299]][_0x5e86[412]] = function (
  _0x5a04x41,
  _0x5a04x158,
  _0x5a04x15b
) {
  this[_0x5e86[404]][_0x5a04x41] = [];
  for (
    var _0x5a04x60 = 0;
    _0x5a04x60 < _0x5a04x15b[_0x5e86[161]];
    _0x5a04x60++
  ) {
    var _0x5a04x57 = [];
    for (
      var _0x5a04x61 = 0;
      _0x5a04x61 < _0x5a04x15b[_0x5a04x60][_0x5e86[161]];
      _0x5a04x61++
    ) {
      _0x5a04x57[_0x5e86[145]](
        _0x5a04x158[_0x5a04x15b[_0x5a04x60][_0x5a04x61]]
      );
    }
    this[_0x5e86[404]][_0x5a04x41][_0x5e86[145]](_0x5a04x57);
  }
};
Animable[_0x5e86[299]][_0x5e86[174]] = function (
  _0x5a04x41,
  _0x5a04x15c,
  _0x5a04x15d
) {
  if (!this[_0x5e86[404]][_0x5a04x41]) {
    return null;
  }
  this[_0x5e86[413]] = _0x5a04x41;
  this[_0x5e86[407]] = this[_0x5e86[414]](this._animationName);
  this[_0x5e86[390]] = 0;
  this[_0x5e86[405]] = _0x5a04x15c || 0;
  this[_0x5e86[406]] = _0x5a04x15d || this[_0x5e86[406]];
  this[_0x5e86[357]] = true;
};
Animable[_0x5e86[299]][_0x5e86[415]] = function () {
  this[_0x5e86[357]] = false;
};
Animable[_0x5e86[299]][_0x5e86[414]] = function (_0x5a04x41) {
  if (this[_0x5e86[404]][_0x5a04x41][0][_0x5e86[399]] === Array) {
    var _0x5a04x15e = Math[_0x5e86[187]](
      Math[_0x5e86[178]]() * (this[_0x5e86[404]][_0x5a04x41][_0x5e86[161]] - 1)
    );
    return this[_0x5e86[404]][_0x5a04x41][_0x5a04x15e];
  } else {
    return this[_0x5e86[404]][_0x5a04x41];
  }
};
Animable[_0x5e86[299]][_0x5e86[416]] = function (
  _0x5a04x41,
  _0x5a04x15c,
  _0x5a04x15d
) {
  this[_0x5e86[408]][_0x5e86[145]]({
    name: _0x5a04x41,
    loops: _0x5a04x15c,
    fps: _0x5a04x15d,
  });
};
Animable[_0x5e86[299]][_0x5e86[417]] = function () {
  this[_0x5e86[408]] = [];
};
Animable[_0x5e86[299]][_0x5e86[418]] = function () {
  if (!this[_0x5e86[408]][_0x5e86[161]]) {
    return;
  }
  var _0x5a04x15f = this[_0x5e86[408]][_0x5e86[411]]();
  this[_0x5e86[174]](
    _0x5a04x15f[_0x5e86[419]],
    _0x5a04x15f[_0x5e86[420]],
    _0x5a04x15f[_0x5e86[421]]
  );
};
Animable[_0x5e86[299]][_0x5e86[201]] = function (_0x5a04x7b) {
  if (!this[_0x5e86[357]] || !this[_0x5e86[407]]) {
    return null;
  }
  this[_0x5e86[390]] += _0x5a04x7b > 0 ? _0x5a04x7b : 0;
  var _0x5a04x160 = this[_0x5e86[407]];
  var _0x5a04x161 = (_0x5a04x160[_0x5e86[161]] - 1) / (this[_0x5e86[406]] / 60);
  if (this[_0x5e86[390]] >= _0x5a04x161) {
    if (this[_0x5e86[405]]) {
      this[_0x5e86[405]]--;
      this[_0x5e86[390]] -= _0x5a04x161;
      this[_0x5e86[407]] = this[_0x5e86[414]](this._animationName);
    } else {
      this[_0x5e86[390]] = _0x5a04x161;
      this[_0x5e86[357]] = false;
      if (this[_0x5e86[408]][_0x5e86[161]]) {
        var _0x5a04x15f = this[_0x5e86[408]][_0x5e86[411]]();
        this[_0x5e86[174]](
          _0x5a04x15f[_0x5e86[419]],
          _0x5a04x15f[_0x5e86[420]],
          _0x5a04x15f[_0x5e86[421]]
        );
      }
    }
  }
  var _0x5a04x162 = Math[_0x5e86[187]](
    (this[_0x5e86[390]] * this[_0x5e86[406]]) / 60
  );
  this[_0x5e86[213]] = _0x5a04x160[_0x5a04x162];
};
Animable[_0x5e86[299]][_0x5e86[422]] = function () {
  this[_0x5e86[390]] = 0;
};
var ParticleManager = (function () {
  var _0x5a04x6 = {};
  _0x5a04x6[_0x5e86[201]] = function () {};
  var _0x5a04x12c = function (_0x5a04x12a, _0x5a04x12d) {
    this[_0x5e86[301]] = _0x5a04x12d;
    this[_0x5e86[275]] = { x: 0, y: 0 };
    this[_0x5e86[302]] = { x: 0, y: 0 };
    this[_0x5e86[276]] = 0;
    this[_0x5e86[303]] = 0;
    this[_0x5e86[280]] = 1;
    this[_0x5e86[304]] = { r: 255, g: 255, b: 255 };
    this[_0x5e86[277]] = 1;
    this[_0x5e86[278]] = 100;
    this[_0x5e86[305]] = 0;
    this[_0x5e86[306]] = 1;
    this[_0x5e86[307]] = { r: 255, g: 255, b: 255 };
    this[_0x5e86[308]] = { x: 0, y: 0 };
    this[_0x5e86[309]] = false;
    this[_0x5e86[310]] = false;
    this[_0x5e86[311]] = false;
    this[_0x5e86[312]] = false;
    this[_0x5e86[313]] = 0;
    this[_0x5e86[314]] = null;
    this[_0x5e86[315]] = 1;
    this[_0x5e86[316]] = 1;
    this[_0x5e86[317]] = { x: 0, y: 0 };
    this[_0x5e86[318]] = 0;
    this[_0x5e86[283]]();
    PIXI[_0x5e86[125]][_0x5e86[295]](this, _0x5a04x12a);
    this[_0x5e86[144]][_0x5e86[128]] = 0.5;
    this[_0x5e86[144]][_0x5e86[129]] = 0.5;
  };
  _0x5a04x12c[_0x5e86[299]] = Object[_0x5e86[300]](
    PIXI[_0x5e86[125]][_0x5e86[299]]
  );
  _0x5a04x12c[_0x5e86[299]][_0x5e86[283]] = function () {
    this[_0x5e86[313]] = 0;
    this[_0x5e86[317]][_0x5e86[128]] = this[_0x5e86[275]][_0x5e86[128]];
    this[_0x5e86[317]][_0x5e86[129]] = this[_0x5e86[275]][_0x5e86[129]];
    this[_0x5e86[318]] = this[_0x5e86[276]];
  };
  _0x5a04x12c[_0x5e86[299]][_0x5e86[319]] = function () {
    this[_0x5e86[313]] = 0;
    this[_0x5e86[317]][_0x5e86[128]] = this[_0x5e86[275]][_0x5e86[128]];
    this[_0x5e86[317]][_0x5e86[129]] = this[_0x5e86[275]][_0x5e86[129]];
    this[_0x5e86[318]] = this[_0x5e86[276]];
  };
  var _0x5a04x12e = function (_0x5a04x7e) {
    if (_0x5a04x7e <= 0.15) {
      return -6.666 * _0x5a04x7e + 1.0;
    }
    return _0x5a04x7e;
  };
  _0x5a04x12c[_0x5e86[299]][_0x5e86[201]] = function (_0x5a04x12f) {
    this[_0x5e86[313]] += _0x5a04x12f;
    if (this[_0x5e86[313]] >= this[_0x5e86[278]]) {
      this[_0x5e86[320]]();
      return -1;
    }
    var _0x5a04x7e = this[_0x5e86[313]] / this[_0x5e86[278]];
    if (this[_0x5e86[314]]) {
      _0x5a04x7e = this._ease(_0x5a04x7e);
    }
    if (this[_0x5e86[312]]) {
      this[_0x5e86[315]] =
        (this[_0x5e86[305]] - this[_0x5e86[277]]) * _0x5a04x7e +
        this[_0x5e86[277]];
    }
    if (this[_0x5e86[311]]) {
      this[_0x5e86[316]] =
        (this[_0x5e86[306]] - this[_0x5e86[280]]) * _0x5a04x7e +
        this[_0x5e86[280]];
    }
    if (this[_0x5e86[310]]) {
      if (this[_0x5e86[317]][_0x5e86[128]] < this[_0x5e86[302]][_0x5e86[128]]) {
        this[_0x5e86[317]][_0x5e86[128]] +=
          this[_0x5e86[308]][_0x5e86[128]] * _0x5a04x12f;
      } else {
        if (
          this[_0x5e86[317]][_0x5e86[128]] > this[_0x5e86[302]][_0x5e86[128]]
        ) {
          this[_0x5e86[317]][_0x5e86[128]] -=
            this[_0x5e86[308]][_0x5e86[128]] * _0x5a04x12f;
        }
      }
      if (this[_0x5e86[317]][_0x5e86[129]] < this[_0x5e86[302]][_0x5e86[129]]) {
        this[_0x5e86[317]][_0x5e86[129]] +=
          this[_0x5e86[308]][_0x5e86[129]] * _0x5a04x12f;
      } else {
        if (
          this[_0x5e86[317]][_0x5e86[129]] > this[_0x5e86[302]][_0x5e86[129]]
        ) {
          this[_0x5e86[317]][_0x5e86[129]] -=
            this[_0x5e86[308]][_0x5e86[129]] * _0x5a04x12f;
        }
      }
    }
    if (this[_0x5e86[309]]) {
      var _0x5a04x130 = _0x5a04x7e;
      var _0x5a04x92 =
        Math[_0x5e86[187]](
          (this[_0x5e86[307]][_0x5e86[321]] -
            this[_0x5e86[304]][_0x5e86[321]]) *
            _0x5a04x130
        ) + this[_0x5e86[304]][_0x5e86[321]];
      var _0x5a04x131 =
        Math[_0x5e86[187]](
          (this[_0x5e86[307]][_0x5e86[322]] -
            this[_0x5e86[304]][_0x5e86[322]]) *
            _0x5a04x130
        ) + this[_0x5e86[304]][_0x5e86[322]];
      var _0x5a04x123 =
        Math[_0x5e86[187]](
          (this[_0x5e86[307]][_0x5e86[323]] -
            this[_0x5e86[304]][_0x5e86[323]]) *
            _0x5a04x130
        ) + this[_0x5e86[304]][_0x5e86[323]];
      this[_0x5e86[324]] = ColorMath.ToHex(
        _0x5a04x92,
        _0x5a04x131,
        _0x5a04x123
      );
    }
    if (this[_0x5e86[303]]) {
      this[_0x5e86[318]] += this[_0x5e86[303]];
    }
    this[_0x5e86[325]]();
    return _0x5a04x7e;
  };
  _0x5a04x12c[_0x5e86[299]][_0x5e86[325]] = function () {
    this[_0x5e86[128]] += this[_0x5e86[317]][_0x5e86[128]];
    this[_0x5e86[129]] += this[_0x5e86[317]][_0x5e86[129]];
    this[_0x5e86[185]] = this[_0x5e86[318]];
    this[_0x5e86[229]] = this[_0x5e86[315]];
    this[_0x5e86[326]] = this[_0x5e86[324]];
    this[_0x5e86[141]][_0x5e86[128]] = this[_0x5e86[141]][_0x5e86[129]] = this[
      _0x5e86[316]
    ];
  };
  _0x5a04x12c[_0x5e86[299]][_0x5e86[320]] = function () {
    if (this[_0x5e86[211]]) {
      this[_0x5e86[211]][_0x5e86[210]](this);
    }
    this[_0x5e86[218]]();
  };
  Object[_0x5e86[328]](_0x5a04x12c[_0x5e86[299]], {
    endColor: {
      set: function (_0x5a04x132) {
        this[_0x5e86[307]] = _0x5a04x132;
        if (_0x5a04x132 != _0x5e86[327]) {
          this[_0x5e86[309]] = true;
        }
      },
    },
    acceleration: {
      get: function () {
        return this[_0x5e86[308]];
      },
      set: function (_0x5a04x132) {
        this[_0x5e86[308]] = _0x5a04x132;
        if (_0x5a04x132[_0x5e86[128]] != 0 || _0x5a04x132[_0x5e86[129]] != 0) {
          this[_0x5e86[310]] = true;
        }
      },
    },
    endSize: {
      set: function (_0x5a04x132) {
        this[_0x5e86[306]] = _0x5a04x132;
        this[_0x5e86[311]] = true;
      },
    },
    endAlpha: {
      set: function (_0x5a04x132) {
        this[_0x5e86[305]] = _0x5a04x132;
        this[_0x5e86[312]] = true;
      },
    },
  });
  _0x5a04x6[_0x5e86[329]] = _0x5a04x12c;
  return _0x5a04x6;
})();
PIXI[_0x5e86[423]] = function (_0x5a04x163) {
  var _0x5a04x54 = PIXI[_0x5e86[85]][_0x5e86[167]][_0x5a04x163[_0x5e86[225]]];
  if (_0x5a04x54) {
    var _0x5a04x164 = [];
    _0x5a04x54[_0x5e86[424]] = {};
    var _0x5a04x73 = 0;
    var _0x5a04x74 = 0;
    for (
      var _0x5a04x60 = 0;
      _0x5a04x60 < _0x5a04x163[_0x5e86[425]];
      _0x5a04x60++
    ) {
      var _0x5a04x41 = _0x5a04x163[_0x5e86[225]] + _0x5e86[426] + _0x5a04x60;
      var _0x5a04x165 = new PIXI.Rectangle(
        _0x5a04x73,
        _0x5a04x74,
        _0x5a04x163[_0x5e86[427]],
        _0x5a04x163[_0x5e86[428]]
      );
      _0x5a04x54[_0x5e86[424]][_0x5a04x41] = new PIXI.Texture(
        _0x5a04x54[_0x5e86[213]][_0x5e86[429]],
        _0x5a04x165,
        _0x5a04x165[_0x5e86[430]]()
      );
      PIXI[_0x5e86[113]][_0x5e86[215]][_0x5a04x41] =
        _0x5a04x54[_0x5e86[424]][_0x5a04x41];
      _0x5a04x164[_0x5e86[145]](_0x5a04x54[_0x5e86[424]][_0x5a04x41]);
      _0x5a04x73 += _0x5a04x163[_0x5e86[427]];
      if (
        _0x5a04x73 + _0x5a04x163[_0x5e86[427]] >
        _0x5a04x54[_0x5e86[213]][_0x5e86[109]]
      ) {
        _0x5a04x73 = 0;
        _0x5a04x74 += _0x5a04x163[_0x5e86[428]];
        if (
          _0x5a04x74 + _0x5a04x163[_0x5e86[428]] >
          _0x5a04x54[_0x5e86[213]][_0x5e86[110]]
        ) {
          break;
        }
      }
    }
    return _0x5a04x164;
  }
  return false;
};
Object[_0x5e86[328]](PIXI[_0x5e86[296]][_0x5e86[299]], {
  scaleX: {
    get: function () {
      return this[_0x5e86[141]][_0x5e86[128]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[141]][_0x5e86[128]] = _0x5a04x132;
    },
  },
  scaleY: {
    get: function () {
      return this[_0x5e86[141]][_0x5e86[129]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[141]][_0x5e86[129]] = _0x5a04x132;
    },
  },
});
Object[_0x5e86[328]](PIXI[_0x5e86[125]][_0x5e86[299]], {
  scaleX: {
    get: function () {
      return this[_0x5e86[141]][_0x5e86[128]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[141]][_0x5e86[128]] = _0x5a04x132;
    },
  },
  scaleY: {
    get: function () {
      return this[_0x5e86[141]][_0x5e86[129]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[141]][_0x5e86[129]] = _0x5a04x132;
    },
  },
  anchorX: {
    get: function () {
      return this[_0x5e86[144]][_0x5e86[128]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[144]][_0x5e86[128]] = _0x5a04x132;
    },
  },
  anchorY: {
    get: function () {
      return this[_0x5e86[144]][_0x5e86[129]];
    },
    set: function (_0x5a04x132) {
      this[_0x5e86[144]][_0x5e86[129]] = _0x5a04x132;
    },
  },
});
var ColorMath;
(function (ColorMath) {
  ColorMath[_0x5e86[431]] = function (_0x5a04x167) {
    var _0x5a04x168 = {};
    if (_0x5a04x167[_0x5e86[432]](0) == _0x5e86[433]) {
      _0x5a04x167 = _0x5a04x167[_0x5e86[434]](1);
    } else {
      if (_0x5a04x167[_0x5e86[220]](_0x5e86[435]) === 0) {
        _0x5a04x167 = _0x5a04x167[_0x5e86[434]](2);
      }
    }
    if (_0x5a04x167[_0x5e86[161]] == 8) {
      _0x5a04x167 = _0x5a04x167[_0x5e86[434]](2);
    }
    _0x5a04x168[_0x5e86[321]] = parseInt(_0x5a04x167[_0x5e86[434]](0, 2), 16);
    _0x5a04x168[_0x5e86[322]] = parseInt(_0x5a04x167[_0x5e86[434]](2, 2), 16);
    _0x5a04x168[_0x5e86[323]] = parseInt(_0x5a04x167[_0x5e86[434]](4, 2), 16);
    return _0x5a04x168;
  };
  ColorMath[_0x5e86[436]] = function (_0x5a04x92, _0x5a04x131, _0x5a04x123) {
    return (
      _0x5e86[435] +
      ((1 << 24) + (_0x5a04x92 << 16) + (_0x5a04x131 << 8) + _0x5a04x123)
        .toString(16)
        [_0x5e86[202]](1)
    );
  };
  ColorMath[_0x5e86[437]] = function (_0x5a04x132) {
    return _0x5e86[435] + _0x5a04x132.toString(16);
  };
})(ColorMath || (ColorMath = {}));
