var _0xdaa5 = [
  "\x69\x6E\x69\x74",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x30\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6C\x6C\x6F\x6D\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x72\x69\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x74\x65\x61\x6D\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x74\x65\x61\x6D\x5F\x73\x70\x72\x69\x74\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x61\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x6F\x6F\x64\x65\x6E\x5F\x62\x6F\x78\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x61\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x63\x6F\x6C\x75\x6D\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x72\x69\x76\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x62\x6F\x61\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x67\x79\x70\x74\x5F\x73\x61\x72\x63\x6F\x70\x68\x61\x67\x75\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x70\x69\x6B\x65\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x70\x69\x6B\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x76\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x73\x74\x72\x69\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x6C\x5F\x62\x6F\x78\x4C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x74\x72\x6F\x5F\x74\x72\x61\x69\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x78\x69\x74\x5F\x73\x69\x67\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x6F\x78\x69\x63\x5F\x62\x61\x72\x72\x65\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x6F\x78\x69\x63\x5F\x70\x69\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x72\x61\x69\x6E\x5F\x66\x72\x6F\x6E\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x72\x61\x69\x6E\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x72\x61\x69\x6E\x5F\x63\x6F\x6E\x6E\x65\x63\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x69\x74\x79\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x69\x74\x79\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x69\x74\x79\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x69\x74\x79\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x69\x74\x79\x5F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x69\x64\x67\x65\x6F\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x65\x6C\x65\x70\x68\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x74\x72\x65\x65\x74\x5F\x6C\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x75\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x6F\x75\x73\x65\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x6F\x75\x73\x65\x5F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x65\x62\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x70\x69\x64\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x61\x6E\x64\x6C\x65\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6F\x72\x74\x72\x61\x69\x74\x5F\x30\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6F\x72\x74\x72\x61\x69\x74\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x74\x68\x65\x5F\x74\x68\x69\x6E\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x61\x76\x65\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x75\x6E\x67\x6C\x65\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x75\x6E\x67\x6C\x65\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x75\x6E\x67\x6C\x65\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x75\x6E\x67\x6C\x65\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x75\x6E\x67\x6C\x65\x5F\x75\x6E\x64\x65\x72\x67\x72\x6F\x75\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x6F\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6C\x61\x63\x6F\x73\x74\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x65\x72\x72\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6E\x61\x6B\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x69\x6E\x74\x65\x72\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6C\x65\x66\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x69\x6E\x74\x65\x72\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x72\x69\x67\x68\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x69\x6E\x74\x65\x72\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x5F\x6D\x69\x64\x64\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x77\x69\x6E\x74\x65\x72\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x63\x6B\x5F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x63\x6B\x5F\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x65\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6E\x6F\x77\x6D\x61\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x72\x65\x73\x65\x6E\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x69\x72\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x65\x6A\x6D\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x6F\x67\x6F\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6B\x61\x74\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6E\x69\x63\x6F\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6A\x69\x72\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x67\x65\x6A\x6D\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x67\x6F\x67\x6F\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6B\x61\x74\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6E\x69\x63\x6F\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x7A\x6F\x6D\x62\x69\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x75\x6D\x69\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x67\x65\x6E\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x62\x62\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x61\x76\x65\x6D\x61\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x61\x73\x6B\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x6C\x66\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6B\x65\x6C\x65\x74\x6F\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x6E\x75\x62\x69\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x6D\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x75\x61\x72\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x6F\x72\x69\x6C\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x69\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x6C\x66\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x65\x78\x69\x74\x5F\x73\x69\x67\x6E\x5F\x73\x70\x72\x69\x74\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6E\x75\x6D\x62\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x72\x72\x6F\x77\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x37\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x36\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x35\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x34\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x6F\x6F\x72\x5F\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x70\x6C\x61\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x70\x6C\x61\x79\x5F\x68\x6F\x76\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x70\x6C\x61\x79\x5F\x64\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6A\x69\x72\x6B\x61\x5F\x73\x65\x6C\x65\x63\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x65\x6A\x6D\x72\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6B\x61\x74\x6B\x61\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x6F\x67\x6F\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6E\x69\x63\x6F\x6C\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6A\x69\x72\x6B\x61\x5F\x73\x65\x6C\x65\x63\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x67\x65\x6A\x6D\x72\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6B\x61\x74\x6B\x61\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x67\x6F\x67\x6F\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x75\x70\x65\x72\x5F\x6E\x69\x63\x6F\x6C\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x72\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6F\x6F\x6B\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x6F\x70\x69\x6E\x67\x5F\x62\x61\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x69\x6E\x65\x63\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x69\x61\x6D\x6F\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x5F\x70\x61\x74\x74\x65\x72\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x75\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x68\x6F\x76\x65\x72\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x64\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x79\x65\x73\x5F\x75\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x79\x65\x73\x5F\x64\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x6E\x6F\x5F\x75\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x6E\x6F\x5F\x64\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x78\x5F\x6E\x6F\x72\x6D\x61\x6C\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x78\x5F\x70\x72\x65\x73\x73\x65\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x75\x70\x67\x72\x61\x64\x65\x5F\x75\x70\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x75\x70\x67\x72\x61\x64\x65\x5F\x64\x6F\x77\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x74\x6E\x5F\x75\x70\x67\x72\x61\x64\x65\x5F\x64\x69\x73\x61\x62\x6C\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x63\x6F\x6E\x74\x69\x6E\x75\x65\x5F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x61\x6E\x64\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x6C\x75\x65\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x65\x64\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x6F\x6C\x64\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x69\x6E\x6B\x6F\x6E\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x67\x6F\x6C\x64\x6F\x6E\x65\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x69\x6E\x6B\x6F\x6E\x65\x5F\x62\x69\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x64\x61\x77\x61\x65\x2E\x70\x6E\x67",
  "\x6A\x69\x72\x6B\x61",
  "\x67\x65\x6A\x6D\x72",
  "\x6B\x61\x74\x6B\x61",
  "\x67\x6F\x67\x6F",
  "\x6E\x69\x63\x6F\x6C",
  "\x73\x75\x70\x65\x72\x5F\x6A\x69\x72\x6B\x61",
  "\x73\x75\x70\x65\x72\x5F\x67\x65\x6A\x6D\x72",
  "\x73\x75\x70\x65\x72\x5F\x6B\x61\x74\x6B\x61",
  "\x73\x75\x70\x65\x72\x5F\x67\x6F\x67\x6F",
  "\x73\x75\x70\x65\x72\x5F\x6E\x69\x63\x6F\x6C",
  "\x62\x6C\x75\x65\x6F\x6E\x65",
  "\x72\x65\x64\x6F\x6E\x65",
  "\x67\x6F\x6C\x64\x6F\x6E\x65",
  "\x70\x69\x6E\x6B\x6F\x6E\x65",
  "\x64\x61\x77\x61\x65",
  "\x74\x6F\x78\x69\x63",
  "\x6C\x61\x76\x61",
  "\x62\x61\x74",
  "\x70\x69\x64\x67\x65\x6F\x6E",
  "\x72\x6F\x74\x73\x70\x69\x6B\x65\x73",
  "\x73\x70\x69\x64\x65\x72",
  "\x73\x6E\x61\x6B\x65",
  "\x62\x65\x72\x72\x79",
  "\x73\x6E\x6F\x77\x6D\x61\x6E",
  "\x64\x6F\x6F\x72\x5F\x30",
  "\x64\x6F\x6F\x72\x5F\x31",
  "\x64\x6F\x6F\x72\x5F\x33",
  "\x64\x6F\x6F\x72\x5F\x34",
  "\x64\x6F\x6F\x72\x5F\x35",
  "\x64\x6F\x6F\x72\x5F\x36",
  "\x64\x6F\x6F\x72\x5F\x37",
  "\x72\x61\x74",
  "\x6C\x61\x63\x6F\x73\x74\x65",
  "\x6D\x65\x74\x72\x6F\x5F\x73\x69\x67\x6E\x5F\x73\x70\x72\x69\x74\x65",
  "\x73\x74\x65\x61\x6D\x5F\x73\x70\x72\x69\x74\x65",
  "\x63\x61\x6E\x64\x6C\x65\x73",
  "\x70\x6F\x72\x74\x72\x61\x69\x74\x5F\x61",
  "\x70\x6F\x72\x74\x72\x61\x69\x74\x5F\x62",
  "\x64\x65\x65\x72",
  "\x72\x61\x76\x65\x6E",
  "\x6A\x75\x6E\x67\x6C\x65",
  "\x6A\x75\x6E\x67\x6C\x65\x5F\x67\x72\x6F\x75\x6E\x64",
  "\x77\x6F\x6F\x64\x65\x6E\x62\x6F\x78",
  "\x75\x73\x65\x20\x73\x74\x72\x69\x63\x74",
  "\x63\x61\x6C\x6C",
  "\x53\x70\x72\x69\x74\x65",
  "\x69\x6E\x74\x65\x72\x61\x63\x74\x69\x76\x65",
  "\x62\x75\x74\x74\x6F\x6E\x4D\x6F\x64\x65",
  "\x69\x73\x4F\x76\x65\x72",
  "\x69\x6E\x44\x6F\x77\x6E",
  "\x74\x65\x78\x74\x75\x72\x65\x55\x70",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6F\x75\x74",
  "\x6F\x6E\x4F\x75\x74",
  "\x6F\x6E",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6F\x76\x65\x72",
  "\x6F\x6E\x4F\x76\x65\x72",
  "\x70\x6F\x69\x6E\x74\x65\x72\x75\x70\x6F\x75\x74\x73\x69\x64\x65",
  "\x6F\x6E\x55\x70",
  "\x70\x6F\x69\x6E\x74\x65\x72\x75\x70",
  "\x70\x6F\x69\x6E\x74\x65\x72\x64\x6F\x77\x6E",
  "\x6F\x6E\x44\x6F\x77\x6E",
  "\x70\x72\x6F\x74\x6F\x74\x79\x70\x65",
  "\x63\x72\x65\x61\x74\x65",
  "\x69\x73\x64\x6F\x77\x6E",
  "\x74\x65\x78\x74\x75\x72\x65\x4F\x76\x65\x72",
  "\x74\x65\x78\x74\x75\x72\x65",
  "\x74\x65\x78\x74\x75\x72\x65\x44\x6F\x77\x6E",
  "\x73\x65\x74\x45\x6E\x61\x62\x6C\x65",
  "\x74\x65\x78\x74\x75\x72\x65\x44\x69\x73\x61\x62\x6C\x65\x64",
  "\x72\x75\x6E\x6E\x69\x6E\x67",
  "\x75\x70\x64\x61\x74\x65",
  "\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72",
  "\x6F\x66\x66\x73\x65\x74",
  "\x73\x65\x6C\x65\x63\x74\x65\x64",
  "\x6C\x65\x6E\x67\x74\x68",
  "\x66\x72\x6F\x6D\x46\x72\x61\x6D\x65",
  "\x78",
  "\x61\x6E\x63\x68\x6F\x72",
  "\x79",
  "\x69\x64",
  "\x61\x64\x64\x43\x68\x69\x6C\x64",
  "\x67\x6C\x6F\x62\x61\x6C",
  "\x64\x61\x74\x61",
  "\x65\x78\x74\x72\x61\x63\x74",
  "\x73\x74\x61\x62\x69\x6C\x69\x7A\x65",
  "\x72\x6F\x75\x6E\x64",
  "\x6D\x6F\x76\x65\x42\x79",
  "\x6F\x6E\x4D\x6F\x76\x65",
  "\x61\x62\x73",
  "\x72\x6F\x74\x61\x74\x65\x4C\x65\x66\x74",
  "\x73\x65\x6C\x65\x63\x74",
  "\x63\x68\x69\x6C\x64\x72\x65\x6E",
  "\x65\x6D\x69\x74",
  "\x72\x6F\x74\x61\x74\x65\x52\x69\x67\x68\x74",
  "\x72\x65\x70\x6F\x73\x69\x74\x69\x6F\x6E",
  "\x73\x77\x69\x70\x65",
  "\x62\x69\x6E\x64",
  "\x61\x64\x64\x54\x77\x65\x65\x6E",
  "\x73\x69\x67\x6E",
  "\x73\x65\x74",
  "\x73\x63\x61\x6C\x65",
  "\x5F\x73\x74\x61\x74\x75\x73",
  "\x69\x6E\x73\x74\x61\x6E\x63\x65\x20\x63\x72\x65\x61\x74\x65\x64",
  "\x5F\x63\x65\x6E\x74\x65\x72\x58",
  "\x67\x61\x6D\x65\x57\x69\x64\x74\x68",
  "\x5F\x63\x65\x6E\x74\x65\x72\x59",
  "\x67\x61\x6D\x65\x48\x65\x69\x67\x68\x74",
  "\x5F\x72\x61\x64\x69\x75\x73",
  "\x6C\x6F\x61\x64\x41\x73\x73\x65\x74\x73",
  "\x70\x72\x65\x6C\x6F\x61\x64\x69\x6E\x67",
  "\x73\x6F\x75\x6E\x64\x73",
  "\x63\x72\x6F\x77\x6E",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x63\x72\x6F\x77\x6E\x5F\x70\x69\x63\x6B\x75\x70\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x63\x72\x6F\x77\x6E\x5F\x70\x69\x63\x6B\x75\x70\x2E\x6D\x70\x33",
  "\x67\x61\x6D\x65\x6F\x76\x65\x72",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x65\x6E\x64\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x65\x6E\x64\x2E\x6D\x70\x33",
  "\x63\x6F\x6D\x70\x6C\x65\x74\x65",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6C\x65\x76\x65\x6C\x63\x6F\x6D\x70\x6C\x65\x74\x65\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6C\x65\x76\x65\x6C\x63\x6F\x6D\x70\x6C\x65\x74\x65\x2E\x6D\x70\x33",
  "\x6A\x75\x6D\x70",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6A\x75\x6D\x70\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6A\x75\x6D\x70\x2E\x6D\x70\x33",
  "\x6E\x65\x77\x63\x68\x61\x73\x65\x72",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6E\x65\x77\x63\x68\x61\x73\x65\x72\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x4A\x4B\x5F\x6E\x65\x77\x63\x68\x61\x73\x65\x72\x2E\x6D\x70\x33",
  "\x76\x6F\x69\x63\x65\x5F\x30",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x30\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x30\x2E\x6D\x70\x33",
  "\x76\x6F\x69\x63\x65\x5F\x31",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x31\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x31\x2E\x6D\x70\x33",
  "\x76\x6F\x69\x63\x65\x5F\x32",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x32\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x32\x2E\x6D\x70\x33",
  "\x76\x6F\x69\x63\x65\x5F\x33",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x33\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x33\x2E\x6D\x70\x33",
  "\x76\x6F\x69\x63\x65\x5F\x34",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x34\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x76\x6F\x69\x63\x65\x5F\x34\x2E\x6D\x70\x33",
  "\x62\x69\x74\x6D\x61\x70\x73",
  "\x61\x64\x64",
  "\x6C\x6F\x61\x64\x65\x72",
  "\x61\x73\x73\x65\x74\x73\x4C\x6F\x61\x64\x43\x6F\x6D\x70\x6C\x65\x74\x65",
  "\x6C\x6F\x61\x64",
  "\x63\x72\x65\x61\x74\x65\x53\x63\x65\x6E\x65",
  "\x67\x65\x6E\x65\x72\x61\x74\x69\x6E\x67\x20\x73\x63\x65\x6E\x65",
  "\x64\x65\x76\x69\x63\x65\x50\x69\x78\x65\x6C\x52\x61\x74\x69\x6F",
  "\x5F\x74\x75\x74\x6F\x72\x69\x61\x6C",
  "\x69\x73\x57\x65\x62\x47\x4C\x53\x75\x70\x70\x6F\x72\x74\x65\x64",
  "\x75\x74\x69\x6C\x73",
  "\x5F\x73\x74\x61\x67\x65",
  "\x5F\x72\x65\x6E\x64\x65\x72\x65\x72",
  "\x61\x75\x74\x6F\x44\x65\x74\x65\x63\x74\x52\x65\x6E\x64\x65\x72\x65\x72",
  "\x76\x69\x65\x77",
  "\x61\x70\x70\x65\x6E\x64\x43\x68\x69\x6C\x64",
  "\x67\x6D\x34\x68\x74\x6D\x6C\x35\x5F\x64\x69\x76\x5F\x69\x64",
  "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64",
  "\x73\x70\x72\x69\x74\x65\x73",
  "\x73\x68\x61\x72\x65\x64",
  "\x74\x69\x63\x6B\x65\x72",
  "\x61\x75\x74\x6F\x53\x74\x61\x72\x74",
  "\x73\x74\x6F\x70",
  "\x62\x67",
  "\x65\x78\x74\x72\x61\x73",
  "\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x75\x70",
  "\x76\x69\x73\x69\x62\x6C\x65",
  "\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x64\x6F\x77\x6E",
  "\x62\x74\x6E\x5F\x6D\x65\x6E\x75\x5F\x68\x6F\x76\x65\x72",
  "\x5F\x70\x61\x75\x73\x65",
  "\x5F\x69\x6E\x4D\x65\x6E\x75",
  "\x68\x69\x64\x65\x43\x68\x6F\x73\x65\x53\x63\x72\x65\x65\x6E",
  "\x73\x68\x6F\x77\x43\x68\x6F\x73\x65\x53\x63\x72\x65\x65\x6E",
  "\x73\x70\x65\x65\x64\x58",
  "\x73\x70\x65\x65\x64\x59",
  "\x6A\x75\x6D\x70\x52\x65\x61\x64\x79",
  "\x64\x72\x6F\x70\x52\x65\x61\x64\x79",
  "\x68\x69\x74\x42\x6F\x78",
  "\x61\x64\x64\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x72\x75\x6E",
  "\x64\x65\x61\x74\x68",
  "\x73\x65\x74\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x70\x6C\x61\x79\x65\x72",
  "\x62\x65\x67\x69\x6E\x46\x69\x6C\x6C",
  "\x64\x72\x61\x77\x52\x65\x63\x74",
  "\x70\x61\x74\x74\x65\x72\x6E",
  "\x6D\x65\x6E\x75\x5F\x70\x61\x74\x74\x65\x72\x6E",
  "\x74\x69\x74\x6C\x65",
  "\x43\x48\x4F\x4F\x53\x45\x20\x59\x4F\x55\x52\x20\x43\x48\x41\x52\x41\x43\x54\x45\x52",
  "\x50\x69\x78\x65\x6C\x65\x64",
  "\x63\x65\x6E\x74\x65\x72",
  "\x63\x6F\x6C\x6C\x65\x63\x74\x69\x62\x6C\x65",
  "\x63\x6F\x6C\x6C\x65\x63\x74\x69\x6F\x6E\x43\x6F\x75\x6E\x74",
  "",
  "\x6C\x61\x62\x65\x6C",
  "\x43\x4F\x4D\x4D\x41\x4E\x44\x45\x52",
  "\x73\x65\x6C\x65\x63\x74\x6F\x72",
  "\x67\x6F\x6C\x64\x6F\x6E\x65\x5F\x73\x65\x6C\x65\x63\x74",
  "\x70\x69\x6E\x6B\x6F\x6E\x65\x5F\x73\x65\x6C\x65\x63\x74",
  "\x6C\x69\x6E\x65\x61\x72",
  "\x74\x65\x78\x74",
  "\x63\x6F\x6C\x6C\x65\x63\x74\x69\x6F\x6E",
  "\x73\x61\x76\x65\x53\x74\x61\x74\x65",
  "\x51\x55\x45\x45\x4E",
  "\x62\x74\x6E\x5F\x63\x61\x6E\x63\x65\x6C",
  "\x62\x74\x6E\x5F\x78\x5F\x75\x70",
  "\x62\x74\x6E\x5F\x78\x5F\x64\x6F\x77\x6E",
  "\x63\x6F\x6E\x66\x69\x72\x6D",
  "\x62\x74\x6E\x5F\x73\x74\x61\x72\x74",
  "\x62\x74\x6E\x5F\x73\x74\x61\x72\x74\x5F\x64\x6F\x77\x6E",
  "\x62\x74\x6E\x5F\x73\x74\x61\x72\x74\x5F\x68\x6F\x76\x65\x72",
  "\x73\x65\x6C\x65\x63\x74\x43\x68\x61\x72\x61\x63\x74\x65\x72",
  "\x63\x6F\x6E\x74\x69\x6E\x75\x65\x5F\x62\x67",
  "\x62\x74\x6E\x5F\x6F\x6B",
  "\x62\x74\x6E\x5F\x79\x65\x73\x5F\x75\x70",
  "\x62\x74\x6E\x5F\x79\x65\x73\x5F\x64\x6F\x77\x6E",
  "\x62\x75\x79\x43\x6F\x6E\x74\x69\x6E\x75\x65",
  "\x62\x74\x6E\x5F\x6E\x6F\x5F\x75\x70",
  "\x62\x74\x6E\x5F\x6E\x6F\x5F\x64\x6F\x77\x6E",
  "\x68\x69\x64\x65\x43\x6F\x6E\x74\x69\x6E\x75\x65\x53\x63\x72\x65\x65\x6E",
  "\x72\x65\x6E\x64\x65\x72",
  "\x65\x6E\x64\x47\x61\x6D\x65",
  "\x63\x6F\x6C\x49\x63\x6F\x6E",
  "\x63\x6F\x73\x74",
  "\x2D",
  "\x74\x6F\x74\x61\x6C\x49\x63\x6F\x6E",
  "\x74\x6F\x74\x61\x6C",
  "\x30",
  "\x68\x61\x6E\x64",
  "\x73\x74\x61\x74\x73",
  "\x5F\x64\x69\x73\x70\x6C\x61\x79\x4C\x69\x73\x74",
  "\x72\x65\x73\x69\x7A\x65",
  "\x62\x69\x6E\x64\x45\x76\x65\x6E\x74\x73",
  "\x6D\x6F\x75\x73\x65\x75\x70",
  "\x6D\x6F\x75\x73\x65\x43\x6C\x69\x63\x6B\x48\x61\x6E\x64\x6C\x65\x72",
  "\x74\x6F\x75\x63\x68\x73\x74\x61\x72\x74",
  "\x5F\x73\x77\x69\x70\x69\x6E\x67",
  "\x5F\x6D\x6F\x75\x73\x65\x54\x6D\x70",
  "\x5F\x6C\x6F\x63\x6B\x65\x64",
  "\x5F\x73\x77\x69\x70\x65\x53\x70\x65\x65\x64",
  "\x70\x6F\x69\x6E\x74\x65\x72\x6D\x6F\x76\x65",
  "\x5F\x61\x6C\x69\x76\x65",
  "\x61\x64\x64\x41\x63\x74\x69\x6F\x6E",
  "\x72\x65\x63\x6F\x72\x64\x44\x61\x74\x61",
  "\x6D\x6F\x6F\x6E\x64\x72\x61\x67",
  "\x6B\x65\x79\x64\x6F\x77\x6E",
  "\x6B\x65\x79\x44\x6F\x77\x6E\x48\x61\x6E\x64\x6C\x65\x72",
  "\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72",
  "\x6B\x65\x79\x75\x70",
  "\x6B\x65\x79\x55\x70\x48\x61\x6E\x64\x6C\x65\x72",
  "\x5F\x6D\x75\x74\x65",
  "\x69\x6E\x6E\x65\x72\x57\x69\x64\x74\x68",
  "\x69\x6E\x6E\x65\x72\x48\x65\x69\x67\x68\x74",
  "\x6D\x61\x72\x67\x69\x6E\x4C\x65\x66\x74",
  "\x73\x74\x79\x6C\x65",
  "\x70\x78",
  "\x77\x69\x64\x74\x68",
  "\x68\x65\x69\x67\x68\x74",
  "\x5F\x69\x73\x54\x75\x74\x6F\x72\x69\x61\x6C",
  "\x72\x65\x70\x6C\x61\x79\x44\x61\x74\x61",
  "\x70\x61\x72\x73\x65",
  "\x70\x6C\x61\x79\x65\x64",
  "\x75\x70\x67\x72\x61\x64\x65\x73",
  "\x69\x6E\x69\x74\x20\x76\x61\x72\x69\x61\x62\x6C\x65\x73",
  "\x5F\x6B\x65\x79\x49\x73\x44\x6F\x77\x6E",
  "\x5F\x73\x63\x72\x65\x65\x6E\x4C\x6F\x63\x6B",
  "\x5F\x72\x65\x61\x64\x79",
  "\x5F\x74",
  "\x5F\x64\x69\x73\x74\x61\x6E\x63\x65",
  "\x5F\x6E\x75\x6D\x73",
  "\x5F\x77\x61\x73\x74\x65\x64",
  "\x5F\x6C\x65\x76\x65\x6C",
  "\x5F\x74\x69\x6D\x65\x53\x63\x61\x6C\x65",
  "\x5F\x6F\x62\x73\x74\x61\x63\x6C\x65\x73",
  "\x5F\x74\x72\x61\x70\x73",
  "\x5F\x65\x6E\x65\x6D\x69\x65\x73",
  "\x5F\x73\x65\x6C\x65\x63\x74\x65\x64\x43\x68\x61\x72\x61\x63\x74\x65\x72",
  "\x5F\x63\x72\x6F\x77\x6E\x73",
  "\x5F\x73\x63\x6F\x72\x65",
  "\x63\x72\x65\x61\x74\x65\x4C\x65\x76\x65\x6C",
  "\x73\x74\x61\x72\x74",
  "\x73\x74\x61\x72\x74\x47\x61\x6D\x65",
  "\x65\x6D\x69\x74\x74\x65\x72",
  "\x67\x61\x6D\x65\x52\x65\x61\x64\x79",
  "\x72\x65\x73\x65\x74\x4C\x65\x76\x65\x6C",
  "\x75\x70\x64\x61\x74\x65\x53\x63\x6F\x72\x65",
  "\x67\x61\x6D\x65\x20\x73\x74\x61\x72\x74\x65\x64",
  "\x67\x61\x6D\x65\x20\x73\x74\x61\x72\x74",
  "\x6C\x6F\x67",
  "\x72\x75\x6E\x47\x61\x6D\x65",
  "\x73\x74\x6F\x70\x47\x61\x6D\x65",
  "\x73\x61\x76\x65",
  "\x67\x61\x6D\x65\x4F\x76\x65\x72",
  "\x73\x74\x72\x69\x6E\x67\x69\x66\x79",
  "\x67\x61\x6D\x65\x53\x61\x76\x65",
  "\x72\x65\x6D\x6F\x76\x65\x43\x68\x69\x6C\x64",
  "\x64\x65\x73\x74\x72\x6F\x79",
  "\x65\x78\x69\x74",
  "\x72\x65\x6D\x6F\x76\x65",
  "\x65\x6E\x65\x6D\x79\x5F",
  "\x61\x6C\x70\x68\x61",
  "\x69\x64\x64\x6C\x65",
  "\x6C\x61\x73\x74\x70\x6F\x73",
  "\x72\x65\x67\x65\x6E\x65\x72\x61\x74\x65\x43\x72\x6F\x77\x6E",
  "\x30\x2F\x31\x32",
  "\x72\x65\x73\x74\x6F\x72\x65\x45\x6E\x65\x6D\x69\x65\x73",
  "\x74\x79\x70\x65",
  "\x73\x74\x61\x6D\x70",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x45\x6E\x65\x6D\x79",
  "\x6F\x66\x66\x65\x72\x43\x6F\x6E\x74\x69\x6E\x75\x65",
  "\x73\x68\x6F\x77\x43\x6F\x6E\x74\x69\x6E\x75\x65\x53\x63\x72\x65\x65\x6E",
  "\x72\x65\x73\x6F\x75\x72\x63\x65\x73",
  "\x73\x65\x74\x20\x68\x69\x74\x62\x6F\x78",
  "\x68\x69\x64\x65\x54\x75\x74\x6F\x72\x69\x61\x6C",
  "\x73\x74\x61\x72\x74\x54\x75\x74\x6F\x72\x69\x61\x6C",
  "\x72\x65\x73\x74\x61\x72\x74\x47\x61\x6D\x65",
  "\x61\x64\x64\x54\x6F\x50\x6C\x61\x79\x6C\x69\x73\x74",
  "\x6C\x65\x76\x65\x6C\x73",
  "\x70\x6C\x61\x74\x66\x6F\x72\x6D\x73",
  "\x65\x6E\x76\x69\x72\x6F\x6E\x6D\x65\x6E\x74",
  "\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x4C\x65\x66\x74",
  "\x61\x64\x64\x43\x68\x69\x6C\x64\x41\x74",
  "\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x52\x69\x67\x68\x74",
  "\x73\x69\x7A\x65",
  "\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D",
  "\x70\x75\x73\x68",
  "\x63\x69\x74\x79",
  "\x5F\x70\x6C\x61\x74\x66\x6F\x72\x6D\x42\x6F\x74\x74\x6F\x6D",
  "\x77\x69\x6E\x74\x65\x72",
  "\x45\x4D\x50\x54\x59",
  "\x54\x65\x78\x74\x75\x72\x65",
  "\x72\x61\x6E\x64\x6F\x6D",
  "\x62\x6F\x77",
  "\x73\x74\x61\x74\x69\x63\x73",
  "\x6D\x65\x74\x72\x6F\x5F\x73\x69\x67\x6E",
  "\x65\x78\x69\x74\x5F\x73\x69\x67\x6E",
  "\x69\x64\x6C\x65",
  "\x61\x64\x64\x4D\x75\x6C\x74\x69\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x73\x74\x61\x74\x69\x63",
  "\x73\x74\x65\x61\x6D",
  "\x73\x63\x61\x6C\x65\x58",
  "\x73\x63\x61\x6C\x65\x59",
  "\x61\x6E\x63\x68\x6F\x72\x58",
  "\x61\x6E\x63\x68\x6F\x72\x59",
  "\x6F\x62\x73\x74\x61\x63\x6C\x65\x73",
  "\x62\x61\x72\x72\x65\x6C",
  "\x74\x6F\x78\x69\x73\x62\x61\x72\x72\x65\x6C",
  "\x74\x65\x6C\x65\x70\x68\x6F\x6E\x65",
  "\x70\x72\x65\x73\x65\x6E\x74",
  "\x6F\x62\x73\x74\x61\x63\x6C\x65",
  "\x74\x72\x61\x70\x73",
  "\x66\x6C\x79",
  "\x74\x72\x61\x70",
  "\x66\x6C\x6F\x77",
  "\x72\x6F\x74\x61\x74\x65\x73",
  "\x73\x70\x69\x6B\x65\x73",
  "\x74\x6F\x78\x69\x63\x70\x69\x74",
  "\x74\x68\x69\x6E\x67",
  "\x6A\x75\x6E\x67\x6C\x65\x5F\x62\x67",
  "\x61\x72\x72\x69\x76\x65",
  "\x65\x67\x79\x70\x74\x5F\x72\x69\x76\x65\x72",
  "\x74\x69\x6C\x65\x50\x6F\x73\x69\x74\x69\x6F\x6E\x58",
  "\x74\x69\x6C\x65\x50\x6F\x73\x69\x74\x69\x6F\x6E",
  "\x4C\x45\x56\x45\x4C\x20",
  "\x2F",
  "\x65\x6E\x64\x4C\x65\x76\x65\x6C",
  "\x65\x61\x73\x65\x49\x6E\x51\x75\x61\x64",
  "\x73\x6C\x69\x63\x65",
  "\x65\x61\x73\x65\x4F\x75\x74\x51\x75\x61\x64",
  "\x63\x68\x65\x63\x6B\x50\x6C\x61\x74\x66\x6F\x72\x6D",
  "\x64\x65\x6C\x61\x79",
  "\x74\x69\x63\x6B",
  "\x73\x70\x65\x65\x64\x53\x63\x61\x6C\x65",
  "\x70\x6C\x61\x79",
  "\x76\x6F\x69\x63\x65\x5F",
  "\x73\x6E\x64",
  "\x74\x69\x6D\x65\x73",
  "\x73\x68\x69\x66\x74",
  "\x61\x63\x74\x69\x6F\x6E\x73",
  "\x6B\x69\x6C\x6C\x50\x6C\x61\x79\x65\x72",
  "\x6E\x75\x6D\x62\x65\x72",
  "\x70\x61\x72\x65\x6E\x74",
  "\x73\x68\x6F\x77\x4C\x65\x76\x65\x6C\x45\x78\x69\x74",
  "\x64\x79",
  "\x64\x78",
  "\x61\x64\x64\x45\x6E\x65\x6D\x79\x41\x63\x74\x69\x6F\x6E",
  "\x6F\x70\x65\x6E",
  "\x73\x74\x6F\x70\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x67\x65\x74\x41\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x65\x61\x73\x65\x4F\x75\x74\x53\x69\x6E\x65",
  "\x74\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E\x73",
  "\x65\x61\x73\x65\x4F\x75\x74\x42\x61\x63\x6B",
  "\x65\x6E\x64",
  "\x73\x68\x6F\x77\x47\x61\x6D\x65\x4F\x76\x65\x72",
  "\x66\x72\x65\x65\x7A\x65\x45\x6E\x65\x6D\x69\x65\x73",
  "\x7A\x6F\x6D\x62\x69",
  "\x74\x69\x6D\x65\x4F\x66\x66\x73\x65\x74",
  "\x62\x6C\x69\x6E\x6B\x54\x69\x6D\x65",
  "\x66\x6C\x6F\x6F\x72",
  "\x69\x6E\x64\x65\x78\x4F\x66",
  "\x63\x6F\x6E\x63\x61\x74",
  "\x64\x75\x6E\x67\x65\x6F\x6E",
  "\x31",
  "\x65\x67\x79\x70\x74",
  "\x32",
  "\x6D\x65\x74\x72\x6F",
  "\x33",
  "\x34",
  "\x68\x6F\x75\x73\x65",
  "\x36",
  "\x35",
  "\x6F\x63\x63\x75\x70\x69\x65\x64",
  "\x64\x6F\x6F\x72\x5F",
  "\x72\x65\x64\x75\x63\x65",
  "\x5F\x72\x75\x6E\x6E\x69\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x20\x6C\x6F\x61\x64\x65\x64",
  "\x6B\x65\x79\x43\x6F\x64\x65",
  "\x73\x70\x6C\x69\x63\x65",
  "\x65\x72\x72\x6F\x72\x5F\x20\x70\x6F\x6F\x6C\x20\x63\x6C\x65\x61\x72\x69\x6E\x67",
  "\x73\x71\x72\x74",
  "\x50\x49",
  "\x6D\x75\x74\x65",
  "\x75\x6E\x6D\x75\x74\x65",
  "\x70\x61\x75\x73\x65",
  "\x70\x61\x75\x7A\x61",
  "\x72\x65\x73\x75\x6D\x65",
  "\x72\x65\x73\x74\x61\x72\x74",
  "\x67\x61\x6D\x65\x65\x20\x69\x6E\x69\x74",
  "\x46\x75\x6C\x6C\x53\x63\x72\x65\x65\x6E",
  "\x67\x61\x6D\x65\x49\x6E\x69\x74",
  "\x6F\x6E\x6C\x6F\x61\x64",
  "\x74\x6F\x75\x63\x68\x61\x62\x6C\x65",
  "\x6F\x6E\x74\x6F\x75\x63\x68\x73\x74\x61\x72\x74",
  "\x6D\x61\x78\x54\x6F\x75\x63\x68\x50\x6F\x69\x6E\x74\x73",
  "\x66\x69\x6E\x69\x73\x68",
  "\x74\x77\x65\x65\x6E\x73",
  "\x5F\x74\x61\x72\x67\x65\x74",
  "\x61\x64\x64\x46\x72\x61\x6D\x65\x54\x77\x65\x65\x6E",
  "\x54\x77\x65\x65\x6E",
  "\x5F\x70\x72\x6D\x73",
  "\x5F\x70\x72\x6F\x70\x73\x51\x75\x65\x75\x65",
  "\x5F\x70\x72\x6F\x70\x73\x53\x74\x61\x72\x74",
  "\x5F\x70\x72\x6F\x70\x73\x45\x6E\x64",
  "\x5F\x65\x6C\x61\x70\x73\x65\x64",
  "\x64\x65\x66",
  "\x5F\x65\x6C\x61\x70\x73\x65",
  "\x6F\x6E\x43\x6F\x6D\x70\x6C\x65\x74\x65",
  "\x74\x69\x6D\x65",
  "\x74\x72\x61\x6E\x73\x69\x74\x69\x6F\x6E",
  "\x63\x6F\x6E\x73\x74\x72\x75\x63\x74\x6F\x72",
  "\x63\x65\x69\x6C",
  "\x6F\x6E\x55\x70\x64\x61\x74\x65",
  "\x6C\x6F\x6F\x70",
  "\x61\x73\x69\x6E",
  "\x70\x6F\x77",
  "\x73\x69\x6E",
  "\x63\x6F\x73",
  "\x65\x61\x73\x65\x4F\x75\x74\x42\x6F\x75\x6E\x63\x65",
  "\x65\x61\x73\x65\x49\x6E\x42\x6F\x75\x6E\x63\x65",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x73",
  "\x5F\x6C\x6F\x6F\x70",
  "\x5F\x66\x70\x73",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E",
  "\x5F\x70\x6C\x61\x79\x6C\x69\x73\x74",
  "\x72\x65\x76\x65\x72\x73\x65",
  "\x70\x6F\x70",
  "\x5F\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x4E\x61\x6D\x65",
  "\x63\x6C\x65\x61\x72\x50\x6C\x61\x79\x6C\x69\x73\x74",
  "\x67\x6F\x74\x6F\x4E\x65\x78\x74",
  "\x6E\x61\x6D\x65",
  "\x6C\x6F\x6F\x70\x73",
  "\x66\x70\x73",
  "\x72\x65\x73\x65\x74",
  "\x42\x69\x74\x6D\x61\x70\x54\x65\x78\x74",
  "\x64\x65\x66\x69\x6E\x65\x50\x72\x6F\x70\x65\x72\x74\x69\x65\x73",
  "\x63\x6F\x6E\x74\x61\x69\x6E\x73",
  "\x50\x6F\x6C\x79\x67\x6F\x6E",
  "\x70\x6F\x69\x6E\x74\x73",
  "\x50\x61\x72\x73\x65\x54\x69\x6C\x65",
  "\x73\x6F\x75\x72\x63\x65",
  "\x74\x65\x78\x74\x75\x72\x65\x73",
  "\x66\x72\x61\x6D\x65\x73",
  "\x5F",
  "\x66\x72\x61\x6D\x65\x57\x69\x64\x74\x68",
  "\x66\x72\x61\x6D\x65\x48\x65\x69\x67\x68\x74",
  "\x62\x61\x73\x65\x54\x65\x78\x74\x75\x72\x65",
  "\x63\x6C\x6F\x6E\x65",
  "\x54\x65\x78\x74\x75\x72\x65\x43\x61\x63\x68\x65",
];
window[_0xdaa5[0]] = {
  version: 2,
  gameMaxHeight: 1140,
  gameWidth: 640,
  gameHeight: 640,
  fonts: {},
  bitmaps: {
    dungeon_platformLeft: _0xdaa5[1],
    dungeon_platformRight: _0xdaa5[2],
    dungeon_platform: _0xdaa5[3],
    door_0: _0xdaa5[4],
    bg: _0xdaa5[5],
    ground: _0xdaa5[6],
    collomn: _0xdaa5[7],
    grid: _0xdaa5[8],
    steam: _0xdaa5[9],
    steam_sprite: _0xdaa5[10],
    rat: _0xdaa5[11],
    woodenbox: _0xdaa5[12],
    bat: _0xdaa5[13],
    egypt_platformLeft: _0xdaa5[14],
    egypt_platformRight: _0xdaa5[15],
    egypt_platform: _0xdaa5[16],
    door_1: _0xdaa5[17],
    egypt_bg: _0xdaa5[18],
    egypt_ground: _0xdaa5[19],
    egypt_column: _0xdaa5[20],
    egypt_river: _0xdaa5[21],
    egypt_boat: _0xdaa5[22],
    sarcophag: _0xdaa5[23],
    rotspikes: _0xdaa5[24],
    spikes: _0xdaa5[25],
    lava: _0xdaa5[26],
    metro_platformLeft: _0xdaa5[27],
    metro_platformRight: _0xdaa5[28],
    metro_platform: _0xdaa5[29],
    door_2: _0xdaa5[4],
    metro_bg: _0xdaa5[30],
    metro_ground: _0xdaa5[31],
    metro_strip: _0xdaa5[32],
    metro_elbox: _0xdaa5[33],
    metro_train: _0xdaa5[34],
    metro_sign: _0xdaa5[35],
    barrel: _0xdaa5[36],
    toxic: _0xdaa5[37],
    train_front: _0xdaa5[38],
    train_middle: _0xdaa5[39],
    train_connect: _0xdaa5[40],
    city_platformLeft: _0xdaa5[41],
    city_platformRight: _0xdaa5[42],
    city_platform: _0xdaa5[43],
    city_platformBottom: _0xdaa5[44],
    city_bg: _0xdaa5[45],
    city_ground: _0xdaa5[46],
    pidgeon: _0xdaa5[47],
    telephone: _0xdaa5[48],
    streetLight: _0xdaa5[49],
    bus: _0xdaa5[50],
    house_platformLeft: _0xdaa5[41],
    house_platformRight: _0xdaa5[42],
    house_platform: _0xdaa5[43],
    house_bg: _0xdaa5[51],
    house_ground: _0xdaa5[52],
    spidernet: _0xdaa5[53],
    spider: _0xdaa5[54],
    candles: _0xdaa5[55],
    portrait_a: _0xdaa5[56],
    portrait_b: _0xdaa5[57],
    thing: _0xdaa5[58],
    raven: _0xdaa5[59],
    jungle_platformLeft: _0xdaa5[60],
    jungle_platformRight: _0xdaa5[61],
    jungle_platform: _0xdaa5[62],
    jungle_bg: _0xdaa5[63],
    jungle_ground: _0xdaa5[64],
    log: _0xdaa5[65],
    lacoste: _0xdaa5[66],
    berry: _0xdaa5[67],
    snake: _0xdaa5[68],
    winter_platformLeft: _0xdaa5[69],
    winter_platformRight: _0xdaa5[70],
    winter_platform: _0xdaa5[71],
    winter_bg: _0xdaa5[72],
    sock_1: _0xdaa5[73],
    sock_2: _0xdaa5[74],
    deer: _0xdaa5[75],
    snowman: _0xdaa5[76],
    present: _0xdaa5[77],
    jirka: _0xdaa5[78],
    gejmr: _0xdaa5[79],
    gogo: _0xdaa5[80],
    katka: _0xdaa5[81],
    nicol: _0xdaa5[82],
    super_jirka: _0xdaa5[83],
    super_gejmr: _0xdaa5[84],
    super_gogo: _0xdaa5[85],
    super_katka: _0xdaa5[86],
    super_nicol: _0xdaa5[87],
    zombi: _0xdaa5[88],
    mumi: _0xdaa5[89],
    agent: _0xdaa5[90],
    bobby: _0xdaa5[91],
    caveman: _0xdaa5[92],
    mask: _0xdaa5[93],
    elf: _0xdaa5[94],
    skeleton: _0xdaa5[95],
    anubis: _0xdaa5[96],
    hm: _0xdaa5[97],
    guard: _0xdaa5[98],
    gorila: _0xdaa5[99],
    it: _0xdaa5[100],
    elfka: _0xdaa5[101],
    metro_sign_sprite: _0xdaa5[102],
    number: _0xdaa5[103],
    arrow: _0xdaa5[104],
    door_7: _0xdaa5[105],
    door_6: _0xdaa5[106],
    door_5: _0xdaa5[107],
    door_4: _0xdaa5[108],
    door_3: _0xdaa5[109],
    btn_start: _0xdaa5[110],
    btn_start_hover: _0xdaa5[111],
    btn_start_down: _0xdaa5[112],
    jirka_select: _0xdaa5[113],
    gejmr_select: _0xdaa5[114],
    katka_select: _0xdaa5[115],
    gogo_select: _0xdaa5[116],
    nicol_select: _0xdaa5[117],
    super_jirka_select: _0xdaa5[118],
    super_gejmr_select: _0xdaa5[119],
    super_katka_select: _0xdaa5[120],
    super_gogo_select: _0xdaa5[121],
    super_nicol_select: _0xdaa5[122],
    crown: _0xdaa5[123],
    book: _0xdaa5[124],
    bag: _0xdaa5[125],
    pinecone: _0xdaa5[126],
    diamond: _0xdaa5[127],
    menu_pattern: _0xdaa5[128],
    btn_menu_up: _0xdaa5[129],
    btn_menu_hover: _0xdaa5[130],
    btn_menu_down: _0xdaa5[131],
    btn_yes_up: _0xdaa5[132],
    btn_yes_down: _0xdaa5[133],
    btn_no_up: _0xdaa5[134],
    btn_no_down: _0xdaa5[135],
    btn_x_up: _0xdaa5[136],
    btn_x_down: _0xdaa5[137],
    btn_upgrade_up: _0xdaa5[138],
    btn_upgrade_down: _0xdaa5[139],
    btn_upgrade_disable: _0xdaa5[140],
    continue_bg: _0xdaa5[141],
    hand: _0xdaa5[142],
    blueone: _0xdaa5[143],
    redone: _0xdaa5[144],
    goldone: _0xdaa5[145],
    pinkone: _0xdaa5[146],
    goldone_select: _0xdaa5[147],
    pinkone_select: _0xdaa5[148],
    dawae: _0xdaa5[149],
  },
  sprites: {
    jirka: {
      source: _0xdaa5[150],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    gejmr: {
      source: _0xdaa5[151],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    katka: {
      source: _0xdaa5[152],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    gogo: { source: _0xdaa5[153], frames: 19, frameWidth: 64, frameHeight: 72 },
    nicol: {
      source: _0xdaa5[154],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    super_jirka: {
      source: _0xdaa5[155],
      frames: 19,
      frameWidth: 64,
      frameHeight: 75,
    },
    super_gejmr: {
      source: _0xdaa5[156],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    super_katka: {
      source: _0xdaa5[157],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    super_gogo: {
      source: _0xdaa5[158],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    super_nicol: {
      source: _0xdaa5[159],
      frames: 19,
      frameWidth: 64,
      frameHeight: 72,
    },
    blueone: {
      source: _0xdaa5[160],
      frames: 10,
      frameWidth: 81,
      frameHeight: 60,
    },
    redone: {
      source: _0xdaa5[161],
      frames: 10,
      frameWidth: 81,
      frameHeight: 60,
    },
    goldone: {
      source: _0xdaa5[162],
      frames: 10,
      frameWidth: 81,
      frameHeight: 81,
    },
    pinkone: {
      source: _0xdaa5[163],
      frames: 10,
      frameWidth: 81,
      frameHeight: 97,
    },
    dawae: {
      source: _0xdaa5[164],
      frames: 2,
      frameWidth: 186,
      frameHeight: 118,
    },
    toxic: {
      source: _0xdaa5[165],
      frames: 4,
      frameWidth: 104,
      frameHeight: 162,
    },
    lava: {
      source: _0xdaa5[166],
      frames: 5,
      frameWidth: 104,
      frameHeight: 178,
    },
    bat: { source: _0xdaa5[167], frames: 2, frameWidth: 85, frameHeight: 56 },
    pidgeon: {
      source: _0xdaa5[168],
      frames: 4,
      frameWidth: 108,
      frameHeight: 66,
    },
    rotspikes: {
      source: _0xdaa5[169],
      frames: 3,
      frameWidth: 108,
      frameHeight: 109,
    },
    spider: {
      source: _0xdaa5[170],
      frames: 2,
      frameWidth: 88,
      frameHeight: 62,
    },
    snake: { source: _0xdaa5[171], frames: 6, frameWidth: 72, frameHeight: 64 },
    berry: {
      source: _0xdaa5[172],
      frames: 10,
      frameWidth: 116,
      frameHeight: 134,
    },
    snowman: {
      source: _0xdaa5[173],
      frames: 2,
      frameWidth: 132,
      frameHeight: 136,
    },
    door_0: {
      source: _0xdaa5[174],
      frames: 6,
      frameWidth: 108,
      frameHeight: 126,
    },
    door_1: {
      source: _0xdaa5[175],
      frames: 6,
      frameWidth: 120,
      frameHeight: 127,
    },
    door_2: {
      source: _0xdaa5[176],
      frames: 6,
      frameWidth: 108,
      frameHeight: 126,
    },
    door_3: {
      source: _0xdaa5[177],
      frames: 6,
      frameWidth: 108,
      frameHeight: 126,
    },
    door_4: {
      source: _0xdaa5[178],
      frames: 6,
      frameWidth: 121,
      frameHeight: 126,
    },
    door_5: {
      source: _0xdaa5[179],
      frames: 6,
      frameWidth: 116,
      frameHeight: 126,
    },
    door_6: {
      source: _0xdaa5[180],
      frames: 6,
      frameWidth: 108,
      frameHeight: 126,
    },
    rat: { source: _0xdaa5[181], frames: 6, frameWidth: 92, frameHeight: 80 },
    lacoste: {
      source: _0xdaa5[182],
      frames: 3,
      frameWidth: 216,
      frameHeight: 40,
    },
    exit_sign: {
      source: _0xdaa5[183],
      frames: 2,
      frameWidth: 107,
      frameHeight: 85,
    },
    steam: {
      source: _0xdaa5[184],
      frames: 6,
      frameWidth: 40,
      frameHeight: 100,
    },
    candles: {
      source: _0xdaa5[185],
      frames: 5,
      frameWidth: 63,
      frameHeight: 96,
    },
    portrait_a: {
      source: _0xdaa5[186],
      frames: 2,
      frameWidth: 85,
      frameHeight: 115,
    },
    portrait_b: {
      source: _0xdaa5[187],
      frames: 2,
      frameWidth: 85,
      frameHeight: 115,
    },
    deer: {
      source: _0xdaa5[188],
      frames: 2,
      frameWidth: 119,
      frameHeight: 190,
    },
    raven: {
      source: _0xdaa5[189],
      frames: 4,
      frameWidth: 120,
      frameHeight: 108,
    },
  },
  levels: [
    {
      environment: _0xdaa5[190],
      platforms: [
        { x: -46, y: 295, size: 6 },
        { x: 466, y: 295, size: 6 },
        { x: 208, y: 490, size: 6 },
        { x: -46, y: 681, size: 6 },
        { x: 466, y: 681, size: 6 },
        { x: -62, y: 892, size: 25 },
      ],
      statics: [{ id: _0xdaa5[191], x: 320, y: 1130 }],
      obstacles: [],
      traps: [],
    },
    {
      environment: _0xdaa5[190],
      platforms: [
        { x: 170, y: 112, size: 6 },
        { x: -62, y: 302, size: 5 },
        { x: 380, y: 302, size: 10 },
        { x: 170, y: 492, size: 6 },
        { x: -62, y: 682, size: 25, occupied: true },
        { x: -62, y: 892, size: 25 },
      ],
      statics: [{ id: _0xdaa5[191], x: 320, y: 1132 }],
      obstacles: [],
      traps: [],
    },
    {
      environment: _0xdaa5[190],
      platforms: [
        { x: -46, y: 295, size: 6 },
        { x: 466, y: 295, size: 6 },
        { x: 208, y: 490, size: 6 },
        { x: -46, y: 681, size: 6 },
        { x: 466, y: 681, size: 6 },
        { x: -62, y: 892, size: 25 },
      ],
      statics: [{ id: _0xdaa5[191], x: 320, y: 1130 }],
      obstacles: [{ id: _0xdaa5[192], x: 320, y: 892 }],
      traps: [],
    },
    {
      environment: _0xdaa5[190],
      platforms: [
        { x: 170, y: 112, size: 6 },
        { x: -62, y: 302, size: 5 },
        { x: 380, y: 302, size: 10 },
        { x: 170, y: 492, size: 6 },
        { x: -62, y: 682, size: 25, occupied: true },
        { x: -62, y: 892, size: 25 },
      ],
      statics: [{ id: _0xdaa5[191], x: 320, y: 1132 }],
      obstacles: [{ id: _0xdaa5[192], x: 200, y: 892 }],
      traps: [],
    },
  ],
};
var Game = (function () {
  var _0xf5bax2 = (function () {
    _0xdaa5[193];
    function _0xf5bax2(_0xf5bax3) {
      PIXI[_0xdaa5[195]][_0xdaa5[194]](this, _0xf5bax3);
      this[_0xdaa5[196]] = true;
      this[_0xdaa5[197]] = true;
      this[_0xdaa5[198]] = false;
      this[_0xdaa5[199]] = false;
      this[_0xdaa5[200]] = _0xf5bax3;
      this[_0xdaa5[203]](_0xdaa5[209], this[_0xdaa5[210]])
        [_0xdaa5[203]](_0xdaa5[208], this[_0xdaa5[207]])
        [_0xdaa5[203]](_0xdaa5[206], this[_0xdaa5[207]])
        [_0xdaa5[203]](_0xdaa5[204], this[_0xdaa5[205]])
        [_0xdaa5[203]](_0xdaa5[201], this[_0xdaa5[202]]);
    }
    _0xf5bax2[_0xdaa5[211]] = Object[_0xdaa5[212]](
      PIXI[_0xdaa5[195]][_0xdaa5[211]]
    );
    _0xf5bax2[_0xdaa5[211]][_0xdaa5[207]] = function () {
      this[_0xdaa5[213]] = false;
      if (this[_0xdaa5[198]]) {
        if (this[_0xdaa5[214]]) {
          this[_0xdaa5[215]] = this[_0xdaa5[214]];
        }
      } else {
        this[_0xdaa5[215]] = this[_0xdaa5[200]];
      }
    };
    _0xf5bax2[_0xdaa5[211]][_0xdaa5[210]] = function () {
      this[_0xdaa5[213]] = true;
      if (this[_0xdaa5[216]]) {
        this[_0xdaa5[215]] = this[_0xdaa5[216]];
      }
    };
    _0xf5bax2[_0xdaa5[211]][_0xdaa5[205]] = function () {
      this[_0xdaa5[198]] = true;
      if (this[_0xdaa5[213]]) {
        return;
      }
      if (this[_0xdaa5[214]]) {
        this[_0xdaa5[215]] = this[_0xdaa5[214]];
      }
    };
    _0xf5bax2[_0xdaa5[211]][_0xdaa5[202]] = function () {
      this[_0xdaa5[198]] = false;
      if (this[_0xdaa5[213]]) {
        return;
      }
      this[_0xdaa5[215]] = this[_0xdaa5[200]];
    };
    _0xf5bax2[_0xdaa5[211]][_0xdaa5[217]] = function (_0xf5bax4) {
      if (_0xf5bax4) {
        this[_0xdaa5[215]] = this[_0xdaa5[200]];
        this[_0xdaa5[196]] = true;
      } else {
        this[_0xdaa5[215]] = this[_0xdaa5[218]] || this[_0xdaa5[200]];
        this[_0xdaa5[196]] = false;
      }
    };
    return _0xf5bax2;
  })();
  var _0xf5bax5 = (function () {
    _0xdaa5[193];
    var _0xf5bax6 = {};
    var _0xf5bax7 = {
      add: function (_0xf5bax8, _0xf5bax9) {
        _0xf5bax6[_0xf5bax8] = _0xf5bax9;
      },
      remove: function (_0xf5bax8) {
        if (!_0xf5bax8 || !_0xf5bax6[_0xf5bax8]) {
          return;
        }
        _0xf5bax6[_0xf5bax8] = null;
        delete _0xf5bax6[_0xf5bax8];
      },
      update: function (_0xf5baxa) {
        for (var _0xf5bax8 in _0xf5bax6) {
          if (_0xf5bax6[_0xf5bax8][_0xdaa5[219]]) {
            _0xf5bax6[_0xf5bax8][_0xdaa5[220]](_0xf5baxa);
          }
        }
      },
    };
    return _0xf5bax7;
  })();
  var _0xf5baxb = (function () {
    _0xdaa5[193];
    var _0xf5baxc = 150;
    var _0xf5baxd = 0;
    var _0xf5baxe = 0;
    var _0xf5baxf = 0;
    var _0xf5bax10 = false;
    function _0xf5baxb(_0xf5bax11) {
      PIXI[_0xdaa5[221]][_0xdaa5[194]](this);
      this[_0xdaa5[196]] = true;
      this[_0xdaa5[197]] = true;
      this[_0xdaa5[199]] = false;
      this[_0xdaa5[203]](_0xdaa5[209], this[_0xdaa5[210]])
        [_0xdaa5[203]](_0xdaa5[208], this[_0xdaa5[207]])
        [_0xdaa5[203]](_0xdaa5[206], this[_0xdaa5[207]]);
      this[_0xdaa5[0]](_0xf5bax11);
    }
    _0xf5baxb[_0xdaa5[211]] = Object[_0xdaa5[212]](
      PIXI[_0xdaa5[221]][_0xdaa5[211]]
    );
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[0]] = function (_0xf5bax11) {
      this[_0xdaa5[222]] = 0;
      this[_0xdaa5[223]] = 0;
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax11[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5bax13 = PIXI[_0xdaa5[195]][_0xdaa5[225]](
          _0xf5bax11[_0xf5bax12]
        );
        _0xf5bax13[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
        _0xf5bax13[_0xdaa5[227]][_0xdaa5[228]] = 1;
        _0xf5bax13[_0xdaa5[226]] = _0xf5bax12 * _0xf5baxc + 2 * _0xf5baxc;
        _0xf5bax13[_0xdaa5[228]] = 0;
        _0xf5bax13[_0xdaa5[229]] = _0xf5bax11[_0xf5bax12];
        this[_0xdaa5[230]](_0xf5bax13);
      }
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[210]] = function (_0xf5bax14) {
      if (this[_0xdaa5[199]]) {
        return;
      }
      _0xf5bax10 = false;
      this[_0xdaa5[199]] = true;
      _0xf5baxd = _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[226]];
      _0xf5baxe = _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[228]];
      Tweener[_0xdaa5[233]](this);
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[207]] = function (_0xf5bax14) {
      if (!this[_0xdaa5[199]]) {
        return;
      }
      this[_0xdaa5[199]] = false;
      if (_0xf5bax10) {
        this[_0xdaa5[234]]();
      } else {
        this[_0xdaa5[236]](Math[_0xdaa5[235]]((320 - _0xf5baxd) / _0xf5baxc));
      }
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[237]] = function (_0xf5bax14) {
      if (!this[_0xdaa5[199]]) {
        return;
      }
      var _0xf5bax15 =
        _0xf5baxd - _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[226]];
      this[_0xdaa5[222]] = _0xf5bax15 / _0xf5baxc;
      if (Math[_0xdaa5[238]](this[_0xdaa5[222]]) > 0.2) {
        _0xf5bax10 = true;
      }
      if (this[_0xdaa5[222]] > 0.5) {
        _0xf5baxd -= _0xf5baxc;
        this[_0xdaa5[239]]();
        this[_0xdaa5[242]](
          _0xdaa5[240],
          this[_0xdaa5[241]][this[_0xdaa5[223]]][_0xdaa5[229]],
          this[_0xdaa5[223]]
        );
      } else {
        if (this[_0xdaa5[222]] < -0.5) {
          _0xf5baxd += _0xf5baxc;
          this[_0xdaa5[243]]();
          this[_0xdaa5[242]](
            _0xdaa5[240],
            this[_0xdaa5[241]][this[_0xdaa5[223]]][_0xdaa5[229]],
            this[_0xdaa5[223]]
          );
        }
      }
      this[_0xdaa5[244]]();
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[236]] = function (_0xf5bax4) {
      this[_0xdaa5[245]] = 0;
      var _0xf5bax16 = 0;
      Tweener[_0xdaa5[247]](
        this,
        { swipe: _0xf5bax4 * -1 },
        {
          time: 20,
          onUpdate: function () {
            if (this[_0xdaa5[245]] - _0xf5bax16 > 0.5) {
              _0xf5bax16++;
              this[_0xdaa5[239]]();
            } else {
              if (this[_0xdaa5[245]] - _0xf5bax16 < -0.5) {
                _0xf5bax16--;
                this[_0xdaa5[243]]();
              }
            }
            this[_0xdaa5[222]] = this[_0xdaa5[245]] - _0xf5bax16;
            this[_0xdaa5[244]]();
          }[_0xdaa5[246]](this),
          onComplete: function () {
            this[_0xdaa5[242]](
              _0xdaa5[240],
              this[_0xdaa5[241]][this[_0xdaa5[223]]][_0xdaa5[229]],
              this[_0xdaa5[223]]
            );
          }[_0xdaa5[246]](this),
        }
      );
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[239]] = function () {
      if (!this[_0xdaa5[241]][_0xdaa5[224]]) {
        return;
      }
      if (this[_0xdaa5[223]] == 0) {
        this[_0xdaa5[222]] = -1;
      } else {
        this[_0xdaa5[222]] = 0;
      }
      this[_0xdaa5[223]]++;
      if (this[_0xdaa5[223]] > 1) {
        this[_0xdaa5[223]] = 1;
      }
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[243]] = function () {
      if (!this[_0xdaa5[241]][_0xdaa5[224]]) {
        return;
      }
      if (this[_0xdaa5[223]] == 1) {
        this[_0xdaa5[222]] = 1;
      } else {
        this[_0xdaa5[222]] = 0;
      }
      this[_0xdaa5[223]]--;
      if (this[_0xdaa5[223]] < 0) {
        this[_0xdaa5[223]] = 0;
      }
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[234]] = function () {
      var _0xf5bax17 = 20;
      Tweener[_0xdaa5[247]](
        this,
        { offset: 0 },
        { time: _0xf5bax17, onUpdate: this[_0xdaa5[244]][_0xdaa5[246]](this) }
      );
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[240]] = function (_0xf5bax8) {
      var _0xf5bax18 = Math[_0xdaa5[238]](_0xf5bax8 - this[_0xdaa5[223]]);
      for (var _0xf5bax12 = 0; _0xf5bax12 < _0xf5bax18; _0xf5bax12++) {
        if (_0xf5bax8 > this[_0xdaa5[223]]) {
          this[_0xdaa5[239]]();
        } else {
          if (_0xf5bax8 < this[_0xdaa5[223]]) {
            this[_0xdaa5[243]]();
          }
        }
      }
      this[_0xdaa5[244]]();
    };
    _0xf5baxb[_0xdaa5[211]][_0xdaa5[244]] = function () {
      var _0xf5bax19 = [100, 250, 400];
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < this[_0xdaa5[241]][_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5bax1a =
          _0xf5bax12 + 1 - Math[_0xdaa5[248]](this[_0xdaa5[222]]);
        var _0xf5bax13 = this[_0xdaa5[241]][_0xf5bax12];
        if (this[_0xdaa5[223]] == 0) {
          _0xf5bax13[_0xdaa5[226]] =
            _0xf5bax19[_0xf5bax12 + 1] +
            (_0xf5bax19[_0xf5bax12] - _0xf5bax19[_0xf5bax12 + 1]) *
              Math[_0xdaa5[238]](this[_0xdaa5[222]]);
        } else {
          if (this[_0xdaa5[223]] == 1) {
            _0xf5bax13[_0xdaa5[226]] =
              _0xf5bax19[_0xf5bax12] +
              (_0xf5bax19[_0xf5bax12 + 1] - _0xf5bax19[_0xf5bax12]) *
                Math[_0xdaa5[238]](this[_0xdaa5[222]]);
          }
        }
        if (this[_0xdaa5[222]] > 0) {
          if (_0xf5bax12 == this[_0xdaa5[223]]) {
            _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](
              1.3 - 0.3 * (this[_0xdaa5[222]] / 0.5)
            );
          } else {
            _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](1);
          }
        } else {
          if (this[_0xdaa5[222]] < 0) {
            if (_0xf5bax12 == this[_0xdaa5[223]]) {
              _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](
                1.3 + 0.3 * (this[_0xdaa5[222]] / 0.5)
              );
            } else {
              _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](1);
            }
          } else {
            if (_0xf5bax12 == this[_0xdaa5[223]]) {
              _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](1.3);
            } else {
              _0xf5bax13[_0xdaa5[250]][_0xdaa5[249]](1);
            }
          }
        }
      }
    };
    return _0xf5baxb;
  })();
  var _0xf5bax1b = 640;
  var _0xf5bax1c = 1137 - 60;
  var _0xf5bax1d = 0;
  var _0xf5bax1e = {};
  var _0xf5bax1f = true;
  var _0xf5bax20 = true;
  var _0xf5bax21 = 50;
  var _0xf5bax22,
    _0xf5bax23,
    _0xf5bax24,
    _0xf5bax25,
    _0xf5bax26,
    _0xf5bax27,
    _0xf5bax28,
    _0xf5bax29,
    _0xf5bax2a,
    _0xf5bax2b,
    _0xf5bax2c;
  var _0xf5bax2d, _0xf5bax2e, _0xf5bax2f, _0xf5bax30;
  var _0xf5bax31, _0xf5bax32;
  var _0xf5bax33, _0xf5bax34;
  var _0xf5bax35, _0xf5bax36;
  function Game() {
    this[_0xdaa5[251]] = _0xdaa5[252];
    this[_0xdaa5[253]] = init[_0xdaa5[254]] / 2;
    this[_0xdaa5[255]] = init[_0xdaa5[256]] / 2;
    this[_0xdaa5[257]] = 305;
    this[_0xdaa5[258]]();
  }
  Game[_0xdaa5[211]][_0xdaa5[258]] = function () {
    this[_0xdaa5[251]] = _0xdaa5[259];
    this[_0xdaa5[260]] = {};
    this[_0xdaa5[260]][_0xdaa5[261]] = new Howl({
      src: [_0xdaa5[262], _0xdaa5[263]],
    });
    this[_0xdaa5[260]][_0xdaa5[264]] = new Howl({
      src: [_0xdaa5[265], _0xdaa5[266]],
    });
    this[_0xdaa5[260]][_0xdaa5[267]] = new Howl({
      src: [_0xdaa5[268], _0xdaa5[269]],
    });
    this[_0xdaa5[260]][_0xdaa5[270]] = new Howl({
      src: [_0xdaa5[271], _0xdaa5[272]],
    });
    this[_0xdaa5[260]][_0xdaa5[273]] = new Howl({
      src: [_0xdaa5[274], _0xdaa5[275]],
    });
    this[_0xdaa5[260]][_0xdaa5[276]] = new Howl({
      src: [_0xdaa5[277], _0xdaa5[278]],
    });
    this[_0xdaa5[260]][_0xdaa5[279]] = new Howl({
      src: [_0xdaa5[280], _0xdaa5[281]],
    });
    this[_0xdaa5[260]][_0xdaa5[282]] = new Howl({
      src: [_0xdaa5[283], _0xdaa5[284]],
    });
    this[_0xdaa5[260]][_0xdaa5[285]] = new Howl({
      src: [_0xdaa5[286], _0xdaa5[287]],
    });
    this[_0xdaa5[260]][_0xdaa5[288]] = new Howl({
      src: [_0xdaa5[289], _0xdaa5[290]],
    });
    for (var _0xf5bax37 in init[_0xdaa5[291]]) {
      PIXI[_0xdaa5[293]][_0xdaa5[292]](
        _0xf5bax37,
        init[_0xdaa5[291]][_0xf5bax37]
      );
    }
    PIXI[_0xdaa5[293]][_0xdaa5[295]](this[_0xdaa5[294]][_0xdaa5[246]](this));
  };
  Game[_0xdaa5[211]][_0xdaa5[296]] = function (_0xf5bax38) {
    this[_0xdaa5[251]] = _0xdaa5[297];
    var _0xf5bax39 = window[_0xdaa5[298]];
    this[_0xdaa5[299]] = true;
    var _0xf5bax3a = false;
    if (PIXI[_0xdaa5[301]][_0xdaa5[300]]() && _0xf5bax39 == 1) {
      _0xf5bax3a = true;
    }
    _0xf5bax22 = this[_0xdaa5[302]] = new PIXI[_0xdaa5[221]]();
    this[_0xdaa5[303]] = PIXI[_0xdaa5[304]](_0xf5bax1b, _0xf5bax1c, {
      roundPixels: false,
      resolution: 1,
      antialias: false,
      preserveDrawingBuffer: true,
    });
    document[_0xdaa5[308]](_0xdaa5[307])[_0xdaa5[306]](
      this[_0xdaa5[303]][_0xdaa5[305]]
    );
    for (var _0xf5bax37 in init[_0xdaa5[309]]) {
      var _0xf5bax3b = PIXI.ParseTile(init[_0xdaa5[309]][_0xf5bax37]);
      _0xf5bax1e[_0xf5bax37] = _0xf5bax3b;
    }
    var _0xf5bax3c = PIXI[_0xdaa5[311]][_0xdaa5[310]];
    _0xf5bax3c[_0xdaa5[312]] = false;
    _0xf5bax3c[_0xdaa5[313]]();
    _0xf5bax3c[_0xdaa5[292]](this[_0xdaa5[220]], this);
    _0xf5bax23 = new PIXI[_0xdaa5[315]].TilingSprite(
      _0xf5bax38[_0xdaa5[314]][_0xdaa5[215]],
      _0xf5bax1b,
      _0xf5bax1c
    );
    this[_0xdaa5[302]][_0xdaa5[230]](_0xf5bax23);
    _0xf5bax29 = new _0xf5bax2(_0xf5bax38[_0xdaa5[316]][_0xdaa5[215]]);
    _0xf5bax29[_0xdaa5[226]] = 50;
    _0xf5bax29[_0xdaa5[228]] = 50;
    _0xf5bax29[_0xdaa5[317]] = false;
    _0xf5bax29[_0xdaa5[196]] = true;
    _0xf5bax29[_0xdaa5[197]] = true;
    _0xf5bax29[_0xdaa5[216]] = _0xf5bax38[_0xdaa5[318]][_0xdaa5[215]];
    _0xf5bax29[_0xdaa5[214]] = _0xf5bax38[_0xdaa5[319]][_0xdaa5[215]];
    _0xf5bax29[_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax29[_0xdaa5[203]](
      _0xdaa5[208],
      function () {
        if (this[_0xdaa5[320]]) {
          return;
        }
        if (this[_0xdaa5[321]]) {
          this[_0xdaa5[322]]();
        } else {
          this[_0xdaa5[323]]();
        }
      }[_0xdaa5[246]](this)
    );
    _0xf5bax22[_0xdaa5[230]](_0xf5bax29);
    _0xf5bax24 = new Animable(_0xf5bax1e[_0xdaa5[162]][0]);
    _0xf5bax24[_0xdaa5[250]][_0xdaa5[249]](1.6);
    _0xf5bax24[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax24[_0xdaa5[227]][_0xdaa5[228]] = 1;
    _0xf5bax24[_0xdaa5[226]] = 320;
    _0xf5bax24[_0xdaa5[228]] = 320;
    _0xf5bax24[_0xdaa5[324]] = 3;
    _0xf5bax24[_0xdaa5[325]] = 10;
    _0xf5bax24[_0xdaa5[326]] = true;
    _0xf5bax24[_0xdaa5[327]] = true;
    _0xf5bax24[_0xdaa5[328]] = { x: 0, y: 12, width: 76, height: 102 };
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[270], _0xf5bax1e[_0xdaa5[162]], [9]);
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[330], _0xf5bax1e[_0xdaa5[162]], [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
    ]);
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[331], _0xf5bax1e[_0xdaa5[162]], [9]);
    _0xf5bax24[_0xdaa5[332]](_0xdaa5[330], -1, 15);
    _0xf5bax5[_0xdaa5[292]](_0xdaa5[333], _0xf5bax24);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax24);
    _0xf5bax26 = null;
    _0xf5bax25 = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[261]);
    _0xf5bax25[_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax25);
    _0xf5bax27 = new PIXI.Graphics();
    _0xf5bax27[_0xdaa5[317]] = false;
    _0xf5bax27[_0xdaa5[334]](0x0);
    _0xf5bax27[_0xdaa5[335]](0, 0, _0xf5bax1b, _0xf5bax1c);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax27);
    _0xf5bax33 = new PIXI.Container();
    _0xf5bax33[_0xdaa5[317]] = false;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax33);
    _0xf5bax33[_0xdaa5[336]] = new PIXI[_0xdaa5[315]].TilingSprite(
      _0xf5bax38[_0xdaa5[337]][_0xdaa5[215]],
      _0xf5bax1b,
      _0xf5bax1c
    );
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[336]]);
    _0xf5bax33[_0xdaa5[338]] = new PIXI.Text(_0xdaa5[339], {
      fontFamily: _0xdaa5[340],
      fontSize: 20,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax33[_0xdaa5[338]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[338]][_0xdaa5[226]] = 320;
    _0xf5bax33[_0xdaa5[338]][_0xdaa5[228]] = 130;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[338]]);
    _0xf5bax33[_0xdaa5[314]] = new PIXI.Graphics();
    _0xf5bax33[_0xdaa5[314]][_0xdaa5[228]] = 405;
    _0xf5bax33[_0xdaa5[314]][_0xdaa5[334]](0x005e4c);
    _0xf5bax33[_0xdaa5[314]][_0xdaa5[335]](0, 0, 640, 250);
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[314]]);
    _0xf5bax33[_0xdaa5[342]] = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[261]);
    _0xf5bax33[_0xdaa5[342]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[342]][_0xdaa5[250]][_0xdaa5[249]](1.6);
    _0xf5bax33[_0xdaa5[342]][_0xdaa5[226]] = 320;
    _0xf5bax33[_0xdaa5[342]][_0xdaa5[228]] = 317;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[342]]);
    _0xf5bax33[_0xdaa5[343]] = new PIXI.Text(_0xdaa5[344] + 0, {
      fontFamily: _0xdaa5[340],
      fontSize: 14,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax33[_0xdaa5[343]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[343]][_0xdaa5[226]] = 0;
    _0xf5bax33[_0xdaa5[343]][_0xdaa5[228]] = -50;
    _0xf5bax33[_0xdaa5[342]][_0xdaa5[230]](_0xf5bax33[_0xdaa5[343]]);
    _0xf5bax33[_0xdaa5[345]] = new PIXI.Text(_0xdaa5[346], {
      fontFamily: _0xdaa5[340],
      fontSize: 16,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax33[_0xdaa5[345]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[345]][_0xdaa5[226]] = 320;
    _0xf5bax33[_0xdaa5[345]][_0xdaa5[228]] = 621;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[345]]);
    this[_0xdaa5[347]] = _0xf5bax33[_0xdaa5[347]] = new _0xf5baxb([
      _0xdaa5[348],
      _0xdaa5[349],
    ]);
    _0xf5bax33[_0xdaa5[347]][_0xdaa5[226]] = 70;
    _0xf5bax33[_0xdaa5[347]][_0xdaa5[228]] = 580;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[347]]);
    _0xf5bax33[_0xdaa5[347]][_0xdaa5[203]](_0xdaa5[240], function (
      _0xf5bax14,
      _0xf5bax3d
    ) {
      Tweener[_0xdaa5[247]](
        _0xf5bax33[_0xdaa5[345]],
        { alpha: 0 },
        { time: 10, transition: _0xdaa5[350] }
      );
      Tweener[_0xdaa5[247]](
        _0xf5bax33[_0xdaa5[342]],
        { scaleX: 0.1, scaleY: 0.1, alpha: 0 },
        {
          time: 10,
          onComplete: function () {
            _0xf5bax33[_0xdaa5[343]][_0xdaa5[351]] =
              _0xdaa5[344] + _0xf5bax3e[_0xdaa5[353]][_0xdaa5[352]][_0xf5bax3d];
            switch (_0xf5bax14) {
              case _0xdaa5[348]:
                _0xf5bax33[_0xdaa5[345]][_0xdaa5[351]] = _0xdaa5[346];
                break;
              case _0xdaa5[349]:
                _0xf5bax33[_0xdaa5[345]][_0xdaa5[351]] = _0xdaa5[354];
                break;
            }
            Tweener[_0xdaa5[247]](
              _0xf5bax33[_0xdaa5[345]],
              { alpha: 1 },
              { time: 20, transition: _0xdaa5[350] }
            );
            Tweener[_0xdaa5[247]](
              _0xf5bax33[_0xdaa5[342]],
              { scaleX: 1.6, scaleY: 1.6, alpha: 1 },
              { time: 10, transition: _0xdaa5[350] }
            );
          },
        }
      );
    });
    _0xf5bax33[_0xdaa5[355]] = new _0xf5bax2(
      _0xf5bax38[_0xdaa5[356]][_0xdaa5[215]]
    );
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[226]] = 50;
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[228]] = 50;
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[216]] =
      _0xf5bax38[_0xdaa5[357]][_0xdaa5[215]];
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[196]] = true;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[355]]);
    _0xf5bax33[_0xdaa5[355]][_0xdaa5[203]](
      _0xdaa5[208],
      function () {
        if (this[_0xdaa5[320]]) {
          return;
        }
        this[_0xdaa5[322]]();
      }[_0xdaa5[246]](this)
    );
    _0xf5bax33[_0xdaa5[358]] = new _0xf5bax2(
      _0xf5bax38[_0xdaa5[359]][_0xdaa5[215]]
    );
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[226]] = 320;
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[228]] = 775;
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[216]] =
      _0xf5bax38[_0xdaa5[360]][_0xdaa5[215]];
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[214]] =
      _0xf5bax38[_0xdaa5[361]][_0xdaa5[215]];
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[196]] = true;
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[197]] = true;
    _0xf5bax33[_0xdaa5[230]](_0xf5bax33[_0xdaa5[358]]);
    _0xf5bax33[_0xdaa5[358]][_0xdaa5[203]](
      _0xdaa5[208],
      function () {
        if (this[_0xdaa5[320]]) {
          return;
        }
        this[_0xdaa5[362]]();
      }[_0xdaa5[246]](this)
    );
    _0xf5bax34 = new PIXI.Container();
    _0xf5bax34[_0xdaa5[317]] = false;
    _0xf5bax34[_0xdaa5[228]] = 338;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax34);
    _0xf5bax34[_0xdaa5[314]] = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[363]);
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[314]]);
    _0xf5bax34[_0xdaa5[364]] = new _0xf5bax2(
      _0xf5bax38[_0xdaa5[365]][_0xdaa5[215]]
    );
    _0xf5bax34[_0xdaa5[364]][_0xdaa5[226]] = 75;
    _0xf5bax34[_0xdaa5[364]][_0xdaa5[228]] = 320;
    _0xf5bax34[_0xdaa5[364]][_0xdaa5[216]] =
      _0xf5bax38[_0xdaa5[366]][_0xdaa5[215]];
    _0xf5bax34[_0xdaa5[364]][_0xdaa5[196]] = true;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[364]]);
    _0xf5bax34[_0xdaa5[364]][_0xdaa5[203]](
      _0xdaa5[208],
      function () {
        if (this[_0xdaa5[320]]) {
          return;
        }
        this[_0xdaa5[367]]();
      }[_0xdaa5[246]](this)
    );
    _0xf5bax34[_0xdaa5[355]] = new _0xf5bax2(
      _0xf5bax38[_0xdaa5[368]][_0xdaa5[215]]
    );
    _0xf5bax34[_0xdaa5[355]][_0xdaa5[226]] = 445;
    _0xf5bax34[_0xdaa5[355]][_0xdaa5[228]] = 320;
    _0xf5bax34[_0xdaa5[355]][_0xdaa5[216]] =
      _0xf5bax38[_0xdaa5[369]][_0xdaa5[215]];
    _0xf5bax34[_0xdaa5[355]][_0xdaa5[196]] = true;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[355]]);
    _0xf5bax34[_0xdaa5[355]][_0xdaa5[203]](
      _0xdaa5[208],
      function () {
        if (this[_0xdaa5[320]]) {
          return;
        }
        this[_0xdaa5[370]]();
        this[_0xdaa5[303]][_0xdaa5[371]](_0xf5bax22);
        this[_0xdaa5[372]]();
      }[_0xdaa5[246]](this)
    );
    _0xf5bax34[_0xdaa5[373]] = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[261]);
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[250]][_0xdaa5[249]](0.8);
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[227]][_0xdaa5[228]] = 0.5;
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[226]] = 318;
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[228]] = 383;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[373]]);
    _0xf5bax34[_0xdaa5[374]] = new PIXI.Text(_0xdaa5[375] + 40, {
      fontFamily: _0xdaa5[340],
      fontSize: 28,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax34[_0xdaa5[374]][_0xdaa5[227]][_0xdaa5[226]] = 1;
    _0xf5bax34[_0xdaa5[374]][_0xdaa5[227]][_0xdaa5[228]] = 0;
    _0xf5bax34[_0xdaa5[374]][_0xdaa5[226]] = 278;
    _0xf5bax34[_0xdaa5[374]][_0xdaa5[228]] = 353;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[374]]);
    _0xf5bax34[_0xdaa5[376]] = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[261]);
    _0xf5bax34[_0xdaa5[376]][_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax34[_0xdaa5[376]][_0xdaa5[227]][_0xdaa5[228]] = 0.5;
    _0xf5bax34[_0xdaa5[376]][_0xdaa5[226]] = 320;
    _0xf5bax34[_0xdaa5[376]][_0xdaa5[228]] = -180;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[376]]);
    _0xf5bax34[_0xdaa5[377]] = new PIXI.Text(_0xdaa5[378], {
      fontFamily: _0xdaa5[340],
      fontSize: 32,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax34[_0xdaa5[377]][_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax34[_0xdaa5[377]][_0xdaa5[227]][_0xdaa5[228]] = 0;
    _0xf5bax34[_0xdaa5[377]][_0xdaa5[226]] = 320;
    _0xf5bax34[_0xdaa5[377]][_0xdaa5[228]] = -165;
    _0xf5bax34[_0xdaa5[230]](_0xf5bax34[_0xdaa5[377]]);
    _0xf5bax35 = new PIXI.Graphics();
    _0xf5bax36 = new PIXI.Graphics();
    _0xf5bax2a = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[379]);
    _0xf5bax2a[_0xdaa5[317]] = false;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax2a);
    var _0xf5bax3e = this;
    this[_0xdaa5[380]] = new Stats();
    this[_0xdaa5[381]] = {};
    this[_0xdaa5[382]]();
    gameeInit();
    this[_0xdaa5[383]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[383]] = function () {
    var _0xf5bax3e = this;
    this[_0xdaa5[302]][_0xdaa5[196]] = true;
    this[_0xdaa5[302]][_0xdaa5[384]] = this[_0xdaa5[385]][_0xdaa5[246]](this);
    this[_0xdaa5[302]][_0xdaa5[386]] = this[_0xdaa5[385]][_0xdaa5[246]](this);
    this[_0xdaa5[387]] = false;
    this[_0xdaa5[388]] = { x: 0, y: 0 };
    this[_0xdaa5[389]] = false;
    this[_0xdaa5[390]] = 0;
    var _0xf5bax3f = 0;
    var _0xf5bax40 = false;
    this[_0xdaa5[302]][_0xdaa5[197]] = true;
    this[_0xdaa5[302]][_0xdaa5[203]](_0xdaa5[209], function (_0xf5bax14) {
      if (_0xf5bax3e[_0xdaa5[389]] || _0xf5bax3e[_0xdaa5[321]]) {
        return 0;
      }
      _0xf5bax40 = false;
      _0xf5bax3e[_0xdaa5[387]] = true;
      _0xf5bax3e[_0xdaa5[388]] = {
        x: _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[226]],
        y: _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[228]],
      };
      return false;
    });
    this[_0xdaa5[302]][_0xdaa5[203]](_0xdaa5[391], function (_0xf5bax14) {
      if (
        !_0xf5bax3e[_0xdaa5[392]] ||
        !_0xf5bax3e[_0xdaa5[387]] ||
        _0xf5bax3e[_0xdaa5[320]] ||
        _0xf5bax3e[_0xdaa5[321]] ||
        _0xf5bax2b
      ) {
        return;
      }
      var _0xf5bax41 = null;
      var _0xf5bax42 =
        _0xf5bax3e[_0xdaa5[388]][_0xdaa5[226]] -
        _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[226]];
      var _0xf5bax43 =
        _0xf5bax3e[_0xdaa5[388]][_0xdaa5[228]] -
        _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[228]];
      if (_0xf5bax42 < -20 && _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] < 0) {
        _0xf5bax3e[_0xdaa5[393]](1);
        _0xf5bax3e[_0xdaa5[394]](1);
      } else {
        if (_0xf5bax42 > 20 && _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] > 0) {
          _0xf5bax3e[_0xdaa5[393]](-1);
          _0xf5bax3e[_0xdaa5[394]](-1);
        }
      }
      if (_0xf5bax43 > 20 && _0xf5bax24[_0xdaa5[326]]) {
        _0xf5bax3e[_0xdaa5[393]](0);
        _0xf5bax3e[_0xdaa5[394]](0);
        _0xf5bax40 = true;
      } else {
        if (
          _0xf5bax43 < -20 &&
          _0xf5bax24[_0xdaa5[327]] &&
          _0xf5bax24[_0xdaa5[228]] < 800
        ) {
          _0xf5bax3e[_0xdaa5[393]](2);
          _0xf5bax3e[_0xdaa5[394]](2);
          _0xf5bax40 = true;
        }
      }
      _0xf5bax3e[_0xdaa5[388]] = {
        x: _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[226]],
        y: _0xf5bax14[_0xdaa5[232]][_0xdaa5[231]][_0xdaa5[228]],
      };
    });
    this[_0xdaa5[302]][_0xdaa5[203]](_0xdaa5[208], function (_0xf5bax14) {
      if (!_0xf5bax3e[_0xdaa5[387]] || _0xf5bax3e[_0xdaa5[321]]) {
        return;
      }
      _0xf5bax3e[_0xdaa5[395]] = false;
      _0xf5bax3e[_0xdaa5[387]] = false;
      return false;
    });
    document[_0xdaa5[398]](_0xdaa5[396], function (_0xf5bax14) {
      _0xf5bax3e[_0xdaa5[397]](_0xf5bax14);
    });
    document[_0xdaa5[398]](_0xdaa5[399], function (_0xf5bax14) {
      _0xf5bax3e[_0xdaa5[400]](_0xf5bax14);
    });
    this[_0xdaa5[401]] = false;
  };
  Game[_0xdaa5[211]][_0xdaa5[382]] = function () {
    var _0xf5bax44 = this[_0xdaa5[303]][_0xdaa5[305]];
    var _0xf5bax45 = window[_0xdaa5[402]] / _0xf5bax1b;
    var _0xf5bax46 = window[_0xdaa5[403]] / _0xf5bax1c;
    var _0xf5bax47 = 0;
    var _0xf5bax48 = 0;
    if (_0xf5bax45 < _0xf5bax46) {
      _0xf5bax47 = _0xf5bax1b * _0xf5bax45;
      _0xf5bax48 = _0xf5bax1c * _0xf5bax45;
      _0xf5bax44[_0xdaa5[405]][_0xdaa5[404]] = 0;
    } else {
      _0xf5bax47 = _0xf5bax1b * _0xf5bax46;
      _0xf5bax48 = _0xf5bax1c * _0xf5bax46;
      _0xf5bax44[_0xdaa5[405]][_0xdaa5[404]] =
        (window[_0xdaa5[402]] - _0xf5bax47) / 2 + _0xdaa5[406];
    }
    _0xf5bax44[_0xdaa5[405]][_0xdaa5[407]] = _0xf5bax47 + _0xdaa5[406];
    _0xf5bax44[_0xdaa5[405]][_0xdaa5[408]] = _0xf5bax48 + _0xdaa5[406];
  };
  Game[_0xdaa5[211]][_0xdaa5[0]] = function (_0xf5bax11) {
    _0xf5bax30 = 40;
    this[_0xdaa5[409]] = false;
    this[_0xdaa5[321]] = true;
    this[_0xdaa5[353]] = {
      played: true,
      collection: [0, 0, 0, 0, 0],
      upgrades: [0, 0, 0, 0, 0],
    };
    this[_0xdaa5[410]] = [];
    if (_0xf5bax11 && _0xf5bax11[_0xdaa5[353]] !== null) {
      try {
        var _0xf5bax49 = JSON[_0xdaa5[411]](_0xf5bax11[_0xdaa5[353]]);
        if (_0xf5bax49 !== null) {
          if (_0xf5bax49[_0xdaa5[412]]) {
            this[_0xdaa5[353]][_0xdaa5[412]] = _0xf5bax49[_0xdaa5[412]];
          }
          if (_0xf5bax49[_0xdaa5[352]]) {
            this[_0xdaa5[353]][_0xdaa5[352]] = _0xf5bax49[_0xdaa5[352]];
          }
          if (_0xf5bax49[_0xdaa5[413]]) {
            this[_0xdaa5[353]][_0xdaa5[413]] = _0xf5bax49[_0xdaa5[413]];
          }
        }
      } catch (err) {}
    }
    this[_0xdaa5[251]] = _0xdaa5[414];
    this[_0xdaa5[415]] = null;
    this[_0xdaa5[416]] = false;
    this[_0xdaa5[320]] = false;
    this[_0xdaa5[417]] = false;
    this[_0xdaa5[392]] = true;
    this[_0xdaa5[418]] = 0;
    this[_0xdaa5[419]] = 0;
    _0xf5bax8d(this._nums);
    this[_0xdaa5[420]] = [];
    this[_0xdaa5[421]] = [];
    _0xf5bax2d = this[_0xdaa5[422]] = 0;
    this[_0xdaa5[423]] = 1;
    this[_0xdaa5[424]] = [];
    this[_0xdaa5[425]] = [];
    this[_0xdaa5[426]] = [];
    this[_0xdaa5[427]] = 0;
    this[_0xdaa5[428]] = 0;
    this[_0xdaa5[429]] = 0;
    this[_0xdaa5[430]](this._level);
    this[_0xdaa5[303]][_0xdaa5[371]](this._stage);
    gamee[_0xdaa5[433]][_0xdaa5[398]](
      _0xdaa5[431],
      this[_0xdaa5[432]][_0xdaa5[246]](this)
    );
    gamee[_0xdaa5[434]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[432]] = function (_0xf5bax14) {
    _0xf5bax30 = 40;
    _0xf5bax64 = 1.2;
    _0xf5bax2d = this[_0xdaa5[422]] = 0;
    this[_0xdaa5[430]](this._level);
    this[_0xdaa5[435]]();
    this[_0xdaa5[429]] = 0;
    this[_0xdaa5[436]]();
    this[_0xdaa5[251]] = _0xdaa5[437];
    console[_0xdaa5[439]](_0xdaa5[438]);
    this[_0xdaa5[320]] = false;
    this[_0xdaa5[417]] = true;
    this[_0xdaa5[440]]();
    if (this[_0xdaa5[321]]) {
      this[_0xdaa5[323]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[372]] = function () {
    this[_0xdaa5[417]] = false;
    this[_0xdaa5[441]]();
    this[_0xdaa5[442]](false);
    gamee[_0xdaa5[443]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[436]] = function () {
    gamee[_0xdaa5[436]](this._score);
  };
  Game[_0xdaa5[211]][_0xdaa5[442]] = function (_0xf5bax4a) {
    gamee[_0xdaa5[445]](JSON[_0xdaa5[444]](this[_0xdaa5[353]]), false);
  };
  Game[_0xdaa5[211]][_0xdaa5[435]] = function () {
    if (_0xf5bax51) {
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax51[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        _0xf5bax22[_0xdaa5[446]](_0xf5bax51[_0xf5bax12]);
        _0xf5bax51[_0xf5bax12][_0xdaa5[447]]();
      }
    }
    _0xf5bax51 = [];
    _0xf5bax24[_0xdaa5[331]] = false;
    this[_0xdaa5[387]] = false;
    this[_0xdaa5[392]] = true;
    this[_0xdaa5[418]] = 0;
    if (_0xf5bax26) {
      _0xf5bax5[_0xdaa5[449]](_0xdaa5[448]);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax26);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax28);
      _0xf5bax26 = null;
    }
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[426]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax4b = this[_0xdaa5[426]][_0xf5bax12];
      _0xf5bax5[_0xdaa5[449]](_0xdaa5[450] + _0xf5bax12);
      Tweener[_0xdaa5[233]](_0xf5bax4b);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax4b);
      delete _0xf5bax4b;
    }
    this[_0xdaa5[426]] = [];
    Tweener[_0xdaa5[233]](_0xf5bax24);
    _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] = 1.6;
    _0xf5bax24[_0xdaa5[250]][_0xdaa5[228]] = 1.6;
    _0xf5bax24[_0xdaa5[451]] = 1;
    _0xf5bax24[_0xdaa5[317]] = true;
    _0xf5bax24[_0xdaa5[226]] = 320;
    _0xf5bax24[_0xdaa5[228]] = 320;
    _0xf5bax24[_0xdaa5[324]] = _0xf5bax65;
    _0xf5bax24[_0xdaa5[325]] = 10;
    _0xf5bax24[_0xdaa5[326]] = true;
    _0xf5bax24[_0xdaa5[327]] = true;
    _0xf5bax24[_0xdaa5[332]](_0xdaa5[330], -1, 24);
    _0xf5bax24[_0xdaa5[452]] = 0;
    _0xf5bax67 = 0;
    _0xf5bax25[_0xdaa5[453]] = -1;
    this[_0xdaa5[454]](0);
    this[_0xdaa5[428]] = 0;
    _0xf5bax2e[_0xdaa5[351]] = _0xdaa5[455];
  };
  Game[_0xdaa5[211]][_0xdaa5[456]] = function (_0xf5bax4c) {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
      _0xf5bax12++
    ) {
      this[_0xdaa5[459]](
        _0xf5bax4c[_0xf5bax12][_0xdaa5[457]],
        _0xf5bax4c[_0xf5bax12][_0xdaa5[458]]
      );
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[460]] = function () {
    if (this[_0xdaa5[353]][_0xdaa5[352]][this[_0xdaa5[427]]] >= _0xf5bax30) {
      this[_0xdaa5[461]]();
    } else {
      this[_0xdaa5[372]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[461]] = function () {
    this[_0xdaa5[321]] = true;
    _0xf5bax27[_0xdaa5[451]] = 0.8;
    _0xf5bax27[_0xdaa5[317]] = true;
    _0xf5bax34[_0xdaa5[317]] = true;
    _0xf5bax34[_0xdaa5[377]][_0xdaa5[351]] =
      _0xdaa5[344] + this[_0xdaa5[353]][_0xdaa5[352]][this[_0xdaa5[427]]];
    _0xf5bax34[_0xdaa5[374]][_0xdaa5[351]] = _0xdaa5[375] + _0xf5bax30;
    _0xf5bax34[_0xdaa5[373]][_0xdaa5[215]] = _0xf5bax34[_0xdaa5[376]][
      _0xdaa5[215]
    ] = _0xf5bax25[_0xdaa5[215]];
    _0xf5bax22[_0xdaa5[446]](_0xf5bax27);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax34);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax27);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax34);
    _0xf5bax29[_0xdaa5[317]] = false;
  };
  Game[_0xdaa5[211]][_0xdaa5[370]] = function () {
    this[_0xdaa5[321]] = false;
    _0xf5bax27[_0xdaa5[451]] = 1;
    _0xf5bax27[_0xdaa5[317]] = false;
    _0xf5bax34[_0xdaa5[317]] = false;
    _0xf5bax29[_0xdaa5[317]] = true;
  };
  Game[_0xdaa5[211]][_0xdaa5[367]] = function () {
    this[_0xdaa5[353]][_0xdaa5[352]][this[_0xdaa5[427]]] -= _0xf5bax30;
    _0xf5bax30 *= 2;
    this[_0xdaa5[429]] -= this[_0xdaa5[428]];
    this[_0xdaa5[436]]();
    this[_0xdaa5[442]](false);
    this[_0xdaa5[435]]();
    this[_0xdaa5[370]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[322]] = function () {
    this[_0xdaa5[321]] = false;
    var _0xf5bax4d = _0xdaa5[162];
    switch (this[_0xdaa5[427]]) {
      case 0:
        _0xf5bax4d = _0xdaa5[162];
        _0xf5bax25[_0xdaa5[215]] = _0xf5bax2f[_0xdaa5[215]] =
          PIXI[_0xdaa5[293]][_0xdaa5[462]][_0xdaa5[261]][_0xdaa5[215]];
        break;
      case 1:
        _0xf5bax4d = _0xdaa5[163];
        _0xf5bax25[_0xdaa5[215]] = _0xf5bax2f[_0xdaa5[215]] =
          PIXI[_0xdaa5[293]][_0xdaa5[462]][_0xdaa5[261]][_0xdaa5[215]];
        break;
    }
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[270], _0xf5bax1e[_0xf5bax4d], [9]);
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[330], _0xf5bax1e[_0xf5bax4d], [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
    ]);
    _0xf5bax24[_0xdaa5[329]](_0xdaa5[331], _0xf5bax1e[_0xf5bax4d], [9]);
    console[_0xdaa5[439]](_0xdaa5[463]);
    _0xf5bax24[_0xdaa5[328]] = {
      x: 0,
      y: 20,
      width: 76,
      height: _0xf5bax24[_0xdaa5[408]] - 20,
    };
    _0xf5bax27[_0xdaa5[451]] = 1;
    _0xf5bax27[_0xdaa5[317]] = false;
    _0xf5bax33[_0xdaa5[317]] = false;
    _0xf5bax29[_0xdaa5[317]] = true;
  };
  Game[_0xdaa5[211]][_0xdaa5[323]] = function () {
    this[_0xdaa5[464]]();
    this[_0xdaa5[321]] = true;
    _0xf5bax27[_0xdaa5[451]] = 0.7;
    _0xf5bax27[_0xdaa5[317]] = true;
    _0xf5bax33[_0xdaa5[317]] = true;
    _0xf5bax33[_0xdaa5[343]][_0xdaa5[351]] =
      _0xdaa5[344] + this[_0xdaa5[353]][_0xdaa5[352]][this[_0xdaa5[427]]];
    _0xf5bax33[_0xdaa5[347]][_0xdaa5[240]](this._selectedCharacter);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax27);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax33);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax27);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax33);
    _0xf5bax29[_0xdaa5[317]] = false;
  };
  Game[_0xdaa5[211]][_0xdaa5[362]] = function () {
    this[_0xdaa5[321]] = false;
    _0xf5bax27[_0xdaa5[451]] = 1;
    _0xf5bax27[_0xdaa5[317]] = false;
    _0xf5bax33[_0xdaa5[317]] = false;
    this[_0xdaa5[427]] = _0xf5bax33[_0xdaa5[347]][_0xdaa5[223]];
    this[_0xdaa5[322]]();
    if (!this[_0xdaa5[353]][_0xdaa5[412]]) {
      this[_0xdaa5[454]](1);
      this[_0xdaa5[465]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[466]] = function () {
    _0xf5bax64 = 1.2;
    _0xf5bax2d = this[_0xdaa5[422]] = 0;
    this[_0xdaa5[430]](this._level);
    this[_0xdaa5[435]]();
    this[_0xdaa5[429]] = 0;
    this[_0xdaa5[436]]();
    this[_0xdaa5[251]] = _0xdaa5[437];
    console[_0xdaa5[439]](_0xdaa5[438]);
    this[_0xdaa5[417]] = true;
  };
  Game[_0xdaa5[211]][_0xdaa5[464]] = function () {
    _0xf5bax2b = false;
    _0xf5bax2a[_0xdaa5[317]] = false;
    Tweener[_0xdaa5[233]](_0xf5bax2a);
  };
  Game[_0xdaa5[211]][_0xdaa5[465]] = function () {
    _0xf5bax2b = true;
    _0xf5bax2a[_0xdaa5[317]] = true;
    _0xf5bax2a[_0xdaa5[226]] = 400;
    _0xf5bax2a[_0xdaa5[228]] = 320;
    _0xf5bax2a[_0xdaa5[451]] = 0;
    _0xf5bax22[_0xdaa5[446]](_0xf5bax2a);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax2a);
    _0xf5bax24[_0xdaa5[226]] = -20;
    _0xf5bax24[_0xdaa5[228]] = 892;
    var _0xf5bax41 = false;
    var _0xf5bax3e = this;
    Tweener[_0xdaa5[247]](
      _0xf5bax2a,
      {
        x: [400, 320, 140, 140],
        y: [700, 700, 700, 700],
        scaleX: [1.2, 1, 1, 1.3],
        scaleY: [1.2, 1, 1, 1.3],
        alpha: [0, 1, 1, 0],
      },
      {
        time: 50,
        delay: 30,
        onComplete: function () {
          _0xf5bax41 = false;
          Tweener[_0xdaa5[247]](
            _0xf5bax2a,
            {
              x: [400, 400, 320, 500, 500],
              y: [700, 700, 700, 700, 700],
              scaleX: [1.2, 1.2, 1, 1, 1.3],
              scaleY: [1.2, 1.2, 1, 1, 1.3],
              alpha: [0, 0, 1, 1, 0],
            },
            {
              time: 50,
              delay: 30,
              onComplete: function () {
                _0xf5bax41 = false;
                Tweener[_0xdaa5[247]](
                  _0xf5bax2a,
                  {
                    x: [400, 400, 320, 320, 320],
                    y: [700, 700, 700, 520, 520],
                    scaleX: [1.2, 1.2, 1, 1, 1.3],
                    scaleY: [1.2, 1.2, 1, 1, 1.3],
                    alpha: [0, 0, 1, 1, 0],
                  },
                  {
                    time: 50,
                    delay: 0,
                    onComplete: function () {
                      _0xf5bax41 = false;
                      Tweener[_0xdaa5[247]](
                        _0xf5bax2a,
                        {
                          x: [400, 400, 320, 320, 320],
                          y: [700, 700, 700, 880, 880],
                          scaleX: [1.2, 1.2, 1, 1, 1.3],
                          scaleY: [1.2, 1.2, 1, 1, 1.3],
                          alpha: [0, 0, 1, 1, 0],
                        },
                        {
                          time: 50,
                          delay: 0,
                          onComplete: function () {
                            Tweener[_0xdaa5[247]](
                              _0xf5bax2a,
                              { alpha: 0 },
                              {
                                time: 30,
                                onComplete: function () {
                                  _0xf5bax3e[_0xdaa5[353]][_0xdaa5[412]];
                                  _0xf5bax3e[_0xdaa5[464]]();
                                },
                              }
                            );
                          },
                          onUpdate: function (_0xf5bax4e, _0xf5bax4f) {
                            if (!_0xf5bax41 && _0xf5bax4f > 0.5) {
                              _0xf5bax41 = true;
                              _0xf5bax24[_0xdaa5[326]] = false;
                              _0xf5bax24[_0xdaa5[327]] = false;
                              _0xf5bax24[_0xdaa5[325]] = 20 * 1;
                              _0xf5bax24[_0xdaa5[332]](_0xdaa5[270], 0, 7);
                              _0xf5bax24[_0xdaa5[467]](_0xdaa5[330], -1, 24);
                            }
                          },
                        }
                      );
                    },
                    onUpdate: function (_0xf5bax4e, _0xf5bax4f) {
                      if (!_0xf5bax41 && _0xf5bax4f > 0.5) {
                        _0xf5bax41 = true;
                        _0xf5bax24[_0xdaa5[326]] = false;
                        _0xf5bax24[_0xdaa5[327]] = false;
                        _0xf5bax24[_0xdaa5[325]] = -22 * 1;
                        _0xf5bax24[_0xdaa5[332]](_0xdaa5[270], 0, 7);
                        _0xf5bax24[_0xdaa5[467]](_0xdaa5[330], -1, 24);
                      }
                    },
                  }
                );
              },
              onUpdate: function (_0xf5bax4e, _0xf5bax4f) {
                if (!_0xf5bax41 && _0xf5bax4f > 0.5) {
                  _0xf5bax41 = true;
                  _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] = 1.6;
                }
              },
            }
          );
        },
        onUpdate: function (_0xf5bax4e, _0xf5bax4f) {
          if (!_0xf5bax41 && _0xf5bax4f > 0.5) {
            _0xf5bax41 = true;
            _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] = -1.6;
          }
        },
      }
    );
  };
  var _0xf5bax50 = [];
  var _0xf5bax51 = [];
  var _0xf5bax52 = 0;
  var _0xf5bax53 = 0;
  var _0xf5bax54 = 0;
  Game[_0xdaa5[211]][_0xdaa5[430]] = function (_0xf5bax8) {
    if (_0xf5bax26) {
      _0xf5bax5[_0xdaa5[449]](_0xdaa5[448]);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax26);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax28);
      _0xf5bax26 = null;
    }
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[424]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax55 = this[_0xdaa5[424]][_0xf5bax12];
      _0xf5bax22[_0xdaa5[446]](_0xf5bax55);
      delete _0xf5bax55;
    }
    this[_0xdaa5[424]] = [];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[425]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax56 = this[_0xdaa5[425]][_0xf5bax12];
      _0xf5bax5[_0xdaa5[449]](_0xf5bax56[_0xdaa5[229]]);
      Tweener[_0xdaa5[233]](_0xf5bax56);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax56);
      delete _0xf5bax56;
    }
    this[_0xdaa5[425]] = [];
    if (_0xf5bax50) {
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax50[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        if (_0xf5bax50[_0xf5bax12][_0xdaa5[229]]) {
          _0xf5bax5[_0xdaa5[449]](_0xf5bax50[_0xf5bax12][_0xdaa5[229]]);
        }
        Tweener[_0xdaa5[233]](_0xf5bax50[_0xf5bax12]);
        _0xf5bax22[_0xdaa5[446]](_0xf5bax50[_0xf5bax12]);
      }
    }
    _0xf5bax50 = [];
    var _0xf5bax57 = init[_0xdaa5[468]][_0xf5bax8];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax58 = _0xf5bax57[_0xdaa5[469]][_0xf5bax12];
      var _0xf5bax59 = PIXI[_0xdaa5[195]][_0xdaa5[225]](
        _0xf5bax57[_0xdaa5[470]] + _0xdaa5[471]
      );
      _0xf5bax59[_0xdaa5[226]] = _0xf5bax58[_0xdaa5[226]];
      _0xf5bax59[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[472]](_0xf5bax59, 1);
      var _0xf5bax5a = PIXI[_0xdaa5[195]][_0xdaa5[225]](
        _0xf5bax57[_0xdaa5[470]] + _0xdaa5[473]
      );
      _0xf5bax5a[_0xdaa5[226]] =
        _0xf5bax59[_0xdaa5[226]] +
        (_0xf5bax58[_0xdaa5[474]] - 2) * 34 +
        _0xf5bax59[_0xdaa5[407]];
      _0xf5bax5a[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[472]](_0xf5bax5a, 1);
      var _0xf5bax5b = new PIXI[_0xdaa5[315]].TilingSprite(
        PIXI[_0xdaa5[293]][_0xdaa5[462]][
          _0xf5bax57[_0xdaa5[470]] + _0xdaa5[475]
        ][_0xdaa5[215]],
        (_0xf5bax58[_0xdaa5[474]] - 2) * 34,
        35
      );
      _0xf5bax5b[_0xdaa5[226]] =
        _0xf5bax59[_0xdaa5[226]] + _0xf5bax59[_0xdaa5[407]];
      _0xf5bax5b[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[472]](_0xf5bax5b, 1);
      _0xf5bax50[_0xdaa5[476]](_0xf5bax59);
      _0xf5bax50[_0xdaa5[476]](_0xf5bax5b);
      _0xf5bax50[_0xdaa5[476]](_0xf5bax5a);
      if (
        _0xf5bax57[_0xdaa5[470]] == _0xdaa5[477] &&
        _0xf5bax12 == _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]] - 1
      ) {
        _0xf5bax5b[_0xdaa5[215]] =
          PIXI[_0xdaa5[293]][_0xdaa5[462]][
            _0xf5bax57[_0xdaa5[470]] + _0xdaa5[478]
          ][_0xdaa5[215]];
      } else {
        if (
          _0xf5bax57[_0xdaa5[470]] == _0xdaa5[479] &&
          _0xf5bax12 == _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]] - 1
        ) {
          _0xf5bax5b[_0xdaa5[215]] = PIXI[_0xdaa5[481]][_0xdaa5[480]];
        }
      }
      if (_0xf5bax12 == 2) {
        _0xf5bax25[_0xdaa5[226]] =
          _0xf5bax59[_0xdaa5[226]] + Math[_0xdaa5[482]]() * 150;
        _0xf5bax25[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]] - 35;
        Tweener[_0xdaa5[247]](
          _0xf5bax25,
          { y: _0xf5bax25[_0xdaa5[228]] - 10 },
          { time: 60, loop: -1, transition: _0xdaa5[483] }
        );
      }
    }
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[484]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax5c = _0xf5bax57[_0xdaa5[484]][_0xf5bax12];
      var _0xf5bax5d;
      if (_0xf5bax5c[_0xdaa5[229]] == _0xdaa5[485]) {
        _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[486]][0]);
        _0xf5bax5d[_0xdaa5[488]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[486]], [
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],
          [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]);
        _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[489] + _0xf5bax12;
        _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
        _0xf5bax5[_0xdaa5[292]](_0xf5bax5d[_0xdaa5[229]], _0xf5bax5d);
      } else {
        if (_0xf5bax5c[_0xdaa5[229]] == _0xdaa5[185]) {
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[185]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[249]](0.5);
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[185]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
          _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[489] + _0xf5bax12;
          _0xf5bax5[_0xdaa5[292]](_0xf5bax5d[_0xdaa5[229]], _0xf5bax5d);
        } else {
          if (_0xf5bax5c[_0xdaa5[229]] == _0xdaa5[186]) {
            _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[186]][0]);
            _0xf5bax5d[_0xdaa5[227]][_0xdaa5[249]](0.5);
            _0xf5bax5d[_0xdaa5[488]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[186]], [
              [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ]);
            _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
            _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[489] + _0xf5bax12;
            _0xf5bax5[_0xdaa5[292]](_0xf5bax5d[_0xdaa5[229]], _0xf5bax5d);
          } else {
            if (_0xf5bax5c[_0xdaa5[229]] == _0xdaa5[187]) {
              _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[187]][0]);
              _0xf5bax5d[_0xdaa5[227]][_0xdaa5[249]](0.5);
              _0xf5bax5d[_0xdaa5[488]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[187]], [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              ]);
              _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
              _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[489] + _0xf5bax12;
              _0xf5bax5[_0xdaa5[292]](_0xf5bax5d[_0xdaa5[229]], _0xf5bax5d);
            } else {
              if (_0xf5bax5c[_0xdaa5[229]] == _0xdaa5[490]) {
                _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[490]][0]);
                _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
                _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
                _0xf5bax5d[_0xdaa5[329]](
                  _0xdaa5[490],
                  _0xf5bax1e[_0xdaa5[490]]
                );
                _0xf5bax5d[_0xdaa5[332]](_0xdaa5[490], -1, 8);
                _0xf5bax5[_0xdaa5[292]](_0xdaa5[489] + _0xf5bax12, _0xf5bax5d);
              } else {
                _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](
                  _0xf5bax5c[_0xdaa5[229]]
                );
              }
            }
          }
        }
      }
      _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
      _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
      _0xf5bax5d[_0xdaa5[226]] = _0xf5bax5c[_0xdaa5[226]];
      _0xf5bax5d[_0xdaa5[228]] = _0xf5bax5c[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[230]](_0xf5bax5d);
      _0xf5bax50[_0xdaa5[476]](_0xf5bax5d);
      if (_0xf5bax5c[_0xdaa5[491]]) {
        _0xf5bax5d[_0xdaa5[250]][_0xdaa5[226]] = _0xf5bax5c[_0xdaa5[491]];
      }
      if (_0xf5bax5c[_0xdaa5[492]]) {
        _0xf5bax5d[_0xdaa5[250]][_0xdaa5[228]] = _0xf5bax5c[_0xdaa5[492]];
      }
      if (_0xf5bax5c[_0xdaa5[493]]) {
        _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = _0xf5bax5c[_0xdaa5[493]];
      }
      if (_0xf5bax5c[_0xdaa5[494]]) {
        _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = _0xf5bax5c[_0xdaa5[494]];
      }
    }
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[495]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax55 = _0xf5bax57[_0xdaa5[495]][_0xf5bax12];
      var _0xf5bax5d;
      switch (_0xf5bax55[_0xdaa5[229]]) {
        case _0xdaa5[192]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[192]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          break;
        case _0xdaa5[497]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[496]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          break;
        case _0xdaa5[498]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[498]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          break;
        case _0xdaa5[499]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[499]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          break;
        default:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[192]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
      }
      _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[500] + _0xf5bax12;
      _0xf5bax5d[_0xdaa5[226]] = _0xf5bax55[_0xdaa5[226]];
      _0xf5bax5d[_0xdaa5[228]] = _0xf5bax55[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[230]](_0xf5bax5d);
      this[_0xdaa5[424]][_0xdaa5[476]](_0xf5bax5d);
    }
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[501]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax56 = _0xf5bax57[_0xdaa5[501]][_0xf5bax12];
      var _0xf5bax5d;
      switch (_0xf5bax56[_0xdaa5[229]]) {
        case _0xdaa5[167]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[167]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[249]](0.5);
          _0xf5bax5d[_0xdaa5[250]][_0xdaa5[249]](0.9);
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[502], _0xf5bax1e[_0xdaa5[167]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[502], -1, 2);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          break;
        case _0xdaa5[168]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[168]][3]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[488]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[168]], [
            [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
            [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 1, 0, 3],
            [3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 3],
          ]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          break;
        case _0xdaa5[170]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[170]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 0.5;
          _0xf5bax5d[_0xdaa5[488]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[170]], [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          ]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 10);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          break;
        case _0xdaa5[166]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[166]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[504], _0xf5bax1e[_0xdaa5[166]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[504], -1, 12);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          _0xf5bax5d[_0xdaa5[328]] = { x: 1, y: 160, width: 103, height: 21 };
          break;
        case _0xdaa5[169]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[169]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 0.5;
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[505], _0xf5bax1e[_0xdaa5[169]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[505], -1, 7);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          break;
        case _0xdaa5[506]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[506]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          break;
        case _0xdaa5[507]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[165]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[504], _0xf5bax1e[_0xdaa5[165]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[504], -1, 12);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          _0xf5bax5d[_0xdaa5[328]] = { x: 1, y: 144, width: 103, height: 14 };
          break;
        case _0xdaa5[508]:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[508]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[328]] = { x: 0, y: 13, width: 60, height: 60 };
          break;
        case _0xdaa5[171]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[171]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[171]]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 5);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          _0xf5bax5d[_0xdaa5[328]] = { x: 5, y: 5, width: 62, height: 59 };
          break;
        case _0xdaa5[172]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[172]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 0;
          _0xf5bax5d[_0xdaa5[329]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[172]], [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            8,
            7,
            6,
            5,
            4,
            3,
            2,
            1,
          ]);
          _0xf5bax5d[_0xdaa5[332]](_0xdaa5[487], -1, 20);
          _0xf5bax5[_0xdaa5[292]](_0xdaa5[503] + _0xf5bax12, _0xf5bax5d);
          _0xf5bax5d[_0xdaa5[328]] = { x: 5, y: 5, width: 106, height: 100 };
          break;
        case _0xdaa5[173]:
          _0xf5bax5d = new Animable(_0xf5bax1e[_0xdaa5[173]][0]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax5d[_0xdaa5[328]] = { x: 5, y: 5, width: 106, height: 100 };
          break;
        default:
          _0xf5bax5d = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[506]);
          _0xf5bax5d[_0xdaa5[227]][_0xdaa5[228]] = 1;
      }
      _0xf5bax5d[_0xdaa5[229]] = _0xdaa5[503] + _0xf5bax12;
      _0xf5bax5d[_0xdaa5[226]] = _0xf5bax56[_0xdaa5[226]];
      _0xf5bax5d[_0xdaa5[228]] = _0xf5bax56[_0xdaa5[228]];
      _0xf5bax22[_0xdaa5[230]](_0xf5bax5d);
      this[_0xdaa5[425]][_0xdaa5[476]](_0xf5bax5d);
    }
    switch (_0xf5bax57[_0xdaa5[470]]) {
      case _0xdaa5[190]:
        _0xf5bax23[_0xdaa5[215]] =
          PIXI[_0xdaa5[293]][_0xdaa5[462]][_0xdaa5[509]][_0xdaa5[215]];
        var _0xf5bax5e = new Animable(_0xf5bax1e[_0xdaa5[182]][0]);
        _0xf5bax5e[_0xdaa5[226]] = -250;
        _0xf5bax5e[_0xdaa5[228]] = 1015;
        _0xf5bax5e[_0xdaa5[329]](_0xdaa5[487], _0xf5bax1e[_0xdaa5[182]]);
        _0xf5bax5e[_0xdaa5[332]](_0xdaa5[487], -1, 3);
        var _0xf5bax5f = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[439]);
        _0xf5bax5f[_0xdaa5[226]] = 1300;
        _0xf5bax5f[_0xdaa5[228]] = 980;
        _0xf5bax22[_0xdaa5[230]](_0xf5bax5f);
        _0xf5bax50[_0xdaa5[476]](_0xf5bax5f);
        _0xf5bax5f[_0xdaa5[510]] = function (_0xf5bax17) {
          _0xf5bax5f[_0xdaa5[226]] = 1300;
          Tweener[_0xdaa5[247]](
            _0xf5bax5f,
            { x: -500 },
            {
              time: 1700,
              delay: _0xf5bax17,
              transition: _0xdaa5[350],
              onComplete: function (_0xf5bax4e) {
                var _0xf5bax17 = 50 + Math[_0xdaa5[482]]() * 50;
                if (Math[_0xdaa5[482]]() > 0.5) {
                  _0xf5bax5e[_0xdaa5[510]](_0xf5bax17);
                } else {
                  _0xf5bax5f[_0xdaa5[510]](_0xf5bax17);
                }
              },
            }
          );
        };
        _0xf5bax22[_0xdaa5[230]](_0xf5bax5e);
        _0xf5bax50[_0xdaa5[476]](_0xf5bax5e);
        _0xf5bax5[_0xdaa5[292]](_0xdaa5[182], _0xf5bax5e);
        _0xf5bax5e[_0xdaa5[510]] = function (_0xf5bax17) {
          _0xf5bax5e[_0xdaa5[226]] = -250;
          Tweener[_0xdaa5[247]](
            _0xf5bax5e,
            { x: 750 },
            {
              time: 1300,
              delay: _0xf5bax17,
              transition: _0xdaa5[350],
              onComplete: function (_0xf5bax4e) {
                var _0xf5bax17 = 50 + Math[_0xdaa5[482]]() * 50;
                if (Math[_0xdaa5[482]]() > 0.5) {
                  _0xf5bax5e[_0xdaa5[510]](_0xf5bax17);
                } else {
                  _0xf5bax5f[_0xdaa5[510]](_0xf5bax17);
                }
              },
            }
          );
        };
        _0xf5bax5e[_0xdaa5[510]](100);
        var _0xf5bax60 = new PIXI[_0xdaa5[315]].TilingSprite(
          PIXI[_0xdaa5[293]][_0xdaa5[462]][_0xdaa5[511]][_0xdaa5[215]],
          640,
          48
        );
        _0xf5bax60[_0xdaa5[226]] = 0;
        _0xf5bax60[_0xdaa5[228]] = 1030;
        _0xf5bax60[_0xdaa5[512]] = 0;
        _0xf5bax22[_0xdaa5[230]](_0xf5bax60);
        Tweener[_0xdaa5[247]](
          _0xf5bax60,
          { tilePositionX: -80 },
          {
            time: 100,
            loop: -1,
            onUpdate: function (_0xf5bax4e) {
              _0xf5bax4e[_0xdaa5[513]][_0xdaa5[226]] = _0xf5bax4e[_0xdaa5[512]];
            },
          }
        );
        _0xf5bax50[_0xdaa5[476]](_0xf5bax60);
        break;
    }
    var _0xf5bax61 = new PIXI.Text(_0xdaa5[514] + (_0xf5bax2d + 1), {
      fontFamily: _0xdaa5[340],
      fontSize: 15,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax61[_0xdaa5[227]][_0xdaa5[226]] = 1;
    _0xf5bax61[_0xdaa5[226]] = 620;
    _0xf5bax61[_0xdaa5[228]] = 20;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax61);
    _0xf5bax50[_0xdaa5[476]](_0xf5bax61);
    _0xf5bax2e = new PIXI.Text(0 + _0xdaa5[515] + 12, {
      fontFamily: _0xdaa5[340],
      fontSize: 12,
      fill: 0xffffff,
      align: _0xdaa5[341],
    });
    _0xf5bax2e[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax2e[_0xdaa5[226]] = 590;
    _0xf5bax2e[_0xdaa5[228]] = 55;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax2e);
    _0xf5bax50[_0xdaa5[476]](_0xf5bax2e);
    _0xf5bax2f = new PIXI.Sprite(_0xf5bax25[_0xdaa5[215]]);
    _0xf5bax2f[_0xdaa5[250]][_0xdaa5[249]](0.4);
    _0xf5bax2f[_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax2f[_0xdaa5[226]] = 544;
    _0xf5bax2f[_0xdaa5[228]] = 68;
    _0xf5bax22[_0xdaa5[230]](_0xf5bax2f);
    _0xf5bax50[_0xdaa5[476]](_0xf5bax2f);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax25);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax25);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax24);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax24);
    _0xf5bax29[_0xdaa5[317]] = true;
    _0xf5bax22[_0xdaa5[446]](_0xf5bax29);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax29);
  };
  Game[_0xdaa5[211]][_0xdaa5[516]] = function () {
    _0xf5bax29[_0xdaa5[317]] = false;
    this[_0xdaa5[392]] = false;
    _0xf5bax25[_0xdaa5[317]] = false;
    _0xf5bax24[_0xdaa5[326]] = false;
    _0xf5bax24[_0xdaa5[327]] = false;
    _0xf5bax24[_0xdaa5[325]] = 0;
    _0xf5bax24[_0xdaa5[324]] = 0;
    _0xf5bax22[_0xdaa5[446]](_0xf5bax27);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax27);
    _0xf5bax27[_0xdaa5[317]] = true;
    _0xf5bax27[_0xdaa5[451]] = 0;
    Tweener[_0xdaa5[247]](
      _0xf5bax24,
      {
        x: _0xf5bax26[_0xdaa5[226]],
        y: _0xf5bax26[_0xdaa5[228]] - 20,
        scaleX: _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] * 0.5,
        scaleY: _0xf5bax24[_0xdaa5[250]][_0xdaa5[228]] * 0.5,
        alpha: 0,
      },
      { time: 50, transition: _0xdaa5[517] }
    );
    Tweener[_0xdaa5[247]](
      _0xf5bax27,
      { alpha: 1 },
      { time: 70, transition: _0xdaa5[517] }
    );
    _0xf5bax2d++;
    this[_0xdaa5[422]]++;
    if (this[_0xdaa5[422]] >= init[_0xdaa5[468]][_0xdaa5[224]]) {
      this[_0xdaa5[422]] = init[_0xdaa5[468]][_0xdaa5[224]] - 2;
    }
    _0xf5bax64 *= 1.25;
    if (_0xf5bax64 > 2.5) {
      _0xf5bax64 = 2.5;
    }
    var _0xf5bax3e = this;
    setTimeout(function () {
      var _0xf5bax62 = _0xf5bax3e[_0xdaa5[426]][_0xdaa5[518]](0);
      _0xf5bax3e[_0xdaa5[430]](_0xf5bax3e._level);
      _0xf5bax3e[_0xdaa5[435]]();
      _0xf5bax3e[_0xdaa5[456]](_0xf5bax62);
      Tweener[_0xdaa5[247]](
        _0xf5bax27,
        { alpha: 0 },
        { time: 70, transition: _0xdaa5[519] }
      );
    }, 1500);
  };
  var _0xf5bax63 = 1000;
  var _0xf5bax64 = 1.2;
  var _0xf5bax65 = 3;
  var _0xf5bax66 = 1;
  var _0xf5bax67 = 0;
  Game[_0xdaa5[211]][_0xdaa5[220]] = function (_0xf5baxa) {
    if (this[_0xdaa5[321]]) {
      return this[_0xdaa5[303]][_0xdaa5[371]](this._stage);
    }
    _0xf5bax5[_0xdaa5[220]](_0xf5baxa);
    var _0xf5bax3e = this;
    if (this[_0xdaa5[392]]) {
      _0xf5bax67++;
      if (_0xf5bax24[_0xdaa5[324]]) {
        _0xf5bax24[_0xdaa5[226]] +=
          _0xf5bax24[_0xdaa5[324]] *
          _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] *
          _0xf5bax64;
        if (
          _0xf5bax24[_0xdaa5[226]] > 640 &&
          _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] > 0
        ) {
          _0xf5bax24[_0xdaa5[226]] -= 640;
        } else {
          if (
            _0xf5bax24[_0xdaa5[226]] < 0 &&
            _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] < 0
          ) {
            _0xf5bax24[_0xdaa5[226]] += 640;
          }
        }
      }
      if (_0xf5bax24[_0xdaa5[325]] < 10 * 1) {
        _0xf5bax24[_0xdaa5[325]] += _0xf5bax66 * _0xf5bax64;
      }
      if (_0xf5bax24[_0xdaa5[325]]) {
        _0xf5bax24[_0xdaa5[228]] += _0xf5bax24[_0xdaa5[325]] * _0xf5bax64;
        var _0xf5bax68 = this[_0xdaa5[520]](_0xf5bax24);
        if (
          _0xf5bax68 &&
          _0xf5bax24[_0xdaa5[325]] < 15 * 1 &&
          _0xf5bax24[_0xdaa5[325]] > 0
        ) {
          _0xf5bax24[_0xdaa5[228]] = _0xf5bax68;
          _0xf5bax24[_0xdaa5[326]] = true;
          _0xf5bax24[_0xdaa5[327]] = true;
        } else {
        }
        if (_0xf5bax24[_0xdaa5[325]] > 10 * 1) {
          _0xf5bax24[_0xdaa5[325]] = 10 * 1;
        }
      }
      _0xf5bax24[_0xdaa5[452]]++;
      var _0xf5bax4c = this[_0xdaa5[426]][_0xdaa5[518]](0);
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5bax4b = _0xf5bax4c[_0xf5bax12];
        if (_0xf5bax4b[_0xdaa5[521]] > 0) {
          _0xf5bax4b[_0xdaa5[521]] -= _0xf5bax64;
          if (_0xf5bax4b[_0xdaa5[521]] <= 0) {
            _0xf5bax4b[_0xdaa5[332]](_0xdaa5[330], -1, 24);
          } else {
            continue;
          }
        } else {
          _0xf5bax4b[_0xdaa5[522]] += _0xf5bax4b[_0xdaa5[523]];
        }
        if (
          (_0xf5bax4b[_0xdaa5[522]] +
            _0xf5bax12 * 40 * _0xf5bax4b[_0xdaa5[523]]) %
            (180 * _0xf5bax4b[_0xdaa5[523]]) ==
            0 &&
          (_0xf5bax12 < 6 || this[_0xdaa5[426]][_0xdaa5[224]] < 3)
        ) {
          this[_0xdaa5[260]][_0xdaa5[525] + _0xf5bax4b[_0xdaa5[526]]][
            _0xdaa5[524]
          ]();
        }
        var _0xf5bax69 = 0;
        if (_0xf5bax4b[_0xdaa5[527]][_0xdaa5[224]]) {
          if (_0xf5bax4b[_0xdaa5[527]][0] <= _0xf5bax4b[_0xdaa5[522]]) {
            _0xf5bax69 = _0xf5bax4b[_0xdaa5[522]] - _0xf5bax4b[_0xdaa5[527]][0];
            _0xf5bax4b[_0xdaa5[527]][_0xdaa5[528]]();
            var _0xf5bax41 = _0xf5bax4b[_0xdaa5[529]][_0xdaa5[528]]();
            if (_0xf5bax41 == 1) {
              _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] = 1.6;
            } else {
              if (_0xf5bax41 < 0) {
                _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] = -1.6;
              } else {
                if (_0xf5bax41 == 0) {
                  _0xf5bax4b[_0xdaa5[325]] = -22;
                  _0xf5bax4b[_0xdaa5[332]](_0xdaa5[270], 0, 7);
                  _0xf5bax4b[_0xdaa5[467]](_0xdaa5[330], -1, 24);
                } else {
                  if (_0xf5bax41 == 2) {
                    _0xf5bax4b[_0xdaa5[325]] = 20;
                    _0xf5bax4b[_0xdaa5[332]](_0xdaa5[270], 0, 7);
                    _0xf5bax4b[_0xdaa5[467]](_0xdaa5[330], -1, 24);
                  }
                }
              }
            }
          }
        }
        if (_0xf5bax4b[_0xdaa5[324]]) {
          _0xf5bax4b[_0xdaa5[226]] +=
            _0xf5bax4b[_0xdaa5[324]] *
            _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] *
            (_0xf5bax4b[_0xdaa5[523]] + _0xf5bax69 * 2) *
            _0xf5bax64;
          if (
            _0xf5bax4b[_0xdaa5[226]] > 640 &&
            _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] > 0
          ) {
            _0xf5bax4b[_0xdaa5[226]] -= 640;
          } else {
            if (
              _0xf5bax4b[_0xdaa5[226]] < 0 &&
              _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] < 0
            ) {
              _0xf5bax4b[_0xdaa5[226]] += 640;
            }
          }
        }
        if (_0xf5bax4b[_0xdaa5[325]] < 10) {
          _0xf5bax4b[_0xdaa5[325]] +=
            _0xf5bax66 * (_0xf5bax4b[_0xdaa5[523]] + _0xf5bax69) * _0xf5bax64;
        }
        if (_0xf5bax4b[_0xdaa5[325]]) {
          _0xf5bax4b[_0xdaa5[228]] +=
            _0xf5bax4b[_0xdaa5[325]] *
            (_0xf5bax4b[_0xdaa5[523]] + _0xf5bax69) *
            _0xf5bax64;
          if (_0xf5bax4b[_0xdaa5[228]] > 888) {
            _0xf5bax4b[_0xdaa5[228]] = 888;
          }
          var _0xf5bax68 = this[_0xdaa5[520]](_0xf5bax4b);
          if (_0xf5bax68 && _0xf5bax4b[_0xdaa5[325]] < 15) {
            _0xf5bax4b[_0xdaa5[228]] = _0xf5bax68;
            _0xf5bax4b[_0xdaa5[326]] = true;
            _0xf5bax4b[_0xdaa5[327]] = true;
          }
          if (_0xf5bax4b[_0xdaa5[325]] > 10) {
            _0xf5bax4b[_0xdaa5[325]] = 10;
          }
        }
        if (
          _0xf5bax89(
            {
              x:
                _0xf5bax24[_0xdaa5[226]] - (_0xf5bax24[_0xdaa5[407]] * 0.5) / 2,
              y: _0xf5bax24[_0xdaa5[228]] - _0xf5bax24[_0xdaa5[408]] * 0.8,
              width: _0xf5bax24[_0xdaa5[407]] * 0.5,
              height: _0xf5bax24[_0xdaa5[408]] * 0.8,
            },
            {
              x:
                _0xf5bax4b[_0xdaa5[226]] - (_0xf5bax4b[_0xdaa5[407]] * 0.5) / 2,
              y: _0xf5bax4b[_0xdaa5[228]] - _0xf5bax4b[_0xdaa5[408]] * 0.8,
              width: _0xf5bax4b[_0xdaa5[407]] * 0.5,
              height: _0xf5bax4b[_0xdaa5[408]] * 0.8,
            }
          )
        ) {
          _0xf5bax52 = 0;
          _0xf5bax53 = _0xf5bax4b[_0xdaa5[226]];
          _0xf5bax54 = _0xf5bax4b[_0xdaa5[228]];
          this[_0xdaa5[530]]();
          break;
        }
      }
      if (
        _0xf5bax25[_0xdaa5[317]] &&
        _0xf5bax89(
          {
            x: _0xf5bax24[_0xdaa5[226]] - (_0xf5bax24[_0xdaa5[407]] * 0.5) / 2,
            y: _0xf5bax24[_0xdaa5[228]] - _0xf5bax24[_0xdaa5[408]],
            width: _0xf5bax24[_0xdaa5[407]] * 0.5,
            height: _0xf5bax24[_0xdaa5[408]],
          },
          {
            x: _0xf5bax25[_0xdaa5[226]] - _0xf5bax25[_0xdaa5[407]] / 2,
            y: _0xf5bax25[_0xdaa5[228]] - _0xf5bax25[_0xdaa5[408]] / 2,
            width: _0xf5bax25[_0xdaa5[407]],
            height: _0xf5bax25[_0xdaa5[408]],
          }
        )
      ) {
        _0xf5bax24[_0xdaa5[452]] = 0;
        this[_0xdaa5[428]]++;
        this[_0xdaa5[353]][_0xdaa5[352]][this[_0xdaa5[427]]]++;
        _0xf5bax2e[_0xdaa5[351]] = this[_0xdaa5[428]] + _0xdaa5[515] + 12;
        var _0xf5bax6a = PIXI[_0xdaa5[195]][_0xdaa5[225]](_0xdaa5[531]);
        _0xf5bax6a[_0xdaa5[227]][_0xdaa5[249]](0.5);
        _0xf5bax6a[_0xdaa5[226]] = _0xf5bax25[_0xdaa5[226]];
        _0xf5bax6a[_0xdaa5[228]] = _0xf5bax25[_0xdaa5[228]] - 20;
        _0xf5bax6a[_0xdaa5[451]] = 1;
        _0xf5bax22[_0xdaa5[230]](_0xf5bax6a);
        Tweener[_0xdaa5[247]](
          _0xf5bax6a,
          { alpha: 0, y: _0xf5bax6a[_0xdaa5[228]] - 80 },
          {
            time: 80,
            onComplete: function (_0xf5bax4e) {
              _0xf5bax4e[_0xdaa5[532]][_0xdaa5[446]](_0xf5bax4e);
              delete _0xf5bax4e;
            },
          }
        );
        if (
          this[_0xdaa5[428]] % 3 == 0 &&
          this[_0xdaa5[426]][_0xdaa5[224]] < 20
        ) {
          this[_0xdaa5[459]]();
        }
        if (this[_0xdaa5[428]] < 12) {
          _0xf5bax25[_0xdaa5[317]] = true;
          this[_0xdaa5[454]]();
        } else {
          _0xf5bax25[_0xdaa5[317]] = false;
          this[_0xdaa5[533]]();
        }
        this[_0xdaa5[429]]++;
        this[_0xdaa5[436]]();
        this[_0xdaa5[260]][_0xdaa5[261]][_0xdaa5[524]]();
      }
      var _0xf5bax4c = this[_0xdaa5[424]][_0xdaa5[518]](0);
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5bax55 = _0xf5bax4c[_0xf5bax12];
        var _0xf5bax6b = _0xf5bax83(_0xf5bax55, _0xf5bax24);
        if (_0xf5bax6b) {
          if (
            _0xf5bax24[_0xdaa5[228]] <= _0xf5bax55[_0xdaa5[228]] &&
            _0xf5bax6b[_0xdaa5[534]] <= _0xf5bax24[_0xdaa5[325]]
          ) {
            _0xf5bax24[_0xdaa5[228]] =
              _0xf5bax55[_0xdaa5[228]] -
              _0xf5bax55[_0xdaa5[408]] * _0xf5bax55[_0xdaa5[227]][_0xdaa5[228]];
          } else {
            if (
              !(
                (_0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] > 0 &&
                  _0xf5bax24[_0xdaa5[226]] +
                    _0xf5bax24[_0xdaa5[324]] *
                      _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] >
                    _0xf5bax55[_0xdaa5[226]]) ||
                (_0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] < 0 &&
                  _0xf5bax24[_0xdaa5[226]] +
                    _0xf5bax24[_0xdaa5[324]] *
                      _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] <
                    _0xf5bax55[_0xdaa5[226]] + _0xf5bax55[_0xdaa5[407]])
              ) &&
              _0xf5bax24[_0xdaa5[228]] <=
                _0xf5bax55[_0xdaa5[228]] +
                  _0xf5bax24[_0xdaa5[328]][_0xdaa5[408]] / 2 &&
              _0xf5bax6b[_0xdaa5[535]] <=
                Math[_0xdaa5[238]](
                  _0xf5bax24[_0xdaa5[324]] *
                    _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] *
                    2
                )
            ) {
              _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] *= -1;
              if (_0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] > 0) {
                this[_0xdaa5[536]](1);
              } else {
                this[_0xdaa5[536]](-1);
              }
            } else {
            }
          }
          break;
        }
      }
      var _0xf5bax4c = this[_0xdaa5[425]][_0xdaa5[518]](0);
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5bax56 = _0xf5bax4c[_0xf5bax12];
        var _0xf5bax6b = _0xf5bax83(_0xf5bax56, _0xf5bax24);
        if (_0xf5bax6b) {
          this[_0xdaa5[530]]();
        }
      }
      if (_0xf5bax26) {
        var _0xf5bax6c = _0xf5bax90(_0xf5bax26, _0xf5bax24);
        if (!_0xf5bax26[_0xdaa5[537]] && _0xf5bax6c < 250) {
          _0xf5bax26[_0xdaa5[537]] = true;
          _0xf5bax26[_0xdaa5[332]](_0xdaa5[537], 0, 30);
        } else {
          if (_0xf5bax26[_0xdaa5[537]] && _0xf5bax6c > 250) {
            _0xf5bax26[_0xdaa5[537]] = false;
            _0xf5bax26[_0xdaa5[538]]();
            _0xf5bax26[_0xdaa5[215]] = _0xf5bax26[_0xdaa5[539]](
              _0xdaa5[537]
            )[0];
          }
        }
      }
      if (
        _0xf5bax26 &&
        _0xf5bax26[_0xdaa5[317]] &&
        _0xf5bax89(
          {
            x: _0xf5bax24[_0xdaa5[226]] - (_0xf5bax24[_0xdaa5[407]] * 0.5) / 2,
            y: _0xf5bax24[_0xdaa5[228]] - _0xf5bax24[_0xdaa5[408]] * 0.8,
            width: _0xf5bax24[_0xdaa5[407]] * 0.5,
            height: _0xf5bax24[_0xdaa5[408]] * 0.8,
          },
          {
            x: _0xf5bax26[_0xdaa5[226]] - (_0xf5bax26[_0xdaa5[407]] * 0.5) / 2,
            y: _0xf5bax26[_0xdaa5[228]] - _0xf5bax26[_0xdaa5[408]],
            width: _0xf5bax26[_0xdaa5[407]] * 0.5,
            height: _0xf5bax26[_0xdaa5[408]],
          }
        )
      ) {
        this[_0xdaa5[260]][_0xdaa5[267]][_0xdaa5[524]]();
        this[_0xdaa5[516]]();
      }
    } else {
      if (_0xf5bax24[_0xdaa5[331]]) {
        var _0xf5bax6d = Math[_0xdaa5[482]]() * 100;
        var _0xf5bax6e = Math[_0xdaa5[482]]() * 100;
        if (this[_0xdaa5[418]] % 2 == 0 && _0xf5bax52 < 100) {
          var _0xf5bax4f = _0xf5bax52 / 100;
          var _0xf5bax6f = new Animable(_0xf5bax1e[_0xdaa5[161]][0]);
          _0xf5bax6f[_0xdaa5[250]][_0xdaa5[249]](2.6);
          _0xf5bax6f[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
          _0xf5bax6f[_0xdaa5[227]][_0xdaa5[228]] = 1;
          _0xf5bax6f[_0xdaa5[226]] =
            _0xf5bax53 +
            (Math[_0xdaa5[482]]() * 640 - _0xf5bax53) * _0xf5bax4f +
            _0xf5bax6d * Tweener[_0xdaa5[541]][_0xdaa5[540]](_0xf5bax4f);
          _0xf5bax6f[_0xdaa5[228]] =
            _0xf5bax54 +
            (Math[_0xdaa5[482]]() * 1000 - _0xf5bax54) * _0xf5bax4f +
            _0xf5bax6e * Tweener[_0xdaa5[541]][_0xdaa5[542]](_0xf5bax4f);
          _0xf5bax22[_0xdaa5[230]](_0xf5bax6f);
          _0xf5bax51[_0xdaa5[476]](_0xf5bax6f);
          _0xf5bax52++;
        }
      }
    }
    this[_0xdaa5[418]]++;
    if (this[_0xdaa5[418]] == 3000) {
      this[_0xdaa5[418]] = 0;
    }
    this[_0xdaa5[303]][_0xdaa5[371]](this._stage);
    this[_0xdaa5[380]][_0xdaa5[543]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[544]] = function () {};
  Game[_0xdaa5[211]][_0xdaa5[530]] = function () {
    this[_0xdaa5[392]] = false;
    _0xf5bax24[_0xdaa5[331]] = true;
    _0xf5bax24[_0xdaa5[332]](_0xdaa5[331], 0, 10);
    this[_0xdaa5[260]][_0xdaa5[264]][_0xdaa5[524]]();
    this[_0xdaa5[544]]();
    setTimeout(
      function () {
        _0xf5bax24[_0xdaa5[317]] = false;
        this[_0xdaa5[303]][_0xdaa5[371]](this._stage);
        this[_0xdaa5[460]]();
      }[_0xdaa5[246]](this),
      3000
    );
    this[_0xdaa5[545]]();
  };
  Game[_0xdaa5[211]][_0xdaa5[545]] = function () {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[426]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax4b = this[_0xdaa5[426]][_0xf5bax12];
      _0xf5bax5[_0xdaa5[449]](_0xdaa5[450] + _0xf5bax12);
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[520]] = function (_0xf5bax13) {
    var _0xf5bax70 = false;
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[424]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax6b = _0xf5bax83(this[_0xdaa5[424]][_0xf5bax12], _0xf5bax13);
      if (_0xf5bax6b) {
        if (
          _0xf5bax13[_0xdaa5[228]] <=
            this[_0xdaa5[424]][_0xf5bax12][_0xdaa5[228]] &&
          _0xf5bax6b[_0xdaa5[534]] <= _0xf5bax13[_0xdaa5[325]] * 2
        ) {
          return (
            this[_0xdaa5[424]][_0xf5bax12][_0xdaa5[228]] -
            this[_0xdaa5[424]][_0xf5bax12][_0xdaa5[408]] *
              this[_0xdaa5[424]][_0xf5bax12][_0xdaa5[227]][_0xdaa5[228]]
          );
        }
      }
    }
    var _0xf5bax71 = 17 * _0xf5bax64;
    var _0xf5bax57 = init[_0xdaa5[468]][this[_0xdaa5[422]]];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax58 = _0xf5bax57[_0xdaa5[469]][_0xf5bax12];
      if (_0xf5bax13[_0xdaa5[228]] > _0xf5bax58[_0xdaa5[228]] + _0xf5bax71) {
        continue;
      }
      if (
        _0xf5bax89(
          {
            x: _0xf5bax13[_0xdaa5[226]] - (_0xf5bax13[_0xdaa5[407]] * 0.5) / 2,
            y: _0xf5bax13[_0xdaa5[228]] - _0xf5bax71,
            width: _0xf5bax13[_0xdaa5[407]] * 0.5,
            height: _0xf5bax71,
          },
          {
            x: _0xf5bax58[_0xdaa5[226]],
            y: _0xf5bax58[_0xdaa5[228]],
            width: (_0xf5bax58[_0xdaa5[474]] - 2) * 34 + 72,
            height: 35,
          }
        )
      ) {
        return _0xf5bax58[_0xdaa5[228]];
      }
    }
    return false;
  };
  Game[_0xdaa5[211]][_0xdaa5[459]] = function (_0xf5bax72, _0xf5bax17) {
    if (!_0xf5bax17) {
      this[_0xdaa5[260]][_0xdaa5[273]][_0xdaa5[524]]();
    }
    var _0xf5bax73 = init[_0xdaa5[468]][this[_0xdaa5[422]]][_0xdaa5[470]];
    var _0xf5bax74 = _0xdaa5[546];
    var _0xf5bax75 =
      _0xf5bax72 == undefined
        ? Math[_0xdaa5[235]](Math[_0xdaa5[482]]())
        : _0xf5bax72;
    switch (_0xf5bax73) {
      case _0xdaa5[190]:
        _0xf5bax74 = _0xf5bax75 ? _0xdaa5[160] : _0xdaa5[161];
        break;
    }
    var _0xf5bax76 = this[_0xdaa5[426]][_0xdaa5[224]]
      ? Math[_0xdaa5[235]](Math[_0xdaa5[482]]() * 4)
      : 0;
    var _0xf5bax4b = new Animable(_0xf5bax1e[_0xf5bax74][0]);
    _0xf5bax4b[_0xdaa5[250]][_0xdaa5[226]] =
      _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]];
    _0xf5bax4b[_0xdaa5[250]][_0xdaa5[228]] =
      _0xf5bax24[_0xdaa5[250]][_0xdaa5[228]];
    _0xf5bax4b[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax4b[_0xdaa5[227]][_0xdaa5[228]] = 1;
    _0xf5bax4b[_0xdaa5[226]] = _0xf5bax24[_0xdaa5[226]];
    _0xf5bax4b[_0xdaa5[228]] = _0xf5bax24[_0xdaa5[228]];
    _0xf5bax4b[_0xdaa5[526]] = _0xf5bax76;
    _0xf5bax4b[_0xdaa5[451]] = 0;
    _0xf5bax4b[_0xdaa5[523]] = 1;
    _0xf5bax4b[_0xdaa5[324]] = _0xf5bax24[_0xdaa5[324]];
    _0xf5bax4b[_0xdaa5[325]] = _0xf5bax24[_0xdaa5[325]];
    _0xf5bax4b[_0xdaa5[457]] = _0xf5bax75;
    _0xf5bax4b[_0xdaa5[522]] = _0xf5bax67;
    _0xf5bax4b[_0xdaa5[547]] = 0;
    _0xf5bax4b[_0xdaa5[521]] = _0xf5bax4b[_0xdaa5[458]] =
      _0xf5bax17 ||
      Math[_0xdaa5[235]](30 + Math[_0xdaa5[482]]() * (30 + 60 * 0));
    _0xf5bax4b[_0xdaa5[529]] = [];
    _0xf5bax4b[_0xdaa5[527]] = [];
    _0xf5bax22[_0xdaa5[230]](_0xf5bax4b);
    _0xf5bax4b[_0xdaa5[329]](_0xdaa5[270], _0xf5bax1e[_0xf5bax74], [9]);
    _0xf5bax4b[_0xdaa5[329]](_0xdaa5[330], _0xf5bax1e[_0xf5bax74], [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
    ]);
    _0xf5bax4b[_0xdaa5[229]] = _0xdaa5[450] + this[_0xdaa5[426]][_0xdaa5[224]];
    _0xf5bax5[_0xdaa5[292]](
      _0xdaa5[450] + this[_0xdaa5[426]][_0xdaa5[224]],
      _0xf5bax4b
    );
    this[_0xdaa5[426]][_0xdaa5[476]](_0xf5bax4b);
    _0xf5bax4b[_0xdaa5[548]] = 0;
    Tweener[_0xdaa5[247]](
      _0xf5bax4b,
      { blinkTime: 100 },
      {
        time: 70,
        onUpdate: function (_0xf5bax4e) {
          _0xf5bax4e[_0xdaa5[451]] =
            Math[_0xdaa5[549]](_0xf5bax4e[_0xdaa5[548]] / 10) % 2 == 0;
        },
      }
    );
  };
  Game[_0xdaa5[211]][_0xdaa5[454]] = function (_0xf5bax77) {
    var _0xf5bax57 = init[_0xdaa5[468]][this[_0xdaa5[422]]];
    var _0xf5bax78 = [];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (_0xf5bax12 != _0xf5bax25[_0xdaa5[453]]) {
        _0xf5bax78[_0xdaa5[476]](_0xf5bax57[_0xdaa5[469]][_0xf5bax12]);
      }
    }
    var _0xf5bax79 =
      _0xf5bax77 ||
      Math[_0xdaa5[549]](Math[_0xdaa5[482]]() * _0xf5bax78[_0xdaa5[224]]);
    var _0xf5bax58 = _0xf5bax78[_0xf5bax79];
    _0xf5bax25[_0xdaa5[453]] = _0xf5bax57[_0xdaa5[469]][_0xdaa5[550]](
      _0xf5bax58
    );
    _0xf5bax25[_0xdaa5[226]] =
      _0xf5bax58[_0xdaa5[226]] + Math[_0xdaa5[482]]() * 150;
    _0xf5bax25[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]] - 35;
    _0xf5bax25[_0xdaa5[317]] = true;
    if (_0xf5bax25[_0xdaa5[226]] + _0xf5bax25[_0xdaa5[407]] / 2 > 640) {
      _0xf5bax25[_0xdaa5[226]] = 640 - _0xf5bax25[_0xdaa5[407]] / 2;
    } else {
      if (_0xf5bax25[_0xdaa5[226]] - _0xf5bax25[_0xdaa5[407]] / 2 < 0) {
        _0xf5bax25[_0xdaa5[226]] = _0xf5bax25[_0xdaa5[407]] / 2;
      }
    }
    Tweener[_0xdaa5[247]](
      _0xf5bax25,
      { y: _0xf5bax25[_0xdaa5[228]] - 10 },
      { time: 60, loop: -1, transition: _0xdaa5[483] }
    );
    var _0xf5bax4c = this[_0xdaa5[424]][_0xdaa5[518]](0);
    _0xf5bax4c = _0xf5bax4c[_0xdaa5[551]](this._traps);
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax55 = _0xf5bax4c[_0xf5bax12];
      var _0xf5bax6b = _0xf5bax83(_0xf5bax55, _0xf5bax25);
      if (_0xf5bax6b) {
        _0xf5bax25[_0xdaa5[226]] =
          _0xf5bax55[_0xdaa5[226]] + _0xf5bax55[_0xdaa5[407]] * 1.5 + 20;
        if (_0xf5bax25[_0xdaa5[226]] >= 620) {
          _0xf5bax25[_0xdaa5[226]] -= 620;
        }
        break;
      }
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[533]] = function () {
    var _0xf5bax57 = init[_0xdaa5[468]][this[_0xdaa5[422]]];
    var _0xf5bax7a = _0xdaa5[378];
    switch (_0xf5bax57[_0xdaa5[470]]) {
      case _0xdaa5[552]:
        _0xf5bax7a = _0xdaa5[378];
        break;
      case _0xdaa5[554]:
        _0xf5bax7a = _0xdaa5[553];
        break;
      case _0xdaa5[556]:
        _0xf5bax7a = _0xdaa5[555];
        break;
      case _0xdaa5[477]:
        _0xf5bax7a = _0xdaa5[557];
        break;
      case _0xdaa5[559]:
        _0xf5bax7a = _0xdaa5[558];
        break;
      case _0xdaa5[479]:
        _0xf5bax7a = _0xdaa5[560];
        break;
      case _0xdaa5[190]:
        _0xf5bax7a = _0xdaa5[561];
        break;
    }
    var _0xf5bax78 = [];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax57[_0xdaa5[469]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (!_0xf5bax57[_0xdaa5[469]][_0xf5bax12][_0xdaa5[562]]) {
        _0xf5bax78[_0xdaa5[476]](_0xf5bax57[_0xdaa5[469]][_0xf5bax12]);
      }
    }
    var _0xf5bax79 = Math[_0xdaa5[549]](
      Math[_0xdaa5[482]]() * _0xf5bax78[_0xdaa5[224]]
    );
    var _0xf5bax58 = _0xf5bax78[_0xf5bax79];
    if (_0xf5bax26) {
      _0xf5bax22[_0xdaa5[446]](_0xf5bax28);
      _0xf5bax22[_0xdaa5[446]](_0xf5bax26);
    }
    _0xf5bax26 = new Animable(_0xf5bax1e[_0xdaa5[563] + _0xf5bax7a][0]);
    _0xf5bax26[_0xdaa5[226]] =
      _0xf5bax58[_0xdaa5[226]] +
      _0xf5bax26[_0xdaa5[407]] / 2 +
      Math[_0xdaa5[482]]() * 115;
    _0xf5bax26[_0xdaa5[228]] = _0xf5bax58[_0xdaa5[228]] - 2;
    _0xf5bax26[_0xdaa5[227]][_0xdaa5[226]] = 0.5;
    _0xf5bax26[_0xdaa5[227]][_0xdaa5[228]] = 1;
    _0xf5bax26[_0xdaa5[317]] = true;
    _0xf5bax26[_0xdaa5[451]] = 0;
    _0xf5bax26[_0xdaa5[329]](
      _0xdaa5[537],
      _0xf5bax1e[_0xdaa5[563] + _0xf5bax7a]
    );
    _0xf5bax22[_0xdaa5[472]](
      _0xf5bax26,
      _0xf5bax22[_0xdaa5[241]][_0xdaa5[224]] - 4
    );
    _0xf5bax5[_0xdaa5[292]](_0xdaa5[448], _0xf5bax26);
    if (_0xf5bax26[_0xdaa5[226]] + _0xf5bax26[_0xdaa5[407]] / 2 > 640) {
      _0xf5bax26[_0xdaa5[226]] = 640 - _0xf5bax26[_0xdaa5[407]] / 2;
    } else {
      if (_0xf5bax26[_0xdaa5[226]] - _0xf5bax26[_0xdaa5[407]] / 2 < 0) {
        _0xf5bax26[_0xdaa5[226]] = _0xf5bax26[_0xdaa5[407]] / 2;
      }
    }
    Tweener[_0xdaa5[247]](_0xf5bax26, { alpha: 1 }, { time: 15 });
    _0xf5bax28 = new Animable(_0xf5bax1e[_0xdaa5[164]][0]);
    _0xf5bax28[_0xdaa5[227]][_0xdaa5[249]](0.5);
    _0xf5bax28[_0xdaa5[226]] = _0xf5bax26[_0xdaa5[226]];
    _0xf5bax28[_0xdaa5[228]] =
      _0xf5bax26[_0xdaa5[228]] - _0xf5bax26[_0xdaa5[408]] - 20;
    _0xf5bax28[_0xdaa5[329]](_0xdaa5[164], _0xf5bax1e[_0xdaa5[164]]);
    _0xf5bax22[_0xdaa5[472]](
      _0xf5bax28,
      _0xf5bax22[_0xdaa5[241]][_0xdaa5[224]] - 3
    );
    _0xf5bax28[_0xdaa5[332]](_0xdaa5[164], -1, 2);
    _0xf5bax5[_0xdaa5[292]](_0xdaa5[448], _0xf5bax28);
    _0xf5bax22[_0xdaa5[446]](_0xf5bax24);
    _0xf5bax22[_0xdaa5[230]](_0xf5bax24);
  };
  Game[_0xdaa5[211]][_0xdaa5[394]] = function (_0xf5bax41) {};
  Game[_0xdaa5[211]][_0xdaa5[393]] = function (_0xf5bax41) {
    switch (_0xf5bax41) {
      case 0:
        _0xf5bax24[_0xdaa5[326]] = false;
        _0xf5bax24[_0xdaa5[327]] = false;
        _0xf5bax24[_0xdaa5[325]] = -22 * 1;
        _0xf5bax24[_0xdaa5[332]](_0xdaa5[270], 0, 7);
        _0xf5bax24[_0xdaa5[467]](_0xdaa5[330], -1, 24);
        this[_0xdaa5[260]][_0xdaa5[270]][_0xdaa5[524]]();
        break;
      case 1:
        _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] = 1.6;
        break;
      case -1:
        _0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] = -1.6;
        break;
      case 2:
        _0xf5bax24[_0xdaa5[326]] = false;
        _0xf5bax24[_0xdaa5[327]] = false;
        _0xf5bax24[_0xdaa5[325]] = 20 * 1;
        _0xf5bax24[_0xdaa5[332]](_0xdaa5[270], 0, 7);
        _0xf5bax24[_0xdaa5[467]](_0xdaa5[330], -1, 24);
        break;
    }
    if (!this[_0xdaa5[353]][_0xdaa5[412]]) {
      this[_0xdaa5[353]][_0xdaa5[412]] = true;
    }
    this[_0xdaa5[536]](_0xf5bax41);
  };
  Game[_0xdaa5[211]][_0xdaa5[536]] = function (_0xf5bax41) {
    var _0xf5bax4c = this[_0xdaa5[426]][_0xdaa5[518]](0);
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax4c[_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5bax4b = _0xf5bax4c[_0xf5bax12];
      _0xf5bax4b[_0xdaa5[529]][_0xdaa5[476]](_0xf5bax41);
      var _0xf5bax7b = _0xf5bax4b[_0xdaa5[527]][_0xdaa5[564]](function (
        _0xf5bax7c,
        _0xf5bax7d
      ) {
        return _0xf5bax7c + _0xf5bax7d;
      },
      0);
      var _0xf5bax7e = _0xf5bax67 - _0xf5bax4b[_0xdaa5[522]] - _0xf5bax7b;
      _0xf5bax4b[_0xdaa5[527]][_0xdaa5[476]](_0xf5bax67);
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[440]] = function () {
    if (!this[_0xdaa5[565]]) {
      this[_0xdaa5[565]] = true;
      PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[431]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[441]] = function () {
    if (this[_0xdaa5[565]]) {
      this[_0xdaa5[565]] = false;
      PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[313]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[294]] = function (_0xf5bax7f, _0xf5bax80) {
    this[_0xdaa5[251]] = _0xdaa5[566];
    this[_0xdaa5[296]](_0xf5bax80);
  };
  Game[_0xdaa5[211]][_0xdaa5[397]] = function (_0xf5bax14) {
    if (!this[_0xdaa5[415]] || this[_0xdaa5[415]] != _0xf5bax14[_0xdaa5[567]]) {
      if (
        this[_0xdaa5[389]] ||
        !this[_0xdaa5[392]] ||
        this[_0xdaa5[320]] ||
        this[_0xdaa5[321]] ||
        _0xf5bax2b
      ) {
        return;
      }
      this[_0xdaa5[415]] = _0xf5bax14[_0xdaa5[567]];
      switch (_0xf5bax14[_0xdaa5[567]]) {
        case 39:
          if (_0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] < 0) {
            this[_0xdaa5[393]](1);
            this[_0xdaa5[394]](1);
          }
          break;
        case 37:
          if (_0xf5bax24[_0xdaa5[250]][_0xdaa5[226]] > 0) {
            this[_0xdaa5[393]](-1);
            this[_0xdaa5[394]](-1);
          }
          break;
        case 38:
          if (_0xf5bax24[_0xdaa5[326]]) {
            this[_0xdaa5[393]](0);
            this[_0xdaa5[394]](0);
          }
          break;
        case 32:
          if (_0xf5bax24[_0xdaa5[326]]) {
            this[_0xdaa5[393]](0);
            this[_0xdaa5[394]](0);
          }
          break;
        case 40:
          if (_0xf5bax24[_0xdaa5[327]] && _0xf5bax24[_0xdaa5[228]] < 800) {
            this[_0xdaa5[393]](2);
            this[_0xdaa5[394]](2);
          }
          break;
      }
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[400]] = function (_0xf5bax14) {
    if ((this[_0xdaa5[415]] = _0xf5bax14[_0xdaa5[567]])) {
      this[_0xdaa5[415]] = null;
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[385]] = function () {};
  function _0xf5bax81(_0xf5bax82) {
    return _0xf5bax82[
      Math[_0xdaa5[235]](Math[_0xdaa5[482]]() * (_0xf5bax82[_0xdaa5[224]] - 1))
    ];
  }
  function _0xf5bax83(_0xf5bax84, _0xf5bax85) {
    var _0xf5bax86 = {
      x:
        _0xf5bax84[_0xdaa5[226]] -
        _0xf5bax84[_0xdaa5[407]] *
          (_0xf5bax84[_0xdaa5[227]][_0xdaa5[226]] - 0.5),
      y:
        _0xf5bax84[_0xdaa5[228]] -
        _0xf5bax84[_0xdaa5[408]] *
          (_0xf5bax84[_0xdaa5[227]][_0xdaa5[228]] - 0.5),
      width: _0xf5bax84[_0xdaa5[407]],
      height: _0xf5bax84[_0xdaa5[408]],
    };
    if (_0xf5bax84[_0xdaa5[328]]) {
      _0xf5bax86[_0xdaa5[226]] += _0xf5bax84[_0xdaa5[328]][_0xdaa5[226]] / 2;
      _0xf5bax86[_0xdaa5[228]] += _0xf5bax84[_0xdaa5[328]][_0xdaa5[228]] / 2;
      _0xf5bax86[_0xdaa5[407]] = _0xf5bax84[_0xdaa5[328]][_0xdaa5[407]];
      _0xf5bax86[_0xdaa5[408]] = _0xf5bax84[_0xdaa5[328]][_0xdaa5[408]];
    }
    var _0xf5bax87 = {
      x:
        _0xf5bax85[_0xdaa5[226]] -
        _0xf5bax85[_0xdaa5[407]] *
          (_0xf5bax85[_0xdaa5[227]][_0xdaa5[226]] - 0.5),
      y:
        _0xf5bax85[_0xdaa5[228]] -
        _0xf5bax85[_0xdaa5[408]] *
          (_0xf5bax85[_0xdaa5[227]][_0xdaa5[228]] - 0.5),
      width: _0xf5bax85[_0xdaa5[407]],
      height: _0xf5bax85[_0xdaa5[408]],
    };
    if (_0xf5bax85[_0xdaa5[328]]) {
      _0xf5bax87[_0xdaa5[226]] += _0xf5bax85[_0xdaa5[328]][_0xdaa5[226]] / 2;
      _0xf5bax87[_0xdaa5[228]] += _0xf5bax85[_0xdaa5[328]][_0xdaa5[228]] / 2;
      _0xf5bax87[_0xdaa5[407]] = _0xf5bax85[_0xdaa5[328]][_0xdaa5[407]];
      _0xf5bax87[_0xdaa5[408]] = _0xf5bax85[_0xdaa5[328]][_0xdaa5[408]];
    }
    var _0xf5bax15 =
      Math[_0xdaa5[238]](_0xf5bax86[_0xdaa5[226]] - _0xf5bax87[_0xdaa5[226]]) -
      (_0xf5bax86[_0xdaa5[407]] / 2 + _0xf5bax87[_0xdaa5[407]] / 2);
    var _0xf5bax88 =
      Math[_0xdaa5[238]](_0xf5bax86[_0xdaa5[228]] - _0xf5bax87[_0xdaa5[228]]) -
      (_0xf5bax86[_0xdaa5[408]] / 2 + _0xf5bax87[_0xdaa5[408]] / 2);
    if (_0xf5bax15 < 0 && _0xf5bax88 < 0) {
      return { dx: -_0xf5bax15, dy: -_0xf5bax88 };
    } else {
      return false;
    }
  }
  function _0xf5bax89(_0xf5bax86, _0xf5bax87) {
    return !(
      _0xf5bax87[_0xdaa5[226]] >
        _0xf5bax86[_0xdaa5[226]] + _0xf5bax86[_0xdaa5[407]] ||
      _0xf5bax87[_0xdaa5[226]] + _0xf5bax87[_0xdaa5[407]] <
        _0xf5bax86[_0xdaa5[226]] ||
      _0xf5bax87[_0xdaa5[228]] >
        _0xf5bax86[_0xdaa5[228]] + _0xf5bax86[_0xdaa5[408]] ||
      _0xf5bax87[_0xdaa5[228]] + _0xf5bax87[_0xdaa5[408]] <
        _0xf5bax86[_0xdaa5[228]]
    );
  }
  function _0xf5bax8a(_0xf5bax4c, _0xf5bax8b) {
    var _0xf5bax3d = _0xf5bax4c[_0xdaa5[550]](_0xf5bax8b);
    if (_0xf5bax3d > -1) {
      _0xf5bax4c[_0xdaa5[568]](_0xf5bax3d, 1);
      var _0xf5bax8c = _0xf5bax8b[_0xdaa5[532]] || this[_0xdaa5[302]];
      _0xf5bax8c[_0xdaa5[446]](_0xf5bax8b);
    }
    _0xf5bax8b[_0xdaa5[447]]();
  }
  function _0xf5bax8d(_0xf5bax4c, _0xf5bax8e) {
    var _0xf5bax8f = _0xf5bax8e || _0xf5bax22;
    if (_0xf5bax4c) {
      while (_0xf5bax4c[_0xdaa5[224]] > 0) {
        try {
          _0xf5bax8f[_0xdaa5[446]](_0xf5bax4c[_0xdaa5[528]]());
        } catch (err) {
          console[_0xdaa5[439]](err, _0xdaa5[569]);
        }
      }
    }
  }
  function _0xf5bax90(_0xf5bax91, _0xf5bax92) {
    var _0xf5bax15 = _0xf5bax91[_0xdaa5[226]] - _0xf5bax92[_0xdaa5[226]];
    var _0xf5bax88 = _0xf5bax91[_0xdaa5[228]] - _0xf5bax92[_0xdaa5[228]];
    return Math[_0xdaa5[570]](
      _0xf5bax15 * _0xf5bax15 + _0xf5bax88 * _0xf5bax88
    );
  }
  function _0xf5bax93(_0xf5bax94, _0xf5bax95) {
    var _0xf5bax96 = Math[_0xdaa5[571]] * 2;
    var _0xf5bax97 = Math[_0xdaa5[238]](_0xf5bax95 - _0xf5bax94) % _0xf5bax96;
    var _0xf5bax6c =
      _0xf5bax97 > Math[_0xdaa5[571]] ? _0xf5bax96 - _0xf5bax97 : _0xf5bax97;
    return _0xf5bax6c;
  }
  function _0xf5bax98(_0xf5bax99) {
    return Math[_0xdaa5[235]](Math[_0xdaa5[482]]() * (_0xf5bax99 - 1));
  }
  function _0xf5bax9a(_0xf5bax5d) {
    Tweener[_0xdaa5[233]](_0xf5bax5d);
    _0xf5bax5[_0xdaa5[449]](_0xf5bax5d[_0xdaa5[229]] || null);
    if (_0xf5bax5d[_0xdaa5[532]]) {
      _0xf5bax5d[_0xdaa5[532]][_0xdaa5[446]](_0xf5bax5d);
    }
    delete _0xf5bax5d;
  }
  Game[_0xdaa5[211]][_0xdaa5[572]] = function () {
    if (!this[_0xdaa5[401]]) {
      this[_0xdaa5[401]] = true;
      Howler[_0xdaa5[572]](true);
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[573]] = function () {
    if (this[_0xdaa5[401]]) {
      this[_0xdaa5[401]] = false;
      Howler[_0xdaa5[572]](false);
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[574]] = function () {
    console[_0xdaa5[439]](_0xdaa5[575]);
    if (!this[_0xdaa5[320]] && this[_0xdaa5[417]]) {
      this[_0xdaa5[320]] = true;
      this[_0xdaa5[441]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[576]] = function () {
    if (this[_0xdaa5[320]] && this[_0xdaa5[417]]) {
      this[_0xdaa5[320]] = false;
      this[_0xdaa5[440]]();
    }
  };
  Game[_0xdaa5[211]][_0xdaa5[577]] = function () {};
  return Game;
})();
var game;
function gameeUnmute() {
  if (game) {
    game[_0xdaa5[573]]();
  }
}
function gameeMute() {
  if (game) {
    game[_0xdaa5[572]]();
  }
}
function gameeResume() {
  if (game) {
    game[_0xdaa5[576]]();
  }
}
function gameePause() {
  if (game) {
    game[_0xdaa5[574]]();
  }
}
function gameeUnpause() {
  if (game) {
    game[_0xdaa5[576]]();
  }
}
function gameeStop() {}
function gameeRestart() {
  if (game) {
    game[_0xdaa5[577]]();
  }
}
function gameeInit() {
  console[_0xdaa5[439]](_0xdaa5[578]);
  gamee[_0xdaa5[580]](_0xdaa5[579], {}, [_0xdaa5[353]], function (
    _0xf5baxa4,
    _0xf5bax11
  ) {
    if (_0xf5baxa4 !== null) {
      throw _0xf5baxa4;
    }
    if (game) {
      game[_0xdaa5[0]](_0xf5bax11);
    }
  });
  gamee[_0xdaa5[433]][_0xdaa5[398]](_0xdaa5[574], function (_0xf5baxa5) {
    gameePause();
  });
  gamee[_0xdaa5[433]][_0xdaa5[398]](_0xdaa5[576], function (_0xf5baxa5) {
    gameeResume();
  });
  gamee[_0xdaa5[433]][_0xdaa5[398]](_0xdaa5[572], function (_0xf5baxa5) {
    gameeMute();
  });
  gamee[_0xdaa5[433]][_0xdaa5[398]](_0xdaa5[573], function (_0xf5baxa5) {
    gameeUnmute();
  });
}
window[_0xdaa5[581]] = function () {
  window[_0xdaa5[582]] = _0xdaa5[583] in window || navigator[_0xdaa5[584]];
  game = new Game();
};
var Tweener = (function () {
  var Tweener = {
    tweens: [],
    loop: true,
    params: { time: 1, transition: _0xdaa5[350], delay: 0 },
    fallbacks: { onStart: null, onUpdate: null, onComplete: null },
  };
  Tweener[_0xdaa5[585]] = function (_0xf5bax4e) {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < Tweener[_0xdaa5[586]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[587]] == _0xf5bax4e) {
        Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[585]]();
        break;
      }
    }
  };
  Tweener[_0xdaa5[574]] = function (_0xf5bax4e) {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < Tweener[_0xdaa5[586]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[587]] == _0xf5bax4e) {
        Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[574]]();
        break;
      }
    }
  };
  Tweener[_0xdaa5[577]] = function (_0xf5bax4e) {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < Tweener[_0xdaa5[586]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[587]] == _0xf5bax4e) {
        Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[577]]();
        break;
      }
    }
  };
  Tweener[_0xdaa5[233]] = function (_0xf5bax4e) {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < Tweener[_0xdaa5[586]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      if (Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[587]] === _0xf5bax4e) {
        Tweener[_0xdaa5[586]][_0xf5bax12][_0xdaa5[313]]();
        break;
      }
    }
  };
  Tweener[_0xdaa5[247]] = function (_0xf5bax4e, _0xf5baxa7, _0xf5baxa8) {
    var _0xf5baxa9 = Tweener;
    Tweener[_0xdaa5[233]](_0xf5bax4e);
    var _0xf5baxaa = new _0xf5baxa9.Tween(_0xf5bax4e, _0xf5baxa7, _0xf5baxa8);
    _0xf5baxa9[_0xdaa5[586]][_0xdaa5[476]](_0xf5baxaa);
    _0xf5baxaa[_0xdaa5[431]]();
  };
  Tweener[_0xdaa5[588]] = function (_0xf5bax4e, _0xf5baxa7, _0xf5baxa8) {};
  Tweener[_0xdaa5[589]] = function (_0xf5bax4e, _0xf5baxab, _0xf5baxa8) {
    this[_0xdaa5[587]] = _0xf5bax4e;
    this[_0xdaa5[590]] = [];
    this[_0xdaa5[591]] = {};
    this[_0xdaa5[592]] = {};
    this[_0xdaa5[593]] = {};
    this[_0xdaa5[565]] = false;
    this[_0xdaa5[594]] = 0;
    this[_0xdaa5[595]] = {
      time: 25,
      delay: 0,
      transition: _0xdaa5[350],
      onStart: null,
      onUpdate: null,
      onComplete: null,
      loop: false,
    };
    if (_0xf5baxa8) {
      for (var _0xf5baxac in this[_0xdaa5[595]]) {
        this[_0xdaa5[595]][_0xf5baxac] = _0xf5baxa8[_0xf5baxac]
          ? _0xf5baxa8[_0xf5baxac]
          : this[_0xdaa5[595]][_0xf5baxac];
      }
    }
    for (var _0xf5baxad in _0xf5baxab) {
      this[_0xdaa5[590]][_0xdaa5[476]](_0xf5baxad);
      this[_0xdaa5[592]][_0xf5baxad] = _0xf5bax4e[_0xf5baxad];
      this[_0xdaa5[591]][_0xf5baxad] =
        _0xf5baxab[_0xf5baxad] - _0xf5bax4e[_0xf5baxad];
      this[_0xdaa5[593]][_0xf5baxad] = _0xf5baxab[_0xf5baxad];
    }
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[431]] = function () {
    PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[292]](this[_0xdaa5[220]], this);
    this[_0xdaa5[565]] = true;
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[313]] = function () {
    this[_0xdaa5[565]] = false;
    PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[449]](this[_0xdaa5[220]], this);
    var _0xf5baxae = Tweener[_0xdaa5[586]];
    _0xf5baxae[_0xdaa5[568]](_0xf5baxae[_0xdaa5[550]](this), 1);
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[574]] = function () {
    if (!this[_0xdaa5[565]]) {
      return;
    }
    this[_0xdaa5[565]] = false;
    PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[449]](this[_0xdaa5[220]], this);
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[577]] = function () {
    if (!this[_0xdaa5[565]]) {
      PIXI[_0xdaa5[311]][_0xdaa5[310]][_0xdaa5[292]](this[_0xdaa5[220]], this);
      this[_0xdaa5[565]] = true;
    }
    this[_0xdaa5[596]] = 0;
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[585]] = function () {
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < this[_0xdaa5[590]][_0xdaa5[224]];
      _0xf5bax12++
    ) {
      var _0xf5baxaf = this[_0xdaa5[590]][_0xf5bax12];
      this[_0xdaa5[587]][_0xf5baxaf] =
        this[_0xdaa5[592]][_0xf5baxaf] + this[_0xdaa5[591]][_0xf5baxaf];
    }
    if (this[_0xdaa5[595]][_0xdaa5[597]]) {
      this[_0xdaa5[595]][_0xdaa5[597]](this._target);
    }
    this[_0xdaa5[313]]();
  };
  Tweener[_0xdaa5[589]][_0xdaa5[211]][_0xdaa5[220]] = function (_0xf5baxb0) {
    var _0xf5baxa9 = Tweener;
    var _0xf5baxb1 = _0xf5baxb0;
    var _0xf5baxa = this;
    if (this[_0xdaa5[595]][_0xdaa5[521]] > 0) {
      this[_0xdaa5[595]][_0xdaa5[521]] -= _0xf5baxb1;
    } else {
      var _0xf5baxb2 = false;
      var _0xf5baxb3 = this[_0xdaa5[595]][_0xdaa5[598]];
      this[_0xdaa5[594]] += _0xf5baxb1;
      if (this[_0xdaa5[594]] < 0) {
        this[_0xdaa5[594]] = 0;
      } else {
        if (
          this[_0xdaa5[594]] + _0xf5baxb1 / 2 >
          this[_0xdaa5[595]][_0xdaa5[598]]
        ) {
          this[_0xdaa5[594]] = this[_0xdaa5[595]][_0xdaa5[598]];
        }
      }
      var _0xf5bax4f = this[_0xdaa5[594]] / this[_0xdaa5[595]][_0xdaa5[598]];
      var _0xf5baxb4 = Tweener[_0xdaa5[541]][this[_0xdaa5[595]][_0xdaa5[599]]](
        _0xf5bax4f
      );
      for (
        var _0xf5bax12 = 0;
        _0xf5bax12 < this[_0xdaa5[590]][_0xdaa5[224]];
        _0xf5bax12++
      ) {
        var _0xf5baxaf = this[_0xdaa5[590]][_0xf5bax12];
        if (this[_0xdaa5[593]][_0xf5baxaf][_0xdaa5[600]] === Array) {
          var _0xf5baxb5 =
            (this[_0xdaa5[593]][_0xf5baxaf][_0xdaa5[224]] - 1) * _0xf5baxb4;
          var _0xf5baxb6 = Math[_0xdaa5[601]](_0xf5baxb5);
          var _0xf5baxb7 = 1 - (_0xf5baxb6 - _0xf5baxb5);
          var _0xf5baxb8 =
            _0xf5baxb6 > 0
              ? this[_0xdaa5[593]][_0xf5baxaf][_0xf5baxb6 - 1]
              : this[_0xdaa5[592]][_0xf5baxaf];
          var _0xf5baxb9 = this[_0xdaa5[593]][_0xf5baxaf][_0xf5baxb6];
          if (this[_0xdaa5[587]][_0xf5baxaf] != _0xf5baxb9) {
            dirty = true;
            this[_0xdaa5[587]][_0xf5baxaf] =
              _0xf5baxb8 + (_0xf5baxb9 - _0xf5baxb8) * _0xf5baxb7;
          }
        } else {
          this[_0xdaa5[587]][_0xf5baxaf] =
            this[_0xdaa5[592]][_0xf5baxaf] +
            (this[_0xdaa5[593]][_0xf5baxaf] - this[_0xdaa5[592]][_0xf5baxaf]) *
              _0xf5baxb4;
        }
      }
      if (this[_0xdaa5[595]][_0xdaa5[602]]) {
        this[_0xdaa5[595]][_0xdaa5[602]](this._target, _0xf5bax4f);
      }
      if (this[_0xdaa5[594]] >= _0xf5baxb3) {
        if (this[_0xdaa5[595]][_0xdaa5[603]]) {
          if (this[_0xdaa5[595]][_0xdaa5[603]] > 0) {
            this[_0xdaa5[595]][_0xdaa5[603]]--;
          }
          this[_0xdaa5[594]] = 0;
          if (this[_0xdaa5[595]][_0xdaa5[597]]) {
            this[_0xdaa5[595]][_0xdaa5[597]](this._target, this);
          }
        } else {
          this[_0xdaa5[313]]();
          if (this[_0xdaa5[595]][_0xdaa5[597]]) {
            this[_0xdaa5[595]][_0xdaa5[597]](this._target, this);
          }
        }
      }
    }
  };
  Tweener[_0xdaa5[541]] = {
    linear: function (_0xf5baxa) {
      return _0xf5baxa;
    },
    easeInElastic: function (_0xf5baxa, _0xf5baxba, _0xf5baxbb, _0xf5baxbc) {
      var _0xf5baxbd = 1.70158;
      var _0xf5baxad = 0;
      var _0xf5baxbe = _0xf5baxbb;
      if (_0xf5baxa == 0) {
        return _0xf5baxba;
      }
      if ((_0xf5baxa /= _0xf5baxbc) == 1) {
        return _0xf5baxba + _0xf5baxbb;
      }
      if (!_0xf5baxad) {
        _0xf5baxad = _0xf5baxbc * 0.3;
      }
      if (_0xf5baxbe < Math[_0xdaa5[238]](_0xf5baxbb)) {
        _0xf5baxbe = _0xf5baxbb;
        var _0xf5baxbd = _0xf5baxad / 4;
      } else {
        var _0xf5baxbd =
          (_0xf5baxad / (2 * Math[_0xdaa5[571]])) *
          Math[_0xdaa5[604]](_0xf5baxbb / _0xf5baxbe);
      }
      return (
        -(
          _0xf5baxbe *
          Math[_0xdaa5[605]](2, 10 * (_0xf5baxa -= 1)) *
          Math[_0xdaa5[606]](
            ((_0xf5baxa * _0xf5baxbc - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
              _0xf5baxad
          )
        ) + _0xf5baxba
      );
    },
    bow: function (_0xf5baxa) {
      return Math[_0xdaa5[606]](_0xf5baxa * Math[_0xdaa5[571]]);
    },
    bounc: function (_0xf5baxa) {
      return Math[_0xdaa5[606]](3 * _0xf5baxa * Math[_0xdaa5[571]]);
    },
    experimental: function (_0xf5baxa) {
      return Math[_0xdaa5[606]](_0xf5baxa * Math[_0xdaa5[571]]);
    },
    easeOutSine: function (_0xf5baxa) {
      return 1 * Math[_0xdaa5[606]]((_0xf5baxa / 1) * (Math[_0xdaa5[571]] / 2));
    },
    easeOutCubic: function (_0xf5baxa) {
      return 1 * ((_0xf5baxa = _0xf5baxa / 1 - 1) * _0xf5baxa * _0xf5baxa + 1);
    },
    easeOutBounce: function (_0xf5baxa) {
      if (_0xf5baxa < 1 / 2.75) {
        return 1 * (7.5625 * _0xf5baxa * _0xf5baxa);
      } else {
        if (_0xf5baxa < 2 / 2.75) {
          _0xf5baxa -= 1.5 / 2.75;
          return 1 * (7.5625 * _0xf5baxa * _0xf5baxa + 0.75);
        } else {
          if (_0xf5baxa < 2.5 / 2.75) {
            _0xf5baxa -= 2.25 / 2.75;
            return 1 * (7.5625 * _0xf5baxa * _0xf5baxa + 0.9375);
          } else {
            _0xf5baxa -= 1.5 / 2.75;
            if (7.5625 * _0xf5baxa * _0xf5baxa + 0.8575 > 1) {
              return 1;
            } else {
              return 7.5625 * _0xf5baxa * _0xf5baxa + 0.8575;
            }
          }
        }
      }
    },
    easeInOutBack: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (
          (1 / 2) *
          (_0xf5baxa *
            _0xf5baxa *
            (((_0xf5baxbd *= 1.525) + 1) * _0xf5baxa - _0xf5baxbd))
        );
      }
      return (
        (1 / 2) *
        ((_0xf5baxa -= 2) *
          _0xf5baxa *
          (((_0xf5baxbd *= 1.525) + 1) * _0xf5baxa + _0xf5baxbd) +
          2)
      );
    },
    easeInOutElastic: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      var _0xf5baxad = 0;
      var _0xf5baxbe = 1;
      if (_0xf5baxa === 0) {
        return 0;
      }
      if ((_0xf5baxa /= 1 / 2) == 2) {
        return 1;
      }
      if (!_0xf5baxad) {
        _0xf5baxad = 1 * (0.3 * 1.5);
      }
      if (_0xf5baxbe < Math[_0xdaa5[238]](1)) {
        _0xf5baxbe = 1;
        _0xf5baxbd = _0xf5baxad / 4;
      } else {
        _0xf5baxbd =
          (_0xf5baxad / (2 * Math[_0xdaa5[571]])) *
          Math[_0xdaa5[604]](1 / _0xf5baxbe);
      }
      if (_0xf5baxa < 1) {
        return (
          -0.5 *
          (_0xf5baxbe *
            Math[_0xdaa5[605]](2, 10 * (_0xf5baxa -= 1)) *
            Math[_0xdaa5[606]](
              ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
                _0xf5baxad
            ))
        );
      }
      return (
        _0xf5baxbe *
          Math[_0xdaa5[605]](2, -10 * (_0xf5baxa -= 1)) *
          Math[_0xdaa5[606]](
            ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
              _0xf5baxad
          ) *
          0.5 +
        1
      );
    },
    easeInQuad: function (_0xf5baxa) {
      return _0xf5baxa * _0xf5baxa;
    },
    easeOutQuad: function (_0xf5baxa) {
      return -1 * _0xf5baxa * (_0xf5baxa - 2);
    },
    easeInOutQuad: function (_0xf5baxa) {
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (1 / 2) * _0xf5baxa * _0xf5baxa;
      }
      return (-1 / 2) * (--_0xf5baxa * (_0xf5baxa - 2) - 1);
    },
    easeInCubic: function (_0xf5baxa) {
      return _0xf5baxa * _0xf5baxa * _0xf5baxa;
    },
    easeOutCubic: function (_0xf5baxa) {
      return 1 * ((_0xf5baxa = _0xf5baxa / 1 - 1) * _0xf5baxa * _0xf5baxa + 1);
    },
    easeInOutCubic: function (_0xf5baxa) {
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (1 / 2) * _0xf5baxa * _0xf5baxa * _0xf5baxa;
      }
      return (1 / 2) * ((_0xf5baxa -= 2) * _0xf5baxa * _0xf5baxa + 2);
    },
    easeInQuart: function (_0xf5baxa) {
      return _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa;
    },
    easeOutQuart: function (_0xf5baxa) {
      return (
        -1 *
        ((_0xf5baxa = _0xf5baxa / 1 - 1) * _0xf5baxa * _0xf5baxa * _0xf5baxa -
          1)
      );
    },
    easeInOutQuart: function (_0xf5baxa) {
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (1 / 2) * _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa;
      }
      return (
        (-1 / 2) * ((_0xf5baxa -= 2) * _0xf5baxa * _0xf5baxa * _0xf5baxa - 2)
      );
    },
    easeInQuint: function (_0xf5baxa) {
      return (
        1 * (_0xf5baxa /= 1) * _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa
      );
    },
    easeOutQuint: function (_0xf5baxa) {
      return (
        1 *
        ((_0xf5baxa = _0xf5baxa / 1 - 1) *
          _0xf5baxa *
          _0xf5baxa *
          _0xf5baxa *
          _0xf5baxa +
          1)
      );
    },
    easeInOutQuint: function (_0xf5baxa) {
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (
          (1 / 2) * _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa
        );
      }
      return (
        (1 / 2) *
        ((_0xf5baxa -= 2) * _0xf5baxa * _0xf5baxa * _0xf5baxa * _0xf5baxa + 2)
      );
    },
    easeInSine: function (_0xf5baxa) {
      return (
        -1 * Math[_0xdaa5[607]]((_0xf5baxa / 1) * (Math[_0xdaa5[571]] / 2)) + 1
      );
    },
    easeOutSine: function (_0xf5baxa) {
      return 1 * Math[_0xdaa5[606]]((_0xf5baxa / 1) * (Math[_0xdaa5[571]] / 2));
    },
    easeInOutSine: function (_0xf5baxa) {
      return (
        (-1 / 2) *
        (Math[_0xdaa5[607]]((Math[_0xdaa5[571]] * _0xf5baxa) / 1) - 1)
      );
    },
    easeInExpo: function (_0xf5baxa) {
      return _0xf5baxa === 0
        ? 1
        : 1 * Math[_0xdaa5[605]](2, 10 * (_0xf5baxa / 1 - 1));
    },
    easeOutExpo: function (_0xf5baxa) {
      return _0xf5baxa === 1
        ? 1
        : 1 * (-Math[_0xdaa5[605]](2, (-10 * _0xf5baxa) / 1) + 1);
    },
    easeInOutExpo: function (_0xf5baxa) {
      if (_0xf5baxa === 0) {
        return 0;
      }
      if (_0xf5baxa === 1) {
        return 1;
      }
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (1 / 2) * Math[_0xdaa5[605]](2, 10 * (_0xf5baxa - 1));
      }
      return (1 / 2) * (-Math[_0xdaa5[605]](2, -10 * --_0xf5baxa) + 2);
    },
    easeInCirc: function (_0xf5baxa) {
      if (_0xf5baxa >= 1) {
        return _0xf5baxa;
      }
      return -1 * (Math[_0xdaa5[570]](1 - (_0xf5baxa /= 1) * _0xf5baxa) - 1);
    },
    easeOutCirc: function (_0xf5baxa) {
      return (
        1 * Math[_0xdaa5[570]](1 - (_0xf5baxa = _0xf5baxa / 1 - 1) * _0xf5baxa)
      );
    },
    easeInOutCirc: function (_0xf5baxa) {
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (-1 / 2) * (Math[_0xdaa5[570]](1 - _0xf5baxa * _0xf5baxa) - 1);
      }
      return (
        (1 / 2) * (Math[_0xdaa5[570]](1 - (_0xf5baxa -= 2) * _0xf5baxa) + 1)
      );
    },
    easeInElastic: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      var _0xf5baxad = 0;
      var _0xf5baxbe = 1;
      if (_0xf5baxa === 0) {
        return 0;
      }
      if ((_0xf5baxa /= 1) == 1) {
        return 1;
      }
      if (!_0xf5baxad) {
        _0xf5baxad = 1 * 0.3;
      }
      if (_0xf5baxbe < Math[_0xdaa5[238]](1)) {
        _0xf5baxbe = 1;
        _0xf5baxbd = _0xf5baxad / 4;
      } else {
        _0xf5baxbd =
          (_0xf5baxad / (2 * Math[_0xdaa5[571]])) *
          Math[_0xdaa5[604]](1 / _0xf5baxbe);
      }
      return -(
        _0xf5baxbe *
        Math[_0xdaa5[605]](2, 10 * (_0xf5baxa -= 1)) *
        Math[_0xdaa5[606]](
          ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) / _0xf5baxad
        )
      );
    },
    easeOutElastic: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      var _0xf5baxad = 0;
      var _0xf5baxbe = 1;
      if (_0xf5baxa === 0) {
        return 0;
      }
      if ((_0xf5baxa /= 1) == 1) {
        return 1;
      }
      if (!_0xf5baxad) {
        _0xf5baxad = 1 * 0.3;
      }
      if (_0xf5baxbe < Math[_0xdaa5[238]](1)) {
        _0xf5baxbe = 1;
        _0xf5baxbd = _0xf5baxad / 4;
      } else {
        _0xf5baxbd =
          (_0xf5baxad / (2 * Math[_0xdaa5[571]])) *
          Math[_0xdaa5[604]](1 / _0xf5baxbe);
      }
      return (
        _0xf5baxbe *
          Math[_0xdaa5[605]](2, -10 * _0xf5baxa) *
          Math[_0xdaa5[606]](
            ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
              _0xf5baxad
          ) +
        1
      );
    },
    easeInOutElastic: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      var _0xf5baxad = 0;
      var _0xf5baxbe = 1;
      if (_0xf5baxa === 0) {
        return 0;
      }
      if ((_0xf5baxa /= 1 / 2) == 2) {
        return 1;
      }
      if (!_0xf5baxad) {
        _0xf5baxad = 1 * (0.3 * 1.5);
      }
      if (_0xf5baxbe < Math[_0xdaa5[238]](1)) {
        _0xf5baxbe = 1;
        _0xf5baxbd = _0xf5baxad / 4;
      } else {
        _0xf5baxbd =
          (_0xf5baxad / (2 * Math[_0xdaa5[571]])) *
          Math[_0xdaa5[604]](1 / _0xf5baxbe);
      }
      if (_0xf5baxa < 1) {
        return (
          -0.5 *
          (_0xf5baxbe *
            Math[_0xdaa5[605]](2, 10 * (_0xf5baxa -= 1)) *
            Math[_0xdaa5[606]](
              ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
                _0xf5baxad
            ))
        );
      }
      return (
        _0xf5baxbe *
          Math[_0xdaa5[605]](2, -10 * (_0xf5baxa -= 1)) *
          Math[_0xdaa5[606]](
            ((_0xf5baxa * 1 - _0xf5baxbd) * (2 * Math[_0xdaa5[571]])) /
              _0xf5baxad
          ) *
          0.5 +
        1
      );
    },
    easeInBack: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      return (
        1 *
        (_0xf5baxa /= 1) *
        _0xf5baxa *
        ((_0xf5baxbd + 1) * _0xf5baxa - _0xf5baxbd)
      );
    },
    easeOutBack: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      return (
        1 *
        ((_0xf5baxa / 1 - 1) *
          (_0xf5baxa / 1 - 1) *
          ((1.70158 + 1) * (_0xf5baxa / 1 - 1) + 1.70158) +
          1)
      );
    },
    easeInOutBack: function (_0xf5baxa) {
      var _0xf5baxbd = 1.70158;
      if ((_0xf5baxa /= 1 / 2) < 1) {
        return (
          (1 / 2) *
          (_0xf5baxa *
            _0xf5baxa *
            (((_0xf5baxbd *= 1.525) + 1) * _0xf5baxa - _0xf5baxbd))
        );
      }
      return (
        (1 / 2) *
        ((_0xf5baxa -= 2) *
          _0xf5baxa *
          (((_0xf5baxbd *= 1.525) + 1) * _0xf5baxa + _0xf5baxbd) +
          2)
      );
    },
    easeInBounce: function (_0xf5baxa) {
      return 1 - Tweener[_0xdaa5[541]][_0xdaa5[608]](1 - _0xf5baxa);
    },
    easeOutBounce: function (_0xf5baxa) {
      if (_0xf5baxa < 1 / 2.75) {
        return 1 * (7.5625 * _0xf5baxa * _0xf5baxa);
      } else {
        _0xf5baxa -= 1.5 / 2.75;
        if (7.5625 * _0xf5baxa * _0xf5baxa + 0.8575 > 1) {
          return 1;
        } else {
          return 7.5625 * _0xf5baxa * _0xf5baxa + 0.8575;
        }
      }
    },
    easeInOutBounce: function (_0xf5baxa) {
      if (_0xf5baxa < 1 / 2) {
        return easingEffects[_0xdaa5[609]](_0xf5baxa * 2) * 0.5;
      }
      return easingEffects[_0xdaa5[608]](_0xf5baxa * 2 - 1) * 0.5 + 1 * 0.5;
    },
  };
  return Tweener;
})();
function Animable(_0xf5bax3) {
  PIXI[_0xdaa5[195]][_0xdaa5[194]](this, _0xf5bax3);
  this[_0xdaa5[610]] = {};
  this[_0xdaa5[611]] = 0;
  this[_0xdaa5[594]] = 0;
  this[_0xdaa5[612]] = 10;
  this[_0xdaa5[613]] = null;
  this[_0xdaa5[614]] = [];
  this[_0xdaa5[219]] = false;
}
Animable[_0xdaa5[211]] = Object[_0xdaa5[212]](PIXI[_0xdaa5[195]][_0xdaa5[211]]);
Animable[_0xdaa5[211]][_0xdaa5[329]] = function (
  _0xf5bax37,
  _0xf5baxc0,
  _0xf5bax3b,
  _0xf5baxc1
) {
  if (_0xf5bax3b) {
    this[_0xdaa5[610]][_0xf5bax37] = [];
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5bax3b[_0xdaa5[224]];
      _0xf5bax12++
    ) {
      this[_0xdaa5[610]][_0xf5bax37][_0xdaa5[476]](
        _0xf5baxc0[_0xf5bax3b[_0xf5bax12]]
      );
    }
  } else {
    this[_0xdaa5[610]][_0xf5bax37] = _0xf5baxc0;
  }
  if (_0xf5baxc1) {
    var _0xf5baxc2 = [][_0xdaa5[551]](this[_0xdaa5[610]][_0xf5bax37]);
    _0xf5baxc2[_0xdaa5[615]]();
    this[_0xdaa5[610]][_0xf5bax37][_0xdaa5[616]]();
    this[_0xdaa5[610]][_0xf5bax37] = this[_0xdaa5[610]][_0xf5bax37][
      _0xdaa5[551]
    ](_0xf5baxc2);
  }
};
Animable[_0xdaa5[211]][_0xdaa5[488]] = function (
  _0xf5bax37,
  _0xf5baxc0,
  _0xf5baxc3
) {
  this[_0xdaa5[610]][_0xf5bax37] = [];
  for (
    var _0xf5bax12 = 0;
    _0xf5bax12 < _0xf5baxc3[_0xdaa5[224]];
    _0xf5bax12++
  ) {
    var _0xf5bax3b = [];
    for (
      var _0xf5baxc4 = 0;
      _0xf5baxc4 < _0xf5baxc3[_0xf5bax12][_0xdaa5[224]];
      _0xf5baxc4++
    ) {
      _0xf5bax3b[_0xdaa5[476]](_0xf5baxc0[_0xf5baxc3[_0xf5bax12][_0xf5baxc4]]);
    }
    this[_0xdaa5[610]][_0xf5bax37][_0xdaa5[476]](_0xf5bax3b);
  }
};
Animable[_0xdaa5[211]][_0xdaa5[332]] = function (
  _0xf5bax37,
  _0xf5baxc5,
  _0xf5baxc6
) {
  if (!this[_0xdaa5[610]][_0xf5bax37]) {
    return null;
  }
  this[_0xdaa5[617]] = _0xf5bax37;
  this[_0xdaa5[613]] = this[_0xdaa5[539]](this._animationName);
  this[_0xdaa5[594]] = 0;
  this[_0xdaa5[611]] = _0xf5baxc5 || 0;
  this[_0xdaa5[612]] = _0xf5baxc6 || this[_0xdaa5[612]];
  this[_0xdaa5[219]] = true;
};
Animable[_0xdaa5[211]][_0xdaa5[538]] = function () {
  this[_0xdaa5[219]] = false;
};
Animable[_0xdaa5[211]][_0xdaa5[539]] = function (_0xf5bax37) {
  if (this[_0xdaa5[610]][_0xf5bax37][0][_0xdaa5[600]] === Array) {
    var _0xf5bax79 = Math[_0xdaa5[235]](
      Math[_0xdaa5[482]]() * (this[_0xdaa5[610]][_0xf5bax37][_0xdaa5[224]] - 1)
    );
    return this[_0xdaa5[610]][_0xf5bax37][_0xf5bax79];
  } else {
    return this[_0xdaa5[610]][_0xf5bax37];
  }
};
Animable[_0xdaa5[211]][_0xdaa5[467]] = function (
  _0xf5bax37,
  _0xf5baxc5,
  _0xf5baxc6
) {
  this[_0xdaa5[614]][_0xdaa5[476]]({
    name: _0xf5bax37,
    loops: _0xf5baxc5,
    fps: _0xf5baxc6,
  });
};
Animable[_0xdaa5[211]][_0xdaa5[618]] = function () {
  this[_0xdaa5[614]] = [];
};
Animable[_0xdaa5[211]][_0xdaa5[619]] = function () {
  if (!this[_0xdaa5[614]][_0xdaa5[224]]) {
    return;
  }
  var _0xf5baxc7 = this[_0xdaa5[614]][_0xdaa5[616]]();
  this[_0xdaa5[332]](
    _0xf5baxc7[_0xdaa5[620]],
    _0xf5baxc7[_0xdaa5[621]],
    _0xf5baxc7[_0xdaa5[622]]
  );
};
Animable[_0xdaa5[211]][_0xdaa5[220]] = function (_0xf5baxa) {
  if (!this[_0xdaa5[219]] || !this[_0xdaa5[613]]) {
    return null;
  }
  this[_0xdaa5[594]] += _0xf5baxa > 0 ? _0xf5baxa : 0;
  var _0xf5baxc8 = this[_0xdaa5[613]];
  var _0xf5baxc9 = (_0xf5baxc8[_0xdaa5[224]] - 1) / (this[_0xdaa5[612]] / 60);
  if (this[_0xdaa5[594]] >= _0xf5baxc9) {
    if (this[_0xdaa5[611]]) {
      this[_0xdaa5[611]]--;
      this[_0xdaa5[594]] -= _0xf5baxc9;
      this[_0xdaa5[613]] = this[_0xdaa5[539]](this._animationName);
    } else {
      this[_0xdaa5[594]] = _0xf5baxc9;
      this[_0xdaa5[219]] = false;
      if (this[_0xdaa5[614]][_0xdaa5[224]]) {
        var _0xf5baxc7 = this[_0xdaa5[614]][_0xdaa5[616]]();
        this[_0xdaa5[332]](
          _0xf5baxc7[_0xdaa5[620]],
          _0xf5baxc7[_0xdaa5[621]],
          _0xf5baxc7[_0xdaa5[622]]
        );
      }
    }
  }
  var _0xf5baxca = Math[_0xdaa5[235]](
    (this[_0xdaa5[594]] * this[_0xdaa5[612]]) / 60
  );
  this[_0xdaa5[215]] = _0xf5baxc8[_0xf5baxca];
};
Animable[_0xdaa5[211]][_0xdaa5[623]] = function () {
  this[_0xdaa5[594]] = 0;
};
Object[_0xdaa5[625]](PIXI[_0xdaa5[315]][_0xdaa5[624]][_0xdaa5[211]], {
  scaleX: {
    get: function () {
      return this[_0xdaa5[250]][_0xdaa5[226]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[250]][_0xdaa5[226]] = _0xf5bax4;
    },
  },
  scaleY: {
    get: function () {
      return this[_0xdaa5[250]][_0xdaa5[228]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[250]][_0xdaa5[228]] = _0xf5bax4;
    },
  },
});
Object[_0xdaa5[625]](PIXI[_0xdaa5[195]][_0xdaa5[211]], {
  scaleX: {
    get: function () {
      return this[_0xdaa5[250]][_0xdaa5[226]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[250]][_0xdaa5[226]] = _0xf5bax4;
    },
  },
  scaleY: {
    get: function () {
      return this[_0xdaa5[250]][_0xdaa5[228]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[250]][_0xdaa5[228]] = _0xf5bax4;
    },
  },
  anchorX: {
    get: function () {
      return this[_0xdaa5[227]][_0xdaa5[226]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[227]][_0xdaa5[226]] = _0xf5bax4;
    },
  },
  anchorY: {
    get: function () {
      return this[_0xdaa5[227]][_0xdaa5[228]];
    },
    set: function (_0xf5bax4) {
      this[_0xdaa5[227]][_0xdaa5[228]] = _0xf5bax4;
    },
  },
});
PIXI[_0xdaa5[627]][_0xdaa5[211]][_0xdaa5[626]] = function (
  _0xf5baxcb,
  _0xf5baxcc
) {
  var _0xf5baxcd = false;
  var _0xf5baxce = this[_0xdaa5[628]][_0xdaa5[224]] / 2;
  for (
    var _0xf5bax12 = 0, _0xf5baxc4 = _0xf5baxce - 1;
    _0xf5bax12 < _0xf5baxce;
    _0xf5baxc4 = _0xf5bax12++
  ) {
    var _0xf5baxcf = this[_0xdaa5[628]][_0xf5bax12 * 2],
      _0xf5baxd0 = this[_0xdaa5[628]][_0xf5bax12 * 2 + 1],
      _0xf5baxd1 = this[_0xdaa5[628]][_0xf5baxc4 * 2],
      _0xf5baxd2 = this[_0xdaa5[628]][_0xf5baxc4 * 2 + 1],
      _0xf5baxd3 =
        _0xf5baxd0 >= _0xf5baxcc !== _0xf5baxd2 >= _0xf5baxcc &&
        _0xf5baxcb <
          ((_0xf5baxd1 - _0xf5baxcf) * (_0xf5baxcc - _0xf5baxd0)) /
            (_0xf5baxd2 - _0xf5baxd0) +
            _0xf5baxcf;
    if (_0xf5baxd3) {
      _0xf5baxcd = !_0xf5baxcd;
    }
  }
  return _0xf5baxcd;
};
PIXI[_0xdaa5[629]] = function (_0xf5baxd4) {
  var _0xf5bax38 = PIXI[_0xdaa5[293]][_0xdaa5[462]][_0xf5baxd4[_0xdaa5[630]]];
  if (_0xf5bax38) {
    var _0xf5baxd5 = [];
    _0xf5bax38[_0xdaa5[631]] = {};
    var _0xf5baxd6 = 0;
    var _0xf5baxd7 = 0;
    for (
      var _0xf5bax12 = 0;
      _0xf5bax12 < _0xf5baxd4[_0xdaa5[632]];
      _0xf5bax12++
    ) {
      var _0xf5bax37 = _0xf5baxd4[_0xdaa5[630]] + _0xdaa5[633] + _0xf5bax12;
      var _0xf5baxd8 = new PIXI.Rectangle(
        _0xf5baxd6,
        _0xf5baxd7,
        _0xf5baxd4[_0xdaa5[634]],
        _0xf5baxd4[_0xdaa5[635]]
      );
      _0xf5bax38[_0xdaa5[631]][_0xf5bax37] = new PIXI.Texture(
        _0xf5bax38[_0xdaa5[215]][_0xdaa5[636]],
        _0xf5baxd8,
        _0xf5baxd8[_0xdaa5[637]]()
      );
      PIXI[_0xdaa5[301]][_0xdaa5[638]][_0xf5bax37] =
        _0xf5bax38[_0xdaa5[631]][_0xf5bax37];
      _0xf5baxd5[_0xdaa5[476]](_0xf5bax38[_0xdaa5[631]][_0xf5bax37]);
      _0xf5baxd6 += _0xf5baxd4[_0xdaa5[634]];
      if (
        _0xf5baxd6 + _0xf5baxd4[_0xdaa5[634]] >
        _0xf5bax38[_0xdaa5[215]][_0xdaa5[407]]
      ) {
        _0xf5baxd6 = 0;
        _0xf5baxd7 += _0xf5baxd4[_0xdaa5[635]];
        if (
          _0xf5baxd7 + _0xf5baxd4[_0xdaa5[635]] >
          _0xf5bax38[_0xdaa5[215]][_0xdaa5[408]]
        ) {
          break;
        }
      }
    }
    return _0xf5baxd5;
  }
  return false;
};
