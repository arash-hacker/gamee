var _0xbbc5 = [
  "\x5F\x5F\x65\x78\x74\x65\x6E\x64\x73",
  "\x68\x61\x73\x4F\x77\x6E\x50\x72\x6F\x70\x65\x72\x74\x79",
  "\x63\x6F\x6E\x73\x74\x72\x75\x63\x74\x6F\x72",
  "\x70\x72\x6F\x74\x6F\x74\x79\x70\x65",
  "\x63\x61\x6C\x6C",
  "\x78",
  "\x61\x6E\x63\x68\x6F\x72",
  "\x79",
  "\x5F\x6C\x65\x76\x65\x6C",
  "\x5F\x73\x70\x65\x65\x64",
  "\x5F\x74\x79\x70\x65",
  "\x6E\x75\x6C\x6C",
  "\x5F\x62\x65\x74\x61",
  "\x5F\x62\x61\x73\x65",
  "\x5F\x67\x61\x69\x6E",
  "\x74\x79\x70\x65",
  "\x64\x65\x66\x69\x6E\x65\x50\x72\x6F\x70\x65\x72\x74\x79",
  "\x6C\x65\x76\x65\x6C",
  "\x73\x70\x65\x65\x64",
  "\x62\x61\x73\x65",
  "\x62\x65\x74\x61",
  "\x67\x61\x69\x6E",
  "\x65\x78\x74\x72\x61\x73",
  "\x5F\x73\x63\x61\x6C\x65",
  "\x5F\x65\x6C\x61\x70\x73\x65\x64",
  "\x5F\x64\x75\x72\x61\x74\x69\x6F\x6E",
  "\x5F\x74\x77\x65\x65\x6E\x69\x6E\x67",
  "\x5F\x64\x69\x72\x65\x63\x74\x69\x6F\x6E",
  "\x5F\x73\x74\x61\x72\x74\x53\x63\x61\x6C\x65",
  "\x5F\x65\x6E\x64\x53\x63\x61\x6C\x65",
  "\x74\x61\x72\x67\x65\x74",
  "\x72\x65\x73\x65\x74\x50\x72\x6F\x70\x73",
  "\x67\x6F\x74\x6F\x41\x6E\x64\x53\x74\x6F\x70",
  "\x73\x74\x6F\x70\x54\x77\x65\x65\x6E",
  "\x73\x69\x7A\x65",
  "\x73\x63\x61\x6C\x65\x55\x70",
  "\x73\x63\x61\x6C\x65\x54\x6F",
  "\x73\x74\x61\x72\x74\x54\x77\x65\x65\x6E",
  "\x74\x77\x65\x65\x6E\x55\x70\x64\x61\x74\x65",
  "\x61\x64\x64",
  "\x73\x68\x61\x72\x65\x64",
  "\x74\x69\x63\x6B\x65\x72",
  "\x72\x65\x6D\x6F\x76\x65",
  "\x73\x63\x61\x6C\x65",
  "\x64\x69\x72\x65\x63\x74\x69\x6F\x6E",
  "\x70\x6F\x77",
  "\x73\x69\x6E",
  "\x63\x6F\x6C\x69\x73\x69\x6F\x6E\x73",
  "\x63\x61\x6E\x76\x61\x73",
  "\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74",
  "\x70\x6F\x73\x69\x74\x69\x6F\x6E",
  "\x73\x74\x79\x6C\x65",
  "\x61\x62\x73\x6F\x6C\x75\x74\x65",
  "\x6C\x65\x66\x74",
  "\x32\x30\x30\x70\x78",
  "\x32\x64",
  "\x67\x65\x74\x43\x6F\x6E\x74\x65\x78\x74",
  "\x73\x61\x76\x65",
  "\x67\x65\x74\x42\x6F\x75\x6E\x64\x73",
  "\x63\x68\x65\x63\x6B\x52\x65\x63\x74\x43\x6F\x6C\x6C\x69\x73\x69\x6F\x6E",
  "\x77\x69\x64\x74\x68",
  "\x68\x65\x69\x67\x68\x74",
  "\x78\x32",
  "\x79\x32",
  "\x63\x68\x65\x63\x6B\x50\x69\x78\x65\x6C\x43\x6F\x6C\x6C\x69\x73\x69\x6F\x6E",
  "\x73\x6F\x75\x72\x63\x65",
  "\x62\x61\x73\x65\x54\x65\x78\x74\x75\x72\x65",
  "\x74\x65\x78\x74\x75\x72\x65",
  "\x72\x65\x73\x74\x6F\x72\x65",
  "\x74\x72\x61\x6E\x73\x6C\x61\x74\x65",
  "\x64\x72\x61\x77\x49\x6D\x61\x67\x65",
  "\x64\x61\x74\x61",
  "\x67\x65\x74\x49\x6D\x61\x67\x65\x44\x61\x74\x61",
  "\x6C\x65\x6E\x67\x74\x68",
  "\x2B",
  "\x70\x61\x72\x65\x6E\x74",
  "\x2A",
  "\x63\x78",
  "\x68\x77",
  "\x63\x79",
  "\x68\x68",
  "\x61\x62\x73",
  "\x6D\x69\x6E",
  "\x6D\x61\x78",
  "\x63\x65\x69\x6C",
  "\x63\x61\x6C\x63\x75\x6C\x61\x74\x65\x49\x6E\x74\x65\x72\x73\x65\x63\x74\x69\x6F\x6E",
  "\x69\x6E\x69\x74",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x67\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x31\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x32\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x33\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x34\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x34\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x35\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x35\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x37\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x37\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x38\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x38\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x39\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x39\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x31\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x32\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x33\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x34\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x35\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x72\x79\x62\x61\x37\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x65\x64\x75\x7A\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6D\x69\x6E\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x72\x6B\x5F\x30\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x72\x6B\x5F\x30\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x72\x6B\x5F\x30\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x72\x6B\x5F\x30\x34\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x68\x61\x72\x6B\x5F\x30\x35\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x69\x74\x41\x72\x65\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x68\x69\x74\x41\x72\x65\x61\x42\x6F\x64\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x62\x75\x62\x6C\x69\x6E\x6B\x61\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x70\x6F\x6E\x6F\x72\x6B\x61\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x69\x6C\x75\x65\x74\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x64\x2F\x62\x67\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x64\x2F\x77\x61\x74\x63\x68\x5F\x62\x75\x74\x74\x6F\x6E\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x64\x2F\x77\x61\x74\x63\x68\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x63\x6C\x69\x63\x6B\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x64\x2F\x6E\x6F\x70\x65\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x61\x64\x2F\x74\x61\x70\x5F\x74\x6F\x5F\x70\x6C\x61\x79\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x31\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x31\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x31\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x32\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x32\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x33\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x33\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x33\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x34\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x34\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x34\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x35\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x35\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x35\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x36\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x36\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x36\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x37\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x37\x73\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x37\x73\x32\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x39\x2E\x70\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x6F\x75\x74\x6C\x69\x6E\x65\x73\x2F\x39\x73\x2E\x70\x6E\x67",
  "\x72\x79\x62\x61\x31\x73\x32",
  "\x6F\x5F\x31\x73\x32",
  "\x72\x79\x62\x61\x31\x73",
  "\x6F\x5F\x31\x73",
  "\x72\x79\x62\x61\x32\x73\x32",
  "\x6F\x5F\x32\x73\x32",
  "\x72\x79\x62\x61\x31",
  "\x6F\x5F\x31",
  "\x72\x79\x62\x61\x32\x73",
  "\x6F\x5F\x32\x73",
  "\x72\x79\x62\x61\x33\x73\x32",
  "\x6F\x5F\x33\x73\x32",
  "\x72\x79\x62\x61\x32",
  "\x6F\x5F\x32",
  "\x72\x79\x62\x61\x33\x73",
  "\x6F\x5F\x33\x73",
  "\x72\x79\x62\x61\x33",
  "\x6F\x5F\x33",
  "\x72\x79\x62\x61\x34\x73\x32",
  "\x6F\x5F\x34\x73\x32",
  "\x72\x79\x62\x61\x34\x73",
  "\x6F\x5F\x34\x73",
  "\x72\x79\x62\x61\x35\x73\x32",
  "\x6F\x5F\x35\x73\x32",
  "\x72\x79\x62\x61\x37\x73\x32",
  "\x6F\x5F\x37\x73\x32",
  "\x72\x79\x62\x61\x34",
  "\x6F\x5F\x34",
  "\x72\x79\x62\x61\x35\x73",
  "\x6F\x5F\x35\x73",
  "\x72\x79\x62\x61\x38\x73",
  "\x72\x79\x62\x61\x39\x73",
  "\x6F\x5F\x39\x73",
  "\x72\x79\x62\x61\x35",
  "\x6F\x5F\x35",
  "\x72\x79\x62\x61\x37\x73",
  "\x6F\x5F\x37\x73",
  "\x72\x79\x62\x61\x39",
  "\x6F\x5F\x39",
  "\x72\x79\x62\x61\x37",
  "\x6F\x5F\x37",
  "\x72\x79\x62\x61\x38",
  "\x70\x61\x75\x73\x65",
  "\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72",
  "\x65\x6D\x69\x74\x74\x65\x72",
  "\x72\x65\x73\x75\x6D\x65",
  "\x6D\x75\x74\x65",
  "\x75\x6E\x6D\x75\x74\x65",
  "\x46\x75\x6C\x6C\x53\x63\x72\x65\x65\x6E",
  "\x73\x61\x76\x65\x53\x74\x61\x74\x65",
  "\x72\x65\x77\x61\x72\x64\x65\x64\x41\x64\x73",
  "\x6C\x6F\x67\x45\x76\x65\x6E\x74\x73",
  "\x73\x6F\x75\x6E\x64",
  "\x70\x61\x72\x73\x65",
  "\x67\x61\x6D\x65\x49\x6E\x69\x74",
  "\x73\x74\x61\x72\x74",
  "\x67\x61\x6D\x65\x52\x65\x61\x64\x79",
  "\x69\x6E\x69\x74\x56\x61\x72\x69\x61\x62\x6C\x65\x73",
  "\x75\x70\x64\x61\x74\x65\x53\x63\x6F\x72\x65",
  "\x61\x64\x20\x6C\x6F\x61\x64\x69\x6E\x67",
  "\x6C\x6F\x67",
  "\x6C\x6F\x61\x64\x52\x65\x77\x61\x72\x64\x65\x64\x56\x69\x64\x65\x6F",
  "\x61\x64\x20\x6E\x6F\x74\x20\x73\x75\x70\x70\x6F\x72\x74\x65\x64",
  "\x76\x69\x64\x65\x6F\x4C\x6F\x61\x64\x65\x64",
  "\x61\x64\x20\x6C\x6F\x61\x64\x69\x6E\x67\x20\x66\x61\x69\x6C\x65\x64\x3A\x20",
  "\x76\x69\x64\x65\x6F\x50\x6C\x61\x79\x65\x64",
  "\x61\x64\x20\x70\x6C\x61\x79\x20\x66\x61\x69\x6C\x65\x64\x3A\x20",
  "\x73\x68\x6F\x77\x52\x65\x77\x61\x72\x64\x65\x64\x56\x69\x64\x65\x6F",
  "\x65\x6E\x64\x47\x61\x6D\x65",
  "\x61\x64\x5F\x62\x67",
  "\x72\x65\x73\x6F\x75\x72\x63\x65\x73",
  "\x6C\x6F\x61\x64\x65\x72",
  "\x61\x64\x64\x43\x68\x69\x6C\x64",
  "\x5F\x73\x74\x61\x67\x65",
  "\x61\x64\x5F\x62\x74\x6E\x5F\x75\x70",
  "\x69\x6E\x74\x65\x72\x61\x63\x74\x69\x76\x65",
  "\x62\x75\x74\x74\x6F\x6E\x4D\x6F\x64\x65",
  "\x6D\x6F\x75\x73\x65\x64\x6F\x77\x6E",
  "\x72\x65\x6D\x6F\x76\x65\x43\x68\x69\x6C\x64",
  "\x63\x6F\x6E\x74\x69\x6E\x75\x65\x4C\x65\x76\x65\x6C",
  "\x67\x61\x6D\x65\x5F\x6F\x76\x65\x72",
  "\x6F\x6E\x63\x65",
  "\x74\x6F\x75\x63\x68\x73\x74\x61\x72\x74",
  "\x61\x64\x5F\x6E\x6F",
  "\x6F\x6E",
  "\x75\x70\x64\x61\x74\x65",
  "\x5F\x73\x74\x61\x74\x75\x73",
  "\x69\x6E\x73\x74\x61\x6E\x63\x65\x20\x63\x72\x65\x61\x74\x65\x64",
  "\x5F\x70\x61\x75\x73\x65",
  "\x5F\x72\x75\x6E\x6E\x69\x6E\x67",
  "\x5F\x74",
  "\x5F\x72\x65\x6E\x64\x65\x72\x65\x72",
  "\x5F\x70\x61\x72\x61\x6C\x61\x78\x31",
  "\x5F\x70\x61\x72\x61\x6C\x61\x78\x32",
  "\x5F\x74\x6F\x75\x63\x68\x4F\x66\x66\x65\x74\x58",
  "\x5F\x74\x6F\x75\x63\x68\x4F\x66\x66\x65\x74\x59",
  "\x5F\x62\x6F\x64\x79\x48\x69\x74\x41\x72\x65\x61",
  "\x5F\x70\x6C\x61\x79\x65\x72\x48\x69\x74\x41\x72\x65\x61",
  "\x5F\x70\x6C\x61\x79\x65\x72",
  "\x5F\x6D\x61\x72\x69\x6E\x65",
  "\x5F\x70\x6F\x6F\x6C",
  "\x5F\x62\x75\x62\x62\x6C\x65\x73",
  "\x5F\x73\x68\x61\x64\x6F\x77\x73",
  "\x5F\x6D\x69\x6E\x65\x73",
  "\x5F\x61\x6C\x69\x76\x65",
  "\x5F\x73\x63\x6F\x72\x65",
  "\x5F\x66\x6F\x6F\x64\x50\x72\x6F\x62",
  "\x5F\x6D\x69\x6E\x65\x50\x72\x6F\x62",
  "\x5F\x70\x72\x6F\x62\x52\x65\x67\x75\x6C\x61\x74\x69\x6F\x6E",
  "\x65\x61\x74\x53\x6F\x75\x6E\x64",
  "\x6D\x6F\x76\x65\x53\x6F\x75\x6E\x64",
  "\x64\x65\x61\x74\x68\x53\x6F\x75\x6E\x64",
  "\x62\x67\x53\x6F\x75\x6E\x64",
  "\x6D\x69\x6E\x65\x73\x44\x69\x73\x74\x61\x6E\x63\x65",
  "\x5F\x73\x61\x6D\x65\x50\x6F\x73\x65",
  "\x5F\x67\x65\x6E\x65\x72\x61\x74\x65\x54\x69\x6D\x65",
  "\x74\x6F\x75\x63\x68\x43\x6F\x6E\x74\x72\x6F\x6C\x6C",
  "\x67\x61\x6D\x65\x57\x69\x64\x74\x68",
  "\x67\x61\x6D\x65\x48\x65\x69\x67\x68\x74",
  "\x6C\x6F\x61\x64\x41\x73\x73\x65\x74\x73",
  "\x70\x72\x65\x6C\x6F\x61\x64\x69\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x65\x61\x74\x2E\x6D\x70\x33",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x65\x61\x74\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x6D\x6F\x76\x65\x2E\x6D\x70\x33",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x6D\x6F\x76\x65\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x64\x65\x61\x74\x68\x2E\x6D\x70\x33",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x64\x65\x61\x74\x68\x2E\x6F\x67\x67",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x73\x65\x65\x2E\x6D\x70\x33",
  "\x61\x73\x73\x65\x74\x73\x2F\x73\x6F\x75\x6E\x64\x73\x2F\x73\x65\x65\x2E\x6F\x67\x67",
  "\x6C\x6F\x6F\x70",
  "\x62\x69\x74\x6D\x61\x70\x73",
  "\x62\x69\x6E\x64",
  "\x61\x73\x73\x65\x74\x73\x4C\x6F\x61\x64\x43\x6F\x6D\x70\x6C\x65\x74\x65",
  "\x6C\x6F\x61\x64",
  "\x63\x72\x65\x61\x74\x65\x53\x63\x65\x6E\x65",
  "\x67\x65\x6E\x65\x72\x61\x74\x69\x6E\x67\x20\x73\x63\x65\x6E\x65",
  "\x72\x65\x73\x69\x7A\x65",
  "\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72",
  "\x61\x75\x74\x6F\x44\x65\x74\x65\x63\x74\x52\x65\x6E\x64\x65\x72\x65\x72",
  "\x76\x69\x65\x77",
  "\x31\x30\x30\x25",
  "\x61\x70\x70\x65\x6E\x64\x43\x68\x69\x6C\x64",
  "\x67\x6D\x34\x68\x74\x6D\x6C\x35\x5F\x64\x69\x76\x5F\x69\x64",
  "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64",
  "\x62\x67\x31",
  "\x62\x67\x32",
  "\x62\x67\x33",
  "\x73\x68\x61\x72\x6B\x5F",
  "\x70\x75\x73\x68",
  "\x73\x68\x61\x72\x6B\x5F\x31",
  "\x68\x69\x74\x41\x72\x65\x61",
  "\x61\x6C\x70\x68\x61",
  "\x6D\x61\x72\x69\x6E\x65",
  "\x61\x64\x64\x43\x68\x69\x6C\x64\x41\x74",
  "\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x53\x70\x65\x65\x64",
  "\x68\x69\x74\x41\x72\x65\x61\x42\x6F\x64\x79",
  "\x74\x61\x70\x74\x6F\x73\x74\x61\x72\x74",
  "\x76\x69\x73\x69\x62\x6C\x65",
  "\x73\x65\x74",
  "\x61\x75\x74\x6F\x53\x74\x61\x72\x74",
  "\x73\x74\x6F\x70",
  "\x62\x69\x6E\x64\x45\x76\x65\x6E\x74\x73",
  "\x69\x6E\x6E\x65\x72\x57\x69\x64\x74\x68",
  "\x69\x6E\x6E\x65\x72\x48\x65\x69\x67\x68\x74",
  "\x70\x78",
  "\x74\x6F\x75\x63\x68\x6D\x6F\x76\x65",
  "\x74\x6F\x75\x63\x68\x4D\x6F\x76\x65\x48\x61\x6E\x64\x6C\x65\x72",
  "\x6D\x6F\x75\x73\x65\x6D\x6F\x76\x65",
  "\x6D\x6F\x75\x73\x65\x4D\x6F\x76\x65\x48\x61\x6E\x64\x6C\x65\x72",
  "\x67\x6C\x6F\x62\x61\x6C",
  "\x75\x70\x64\x61\x74\x65\x54\x61\x72\x67\x65\x74",
  "\x74\x6F\x75\x63\x68\x53\x74\x61\x72\x74",
  "\x70\x6C\x61\x79",
  "\x68\x61\x6E\x64\x6C\x65\x54\x6F\x75\x63\x68",
  "\x73\x74\x61\x72\x74\x47\x61\x6D\x65",
  "\x69\x6E\x69\x74\x20\x76\x61\x72\x69\x61\x62\x6C\x65\x73",
  "\x5F\x6D\x6F\x76\x65\x53\x70\x65\x65\x64",
  "\x75\x70\x64\x61\x74\x65\x44\x69\x66\x66\x69\x63\x75\x6C\x74\x79",
  "\x63\x6C\x65\x61\x72\x50\x6F\x6F\x6C",
  "\x72\x61\x6E\x64\x6F\x6D",
  "\x73\x65\x65\x6B",
  "\x72\x65\x6E\x64\x65\x72",
  "\x67\x61\x6D\x65\x20\x73\x74\x61\x72\x74\x65\x64",
  "\x67\x61\x6D\x65\x20\x73\x74\x61\x72\x74",
  "\x72\x75\x6E\x47\x61\x6D\x65",
  "\x73\x74\x6F\x70\x47\x61\x6D\x65",
  "\x67\x61\x6D\x65\x4F\x76\x65\x72",
  "\x70\x6C\x61\x79\x65\x72\x4D\x6F\x76\x65",
  "\x73\x71\x72\x74",
  "\x61\x74\x61\x6E\x32",
  "\x63\x6F\x73",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x42\x75\x62\x62\x6C\x65",
  "\x75\x70\x64\x61\x74\x65\x42\x75\x62\x62\x6C\x65\x73",
  "\x73\x6C\x69\x63\x65",
  "\x69\x6E\x64\x65\x78\x4F\x66",
  "\x73\x70\x6C\x69\x63\x65",
  "\x75\x70\x64\x61\x74\x65\x4D\x61\x72\x69\x6E\x65",
  "\x75\x70\x64\x61\x74\x65\x53\x68\x61\x64\x6F\x77\x73",
  "\x75\x70\x64\x61\x74\x65\x50\x61\x72\x61\x6C\x61\x78",
  "\x76\x65\x72\x74\x69\x63\x61\x6C",
  "\x72\x65\x6D\x6F\x76\x65\x46\x72\x6F\x6D\x50\x6F\x6F\x6C",
  "\x6F\x75\x74\x6C\x69\x6E\x65",
  "\x67\x6F\x74\x6F\x41\x6E\x64\x50\x6C\x61\x79",
  "\x70\x6F\x69\x6E\x74\x73",
  "\x67\x65\x6E\x65\x72\x61\x74\x65",
  "\x72\x6F\x75\x6E\x64",
  "\x62\x75\x62\x62\x6C\x65",
  "\x66\x6C\x6F\x6F\x72",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x53\x69\x6C\x75\x65\x74\x65",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x4D\x69\x6E\x65",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x4D\x65\x64\x75\x73\x65",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x53\x6D\x61\x6C\x6C\x65\x72",
  "\x67\x65\x6E\x65\x72\x61\x74\x65\x4C\x61\x72\x67\x65\x72",
  "\x73\x69\x6C\x75\x65\x74\x65",
  "\x67\x65\x74\x49\x6E\x64\x65\x78\x42\x79\x4C\x65\x76\x65\x6C",
  "\x66\x69\x73\x68\x65\x73",
  "\x67\x65\x74\x52\x61\x6E\x64\x6F\x6D\x46\x72\x6F\x6D",
  "\x62\x69\x74\x6D\x61\x70",
  "\x6E\x6F\x72\x6D\x61\x6C",
  "\x6D\x65\x64\x75\x7A\x61",
  "\x73\x68\x69\x66\x74",
  "\x65\x72\x72\x6F\x72\x5F\x20\x70\x6F\x6F\x6C\x20\x63\x6C\x65\x61\x72\x69\x6E\x67",
  "\x61\x73\x73\x65\x74\x73\x20\x6C\x6F\x61\x64\x65\x64",
  "\x72\x65\x73\x74\x61\x72\x74",
  "\x6F\x6E\x6C\x6F\x61\x64",
];
var __extends =
  this[_0xbbc5[0]] ||
  function (_0xfbe7x2, _0xfbe7x3) {
    for (var _0xfbe7x4 in _0xfbe7x3) {
      if (_0xfbe7x3[_0xbbc5[1]](_0xfbe7x4)) {
        _0xfbe7x2[_0xfbe7x4] = _0xfbe7x3[_0xfbe7x4];
      }
    }
    function _0xfbe7x5() {
      this[_0xbbc5[2]] = _0xfbe7x2;
    }
    _0xfbe7x5[_0xbbc5[3]] = _0xfbe7x3[_0xbbc5[3]];
    _0xfbe7x2[_0xbbc5[3]] = new _0xfbe7x5();
  };
var Fish = (function (_0xfbe7x7) {
  __extends(Fish, _0xfbe7x7);
  function Fish(_0xfbe7x8) {
    _0xfbe7x7[_0xbbc5[4]](this, _0xfbe7x8);
    this[_0xbbc5[6]][_0xbbc5[5]] = 0.5;
    this[_0xbbc5[6]][_0xbbc5[7]] = 0.5;
    this[_0xbbc5[8]] = 0;
    this[_0xbbc5[9]] = null;
    this[_0xbbc5[10]] = _0xbbc5[11];
    this[_0xbbc5[12]] = 0;
    this[_0xbbc5[13]] = 0;
    this[_0xbbc5[14]] = 0;
  }
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[15], {
    get: function () {
      return this[_0xbbc5[10]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[10]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[17], {
    get: function () {
      return this[_0xbbc5[8]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[8]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[18], {
    get: function () {
      return this[_0xbbc5[9]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[9]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[19], {
    get: function () {
      return this[_0xbbc5[13]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[13]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[20], {
    get: function () {
      return this[_0xbbc5[12]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[12]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Fish[_0xbbc5[3]], _0xbbc5[21], {
    get: function () {
      return this[_0xbbc5[14]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[14]] = _0xfbe7x9;
    },
  });
  return Fish;
})(PIXI.Sprite);
var Shark = (function (_0xfbe7x7) {
  __extends(Shark, _0xfbe7x7);
  function Shark(_0xfbe7xb) {
    _0xfbe7x7[_0xbbc5[4]](this, _0xfbe7xb);
    this[_0xbbc5[6]][_0xbbc5[5]] = 0.5;
    this[_0xbbc5[6]][_0xbbc5[7]] = 0.5;
    this[_0xbbc5[23]] = 1;
    this[_0xbbc5[24]] = 0;
    this[_0xbbc5[25]] = 100;
    this[_0xbbc5[26]] = false;
    this[_0xbbc5[27]] = 1;
    this[_0xbbc5[28]] = 1;
    this[_0xbbc5[29]] = 1;
    this[_0xbbc5[30]] = { x: 0, y: 0 };
    this[_0xbbc5[8]] = 0.2;
  }
  Shark[_0xbbc5[3]][_0xbbc5[31]] = function () {
    this[_0xbbc5[32]](1);
    if (this[_0xbbc5[26]]) {
      this[_0xbbc5[33]]();
    }
    this[_0xbbc5[34]] = 0.2;
    this[_0xbbc5[17]] = 0.2;
  };
  Shark[_0xbbc5[3]][_0xbbc5[35]] = function () {
    if (this[_0xbbc5[26]]) {
      this[_0xbbc5[34]] = this[_0xbbc5[28]] + this[_0xbbc5[29]];
    }
    if (this[_0xbbc5[8]] < 1) {
      this[_0xbbc5[36]](this._level);
    }
  };
  Shark[_0xbbc5[3]][_0xbbc5[36]] = function (_0xfbe7x9) {
    this[_0xbbc5[24]] = 0;
    this[_0xbbc5[28]] = this[_0xbbc5[34]];
    this[_0xbbc5[29]] = _0xfbe7x9 - this[_0xbbc5[34]];
    if (!this[_0xbbc5[26]]) {
      this[_0xbbc5[37]]();
    }
  };
  Shark[_0xbbc5[3]][_0xbbc5[37]] = function () {
    this[_0xbbc5[26]] = true;
    PIXI[_0xbbc5[41]][_0xbbc5[40]][_0xbbc5[39]](this[_0xbbc5[38]], this);
  };
  Shark[_0xbbc5[3]][_0xbbc5[33]] = function () {
    this[_0xbbc5[26]] = false;
    PIXI[_0xbbc5[41]][_0xbbc5[40]][_0xbbc5[42]](this[_0xbbc5[38]], this);
  };
  Shark[_0xbbc5[3]][_0xbbc5[38]] = function (_0xfbe7xc) {
    this[_0xbbc5[24]] += 1;
    var _0xfbe7xd = this[_0xbbc5[24]] / this[_0xbbc5[25]];
    if (_0xfbe7xd >= 1) {
      _0xfbe7xd = 1;
      this[_0xbbc5[24]] = 0;
      this[_0xbbc5[33]]();
    }
    var _0xfbe7xe =
      this[_0xbbc5[28]] + Transition(_0xfbe7xd) * this[_0xbbc5[29]];
    this[_0xbbc5[34]] = _0xfbe7xe;
  };
  Object[_0xbbc5[16]](Shark[_0xbbc5[3]], _0xbbc5[34], {
    get: function () {
      return this[_0xbbc5[23]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[23]] = this[_0xbbc5[43]][_0xbbc5[7]] = _0xfbe7x9;
      this[_0xbbc5[43]][_0xbbc5[5]] = this[_0xbbc5[23]] * this[_0xbbc5[27]];
    },
  });
  Object[_0xbbc5[16]](Shark[_0xbbc5[3]], _0xbbc5[17], {
    get: function () {
      return this[_0xbbc5[8]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[8]] = _0xfbe7x9;
    },
  });
  Object[_0xbbc5[16]](Shark[_0xbbc5[3]], _0xbbc5[44], {
    get: function () {
      return this[_0xbbc5[27]];
    },
    set: function (_0xfbe7x9) {
      this[_0xbbc5[27]] = _0xfbe7x9;
      this[_0xbbc5[43]][_0xbbc5[5]] = this[_0xbbc5[23]] * this[_0xbbc5[27]];
    },
  });
  Transition = function (_0xfbe7xd) {
    if (_0xfbe7xd <= 0) {
      return 0;
    }
    if (_0xfbe7xd >= 0.4) {
      return 1.0;
    }
    return (
      Math[_0xbbc5[45]](2.0, -5.568 * _0xfbe7xd) *
        Math[_0xbbc5[46]](11.6616 * _0xfbe7xd - 1.571) *
        0.955 +
      0.955
    );
  };
  return Shark;
})(PIXI[_0xbbc5[22]].MovieClip);
this[_0xbbc5[47]] = this[_0xbbc5[47]] || {};
(function () {
  var _0xfbe7xf = document[_0xbbc5[49]](_0xbbc5[48]);
  _0xfbe7xf[_0xbbc5[51]][_0xbbc5[50]] = _0xbbc5[52];
  _0xfbe7xf[_0xbbc5[51]][_0xbbc5[53]] = _0xbbc5[54];
  var _0xfbe7x10 = _0xfbe7xf[_0xbbc5[56]](_0xbbc5[55]);
  _0xfbe7x10[_0xbbc5[57]]();
  var _0xfbe7x11 = document[_0xbbc5[49]](_0xbbc5[48]);
  _0xfbe7x11[_0xbbc5[51]][_0xbbc5[50]] = _0xbbc5[52];
  var _0xfbe7x12 = _0xfbe7x11[_0xbbc5[56]](_0xbbc5[55]);
  _0xfbe7x12[_0xbbc5[57]]();
  var _0xfbe7x13 = [];
  var _0xfbe7x14 = function (_0xfbe7x15, _0xfbe7x16) {
    var _0xfbe7x17, _0xfbe7x18;
    _0xfbe7x17 = _0xfbe7x15[_0xbbc5[58]]();
    _0xfbe7x18 = _0xfbe7x16[_0xbbc5[58]]();
    return _0xfbe7x37(_0xfbe7x17, _0xfbe7x18);
  };
  colisions[_0xbbc5[59]] = _0xfbe7x14;
  var _0xfbe7x19 = function (_0xfbe7x15, _0xfbe7x16) {
    var _0xfbe7x1a, _0xfbe7x1b, _0xfbe7x1c, _0xfbe7x1d, _0xfbe7x1e;
    intersection = _0xfbe7x14(_0xfbe7x15, _0xfbe7x16);
    if (!intersection) {
      return false;
    }
    _0xfbe7xf[_0xbbc5[60]] = intersection[_0xbbc5[60]];
    _0xfbe7xf[_0xbbc5[61]] = intersection[_0xbbc5[61]];
    _0xfbe7x11[_0xbbc5[60]] = intersection[_0xbbc5[60]];
    _0xfbe7x11[_0xbbc5[61]] = intersection[_0xbbc5[61]];
    _0xfbe7x10 = _0xfbe7xf[_0xbbc5[56]](_0xbbc5[55]);
    _0xfbe7x12 = _0xfbe7x11[_0xbbc5[56]](_0xbbc5[55]);
    _0xfbe7x1c = _0xfbe7x1f(intersection, _0xfbe7x15, _0xfbe7x10, 1);
    _0xfbe7x1d = _0xfbe7x1f(intersection, _0xfbe7x16, _0xfbe7x12, 2);
    if (!_0xfbe7x1c || !_0xfbe7x1d) {
      return false;
    }
    _0xfbe7x1e = _0xfbe7x27(
      _0xfbe7x1c,
      _0xfbe7x1d,
      intersection[_0xbbc5[60]],
      intersection[_0xbbc5[61]],
      0
    );
    if (_0xfbe7x1e) {
      _0xfbe7x1e[_0xbbc5[5]] += intersection[_0xbbc5[5]];
      _0xfbe7x1e[_0xbbc5[62]] += intersection[_0xbbc5[5]];
      _0xfbe7x1e[_0xbbc5[7]] += intersection[_0xbbc5[7]];
      _0xfbe7x1e[_0xbbc5[63]] += intersection[_0xbbc5[7]];
    } else {
      return false;
    }
    return _0xfbe7x1e;
  };
  colisions[_0xbbc5[64]] = _0xfbe7x19;
  var _0xfbe7x1f = function (_0xfbe7x1b, _0xfbe7x20, _0xfbe7x21, _0xfbe7x22) {
    if (
      !_0xfbe7x21[_0xbbc5[48]][_0xbbc5[60]] ||
      !_0xfbe7x21[_0xbbc5[48]][_0xbbc5[61]]
    ) {
      return null;
    }
    var _0xfbe7x23, _0xfbe7x24, _0xfbe7x25, _0xfbe7x26;
    _0xfbe7x24 = _0xfbe7x20[_0xbbc5[67]][_0xbbc5[66]][_0xbbc5[65]];
    _0xfbe7x23 = { x: _0xfbe7x1b[_0xbbc5[5]], y: _0xfbe7x1b[_0xbbc5[7]] };
    _0xfbe7x21[_0xbbc5[68]]();
    _0xfbe7x21[_0xbbc5[57]]();
    _0xfbe7x21[_0xbbc5[43]](
      _0xfbe7x20[_0xbbc5[43]][_0xbbc5[5]],
      _0xfbe7x20[_0xbbc5[43]][_0xbbc5[7]]
    );
    _0xfbe7x21[_0xbbc5[69]](
      (_0xfbe7x20[_0xbbc5[5]] -
        _0xfbe7x1b[_0xbbc5[5]] -
        _0xfbe7x20[_0xbbc5[60]] / 2) /
        _0xfbe7x20[_0xbbc5[43]][_0xbbc5[5]],
      (_0xfbe7x20[_0xbbc5[7]] -
        _0xfbe7x1b[_0xbbc5[7]] -
        _0xfbe7x20[_0xbbc5[61]] / 2) /
        _0xfbe7x20[_0xbbc5[43]][_0xbbc5[7]]
    );
    _0xfbe7x21[_0xbbc5[70]](
      _0xfbe7x24,
      0,
      0,
      _0xfbe7x24[_0xbbc5[60]],
      _0xfbe7x24[_0xbbc5[61]]
    );
    return _0xfbe7x21[_0xbbc5[72]](
      0,
      0,
      _0xfbe7x1b[_0xbbc5[60]],
      _0xfbe7x1b[_0xbbc5[61]]
    )[_0xbbc5[71]];
  };
  var _0xfbe7x27 = function (
    _0xfbe7x1c,
    _0xfbe7x1d,
    _0xfbe7x28,
    _0xfbe7x29,
    _0xfbe7x2a
  ) {
    var _0xfbe7x2b,
      _0xfbe7x2c,
      _0xfbe7x2d,
      _0xfbe7x2e,
      _0xfbe7x2f = 3,
      _0xfbe7x30 = { x: Infinity, y: Infinity, x2: -Infinity, y2: -Infinity };
    for (_0xfbe7x2e = 0; _0xfbe7x2e < _0xfbe7x29; ++_0xfbe7x2e) {
      for (_0xfbe7x2d = 0; _0xfbe7x2d < _0xfbe7x28; ++_0xfbe7x2d) {
        _0xfbe7x2b =
          _0xfbe7x1c[_0xbbc5[73]] > _0xfbe7x2f + 1
            ? _0xfbe7x1c[_0xfbe7x2f] / 255
            : 0;
        _0xfbe7x2c =
          _0xfbe7x1d[_0xbbc5[73]] > _0xfbe7x2f + 1
            ? _0xfbe7x1d[_0xfbe7x2f] / 255
            : 0;
        if (_0xfbe7x2b > _0xfbe7x2a && _0xfbe7x2c > _0xfbe7x2a) {
          return { x: _0xfbe7x2d, y: _0xfbe7x2e, width: 1, height: 1 };
        }
        _0xfbe7x2f += 4;
      }
    }
    if (_0xfbe7x30[_0xbbc5[5]] != Infinity) {
      _0xfbe7x30[_0xbbc5[60]] =
        _0xfbe7x30[_0xbbc5[62]] - _0xfbe7x30[_0xbbc5[5]] + 1;
      _0xfbe7x30[_0xbbc5[61]] =
        _0xfbe7x30[_0xbbc5[63]] - _0xfbe7x30[_0xbbc5[7]] + 1;
      return _0xfbe7x30;
    }
    return null;
  };
  var _0xfbe7x31 = function (_0xfbe7x32, _0xfbe7x33, _0xfbe7x34) {
    _0xfbe7x34 = _0xfbe7x34 || _0xbbc5[74];
    if (_0xfbe7x32[_0xbbc5[75]] && _0xfbe7x32[_0xbbc5[75]][_0xfbe7x33]) {
      var _0xfbe7x35 = _0xfbe7x32[_0xfbe7x33];
      var _0xfbe7x36 = _0xfbe7x31(
        _0xfbe7x32[_0xbbc5[75]],
        _0xfbe7x33,
        _0xfbe7x34
      );
      if (_0xfbe7x34 == _0xbbc5[76]) {
        return _0xfbe7x35 * _0xfbe7x36;
      } else {
        return _0xfbe7x35 + _0xfbe7x36;
      }
    }
    return _0xfbe7x32[_0xfbe7x33];
  };
  var _0xfbe7x37 = function (_0xfbe7x38, _0xfbe7x39) {
    var _0xfbe7x3a,
      _0xfbe7x3b,
      _0xfbe7x3c = {},
      _0xfbe7x3d = {};
    _0xfbe7x3c[_0xbbc5[77]] =
      _0xfbe7x38[_0xbbc5[5]] +
      (_0xfbe7x3c[_0xbbc5[78]] = _0xfbe7x38[_0xbbc5[60]] / 2);
    _0xfbe7x3c[_0xbbc5[79]] =
      _0xfbe7x38[_0xbbc5[7]] +
      (_0xfbe7x3c[_0xbbc5[80]] = _0xfbe7x38[_0xbbc5[61]] / 2);
    _0xfbe7x3d[_0xbbc5[77]] =
      _0xfbe7x39[_0xbbc5[5]] +
      (_0xfbe7x3d[_0xbbc5[78]] = _0xfbe7x39[_0xbbc5[60]] / 2);
    _0xfbe7x3d[_0xbbc5[79]] =
      _0xfbe7x39[_0xbbc5[7]] +
      (_0xfbe7x3d[_0xbbc5[80]] = _0xfbe7x39[_0xbbc5[61]] / 2);
    _0xfbe7x3a =
      Math[_0xbbc5[81]](_0xfbe7x3c[_0xbbc5[77]] - _0xfbe7x3d[_0xbbc5[77]]) -
      (_0xfbe7x3c[_0xbbc5[78]] + _0xfbe7x3d[_0xbbc5[78]]);
    _0xfbe7x3b =
      Math[_0xbbc5[81]](_0xfbe7x3c[_0xbbc5[79]] - _0xfbe7x3d[_0xbbc5[79]]) -
      (_0xfbe7x3c[_0xbbc5[80]] + _0xfbe7x3d[_0xbbc5[80]]);
    if (_0xfbe7x3a < 0 && _0xfbe7x3b < 0) {
      _0xfbe7x3a = Math[_0xbbc5[82]](
        Math[_0xbbc5[82]](_0xfbe7x38[_0xbbc5[60]], _0xfbe7x39[_0xbbc5[60]]),
        -_0xfbe7x3a
      );
      _0xfbe7x3b = Math[_0xbbc5[82]](
        Math[_0xbbc5[82]](_0xfbe7x38[_0xbbc5[61]], _0xfbe7x39[_0xbbc5[61]]),
        -_0xfbe7x3b
      );
      return {
        x: Math[_0xbbc5[83]](_0xfbe7x38[_0xbbc5[5]], _0xfbe7x39[_0xbbc5[5]]),
        y: Math[_0xbbc5[83]](_0xfbe7x38[_0xbbc5[7]], _0xfbe7x39[_0xbbc5[7]]),
        width: Math[_0xbbc5[84]](_0xfbe7x3a),
        height: Math[_0xbbc5[84]](_0xfbe7x3b),
        rect1: _0xfbe7x38,
        rect2: _0xfbe7x39,
      };
    } else {
      return null;
    }
  };
  colisions[_0xbbc5[85]] = _0xfbe7x37;
})();
window[_0xbbc5[86]] = {
  bitmaps: {
    bg1: _0xbbc5[87],
    bg2: _0xbbc5[88],
    bg3: _0xbbc5[89],
    ryba1s: _0xbbc5[90],
    ryba1: _0xbbc5[91],
    ryba2s: _0xbbc5[92],
    ryba2: _0xbbc5[93],
    ryba3s: _0xbbc5[94],
    ryba3: _0xbbc5[95],
    ryba4s: _0xbbc5[96],
    ryba4: _0xbbc5[97],
    ryba5s: _0xbbc5[98],
    ryba5: _0xbbc5[99],
    ryba7s: _0xbbc5[100],
    ryba7: _0xbbc5[101],
    ryba8s: _0xbbc5[102],
    ryba8: _0xbbc5[103],
    ryba9s: _0xbbc5[104],
    ryba9: _0xbbc5[105],
    ryba1s2: _0xbbc5[106],
    ryba2s2: _0xbbc5[107],
    ryba3s2: _0xbbc5[108],
    ryba4s2: _0xbbc5[109],
    ryba5s2: _0xbbc5[110],
    ryba7s2: _0xbbc5[111],
    meduza: _0xbbc5[112],
    mine: _0xbbc5[113],
    shark_1: _0xbbc5[114],
    shark_2: _0xbbc5[115],
    shark_3: _0xbbc5[116],
    shark_4: _0xbbc5[117],
    shark_5: _0xbbc5[118],
    hitArea: _0xbbc5[119],
    hitAreaBody: _0xbbc5[120],
    bubble: _0xbbc5[121],
    marine: _0xbbc5[122],
    siluete: _0xbbc5[123],
    ad_bg: _0xbbc5[124],
    ad_btn_up: _0xbbc5[125],
    ad_btn_down: _0xbbc5[126],
    ad_no: _0xbbc5[127],
    taptostart: _0xbbc5[128],
    o_1: _0xbbc5[129],
    o_1s: _0xbbc5[130],
    o_1s2: _0xbbc5[131],
    o_2: _0xbbc5[132],
    o_2s: _0xbbc5[133],
    o_2s2: _0xbbc5[134],
    o_3: _0xbbc5[135],
    o_3s: _0xbbc5[136],
    o_3s2: _0xbbc5[137],
    o_4: _0xbbc5[138],
    o_4s: _0xbbc5[139],
    o_4s2: _0xbbc5[140],
    o_5: _0xbbc5[141],
    o_5s: _0xbbc5[142],
    o_5s2: _0xbbc5[143],
    o_6: _0xbbc5[144],
    o_6s: _0xbbc5[145],
    o_6s2: _0xbbc5[146],
    o_7: _0xbbc5[147],
    o_7s: _0xbbc5[148],
    o_7s2: _0xbbc5[149],
    o_9: _0xbbc5[150],
    o_9s: _0xbbc5[151],
  },
  fishes: [
    { bitmap: _0xbbc5[152], level: 0.1, outline: _0xbbc5[153] },
    { bitmap: _0xbbc5[154], level: 0.12, outline: _0xbbc5[155] },
    { bitmap: _0xbbc5[156], level: 0.14, outline: _0xbbc5[157] },
    { bitmap: _0xbbc5[158], level: 0.15, outline: _0xbbc5[159] },
    { bitmap: _0xbbc5[160], level: 0.16, outline: _0xbbc5[161] },
    { bitmap: _0xbbc5[162], level: 0.18, outline: _0xbbc5[163] },
    { bitmap: _0xbbc5[164], level: 0.21, outline: _0xbbc5[165] },
    { bitmap: _0xbbc5[166], level: 0.22, outline: _0xbbc5[167] },
    { bitmap: _0xbbc5[168], level: 0.3, outline: _0xbbc5[169] },
    { bitmap: _0xbbc5[170], level: 0.32, outline: _0xbbc5[171] },
    { bitmap: _0xbbc5[172], level: 0.37, outline: _0xbbc5[173] },
    { bitmap: _0xbbc5[174], level: 0.42, outline: _0xbbc5[175] },
    { bitmap: _0xbbc5[176], level: 0.47, outline: _0xbbc5[177] },
    { bitmap: _0xbbc5[178], level: 0.5, outline: _0xbbc5[179] },
    { bitmap: _0xbbc5[180], level: 0.53, outline: _0xbbc5[181] },
    { bitmap: _0xbbc5[182], level: 9999, outline: null },
    { bitmap: _0xbbc5[183], level: 0.54, outline: _0xbbc5[184] },
    { bitmap: _0xbbc5[185], level: 0.6, outline: _0xbbc5[186] },
    { bitmap: _0xbbc5[187], level: 0.61, outline: _0xbbc5[188] },
    { bitmap: _0xbbc5[189], level: 0.68, outline: _0xbbc5[190] },
    { bitmap: _0xbbc5[191], level: 1.05, outline: _0xbbc5[192] },
    { bitmap: _0xbbc5[193], level: 9999, outline: null },
  ],
};
var Game = (function () {
  var _0xfbe7x3f = 640;
  var _0xfbe7x40 = 1137;
  var _0xfbe7x41 = {};
  var _0xfbe7x42 = false;
  var _0xfbe7x43 = null;
  var _0xfbe7x44 = false;
  var _0xfbe7x45 = null;
  var _0xfbe7x46 = null;
  var _0xfbe7x47 = true;
  var _0xfbe7x48 = { x: 0, y: 0 };
  function _0xfbe7x49() {
    gamee[_0xbbc5[196]][_0xbbc5[195]](_0xbbc5[194], function (_0xfbe7x4a) {
      _0xfbe7x53();
    });
    gamee[_0xbbc5[196]][_0xbbc5[195]](_0xbbc5[197], function (_0xfbe7x4a) {
      _0xfbe7x52();
    });
    gamee[_0xbbc5[196]][_0xbbc5[195]](_0xbbc5[198], function (_0xfbe7x4a) {
      _0xfbe7x51();
    });
    gamee[_0xbbc5[196]][_0xbbc5[195]](_0xbbc5[199], function (_0xfbe7x4a) {
      _0xfbe7x50();
    });
    gamee[_0xbbc5[206]](
      _0xbbc5[200],
      {},
      [_0xbbc5[201], _0xbbc5[202], _0xbbc5[203]],
      function (_0xfbe7x4b, _0xfbe7x4c) {
        if (_0xfbe7x4b !== null) {
          throw _0xfbe7x4b;
        }
        if (!_0xfbe7x4c[_0xbbc5[204]]) {
          _0xfbe7x51();
        }
        var _0xfbe7x4d = _0xfbe7x4c[_0xbbc5[201]]
          ? JSON[_0xbbc5[205]](_0xfbe7x4c[_0xbbc5[201]])
          : {};
        _0xfbe7x4e(_0xfbe7x4d);
      }
    );
  }
  function _0xfbe7x4e(_0xfbe7x4c) {
    for (var _0xfbe7x4f in _0xfbe7x4c) {
      _0xfbe7x41[_0xfbe7x4f] = _0xfbe7x4c[_0xfbe7x4f];
    }
    gamee[_0xbbc5[196]][_0xbbc5[195]](_0xbbc5[207], function () {
      _0xfbe7x54();
    });
    gamee[_0xbbc5[208]]();
  }
  function _0xfbe7x50() {
    if (_0xfbe7x42) {
      _0xfbe7x42 = false;
      Howler[_0xbbc5[198]](false);
    }
  }
  function _0xfbe7x51() {
    if (!_0xfbe7x42) {
      _0xfbe7x42 = true;
      Howler[_0xbbc5[198]](true);
    }
  }
  function _0xfbe7x52() {
    game[_0xbbc5[197]]();
  }
  function _0xfbe7x53() {
    game[_0xbbc5[194]]();
  }
  function _0xfbe7x54() {
    game[_0xbbc5[209]]();
  }
  function _0xfbe7x55() {}
  function _0xfbe7x56() {}
  function _0xfbe7x57(_0xfbe7x9) {
    gamee[_0xbbc5[210]](_0xfbe7x9);
  }
  function _0xfbe7x58(_0xfbe7x59) {
    console[_0xbbc5[212]](_0xbbc5[211]);
    _0xfbe7x44 = true;
    _0xfbe7x45 = false;
    if (!gamee[_0xbbc5[213]]) {
      console[_0xbbc5[212]](_0xbbc5[214]);
      return 0;
    }
    gamee[_0xbbc5[213]](function (_0xfbe7x4b, _0xfbe7x4c) {
      _0xfbe7x45 = _0xfbe7x4c && _0xfbe7x4c[_0xbbc5[215]];
      if (_0xfbe7x59) {
        _0xfbe7x59(_0xfbe7x4c && _0xfbe7x4c[_0xbbc5[215]]);
      }
      if (!_0xfbe7x45) {
        console[_0xbbc5[212]](_0xbbc5[216], _0xfbe7x4b);
        setTimeout(function () {
          _0xfbe7x58(function () {
            updateAbilities();
          });
        }, 60000);
      } else {
        _0xfbe7x44 = false;
      }
    });
  }
  function _0xfbe7x5a(_0xfbe7x59, _0xfbe7x5b) {
    if (!_0xfbe7x45) {
      return false;
    }
    _0xfbe7x45 = false;
    gamee[_0xbbc5[219]](function (_0xfbe7x4b, _0xfbe7x4c) {
      let _0xfbe7x5c = _0xfbe7x4c && _0xfbe7x4c[_0xbbc5[217]];
      if (_0xfbe7x59) {
        _0xfbe7x59(_0xfbe7x5c);
      }
      if (_0xfbe7x5c) {
      } else {
        console[_0xbbc5[212]](_0xbbc5[218], _0xfbe7x4b);
      }
    });
  }
  function _0xfbe7x5d() {
    if (_0xfbe7x43 && _0xfbe7x45) {
      _0xfbe7x5e();
    } else {
      game[_0xbbc5[220]]();
    }
  }
  function _0xfbe7x5e() {
    var _0xfbe7x5f = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[221]][_0xbbc5[67]]
    );
    _0xfbe7x5f[_0xbbc5[6]][_0xbbc5[5]] = 0.5;
    _0xfbe7x5f[_0xbbc5[5]] = _0xfbe7x3f / 2;
    _0xfbe7x5f[_0xbbc5[7]] = _0xfbe7x40 / 4;
    game[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x5f);
    var _0xfbe7x60 = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[226]][_0xbbc5[67]]
    );
    _0xfbe7x60[_0xbbc5[5]] = 115 - _0xfbe7x5f[_0xbbc5[60]] / 2;
    _0xfbe7x60[_0xbbc5[7]] = 216;
    _0xfbe7x60[_0xbbc5[227]] = true;
    _0xfbe7x60[_0xbbc5[228]] = true;
    _0xfbe7x5f[_0xbbc5[224]](_0xfbe7x60);
    _0xfbe7x60[_0xbbc5[233]](_0xbbc5[229], function () {
      this[_0xbbc5[227]] = false;
      game[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x5f);
      _0xfbe7x5a(function (_0xfbe7x61) {
        if (_0xfbe7x61) {
          _0xfbe7x43 = false;
          game[_0xbbc5[231]]();
        } else {
          game[_0xbbc5[220]]();
        }
      }, _0xbbc5[232]);
    });
    _0xfbe7x60[_0xbbc5[233]](_0xbbc5[234], function () {
      this[_0xbbc5[227]] = false;
      game[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x5f);
      _0xfbe7x5a(function (_0xfbe7x61) {
        if (_0xfbe7x61) {
          _0xfbe7x43 = false;
          game[_0xbbc5[231]]();
        } else {
          game[_0xbbc5[220]]();
        }
      }, _0xbbc5[232]);
    });
    var _0xfbe7x62 = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[235]][_0xbbc5[67]]
    );
    _0xfbe7x62[_0xbbc5[5]] = 212 - _0xfbe7x5f[_0xbbc5[60]] / 2;
    _0xfbe7x62[_0xbbc5[7]] = 353;
    _0xfbe7x62[_0xbbc5[227]] = true;
    _0xfbe7x62[_0xbbc5[228]] = true;
    _0xfbe7x5f[_0xbbc5[224]](_0xfbe7x62);
    _0xfbe7x62[_0xbbc5[236]](_0xbbc5[229], function () {
      this[_0xbbc5[227]] = false;
      game[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x5f);
      game[_0xbbc5[220]]();
    });
    _0xfbe7x62[_0xbbc5[236]](_0xbbc5[234], function (_0xfbe7x63) {
      this[_0xbbc5[227]] = false;
      game[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x5f);
      game[_0xbbc5[220]]();
    });
  }
  var _0xfbe7x64 = 0;
  function _0xfbe7x65(_0xfbe7x66) {
    _0xfbe7x64 += _0xfbe7x66;
    while (_0xfbe7x64 > 1) {
      _0xfbe7x64--;
      game[_0xbbc5[237]](1);
    }
  }
  function _0xfbe7x67() {
    this[_0xbbc5[238]] = _0xbbc5[239];
    this[_0xbbc5[240]] = false;
    this[_0xbbc5[241]] = false;
    this[_0xbbc5[242]] = null;
    this[_0xbbc5[225]] = null;
    this[_0xbbc5[243]] = null;
    this[_0xbbc5[244]] = null;
    this[_0xbbc5[245]] = null;
    this[_0xbbc5[246]] = null;
    this[_0xbbc5[247]] = null;
    this[_0xbbc5[248]] = null;
    this[_0xbbc5[249]] = null;
    this[_0xbbc5[250]] = null;
    this[_0xbbc5[251]] = null;
    this[_0xbbc5[252]] = null;
    this[_0xbbc5[253]] = null;
    this[_0xbbc5[254]] = null;
    this[_0xbbc5[255]] = null;
    this[_0xbbc5[256]] = null;
    this[_0xbbc5[257]] = 0;
    this[_0xbbc5[258]] = null;
    this[_0xbbc5[259]] = null;
    this[_0xbbc5[260]] = 0;
    this[_0xbbc5[261]] = null;
    this[_0xbbc5[262]] = null;
    this[_0xbbc5[263]] = null;
    this[_0xbbc5[264]] = null;
    this[_0xbbc5[265]] = null;
    this[_0xbbc5[266]] = null;
    this[_0xbbc5[267]] = null;
    this[_0xbbc5[268]] = false;
    this[_0xbbc5[269]] = _0xfbe7x3f;
    this[_0xbbc5[270]] = _0xfbe7x40;
    this[_0xbbc5[271]]();
  }
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[271]] = function () {
    this[_0xbbc5[238]] = _0xbbc5[272];
    this[_0xbbc5[261]] = new Howl({ src: [_0xbbc5[273], _0xbbc5[274]] });
    this[_0xbbc5[262]] = new Howl({ src: [_0xbbc5[275], _0xbbc5[276]] });
    this[_0xbbc5[263]] = new Howl({ src: [_0xbbc5[277], _0xbbc5[278]] });
    this[_0xbbc5[264]] = new Howl({ src: [_0xbbc5[279], _0xbbc5[280]] });
    this[_0xbbc5[264]][_0xbbc5[281]](true);
    for (var _0xfbe7x4f in init[_0xbbc5[282]]) {
      PIXI[_0xbbc5[223]][_0xbbc5[39]](
        _0xfbe7x4f,
        init[_0xbbc5[282]][_0xfbe7x4f]
      );
    }
    PIXI[_0xbbc5[223]][_0xbbc5[285]](this[_0xbbc5[284]][_0xbbc5[283]](this));
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[286]] = function () {
    this[_0xbbc5[238]] = _0xbbc5[287];
    this[_0xbbc5[288]]();
    this[_0xbbc5[225]] = new PIXI[_0xbbc5[289]]();
    this[_0xbbc5[243]] = PIXI[_0xbbc5[290]](_0xfbe7x3f, _0xfbe7x40, {
      roundPixels: false,
      resolution: 1,
      antialias: false,
      transparent: true,
    });
    this[_0xbbc5[243]][_0xbbc5[291]][_0xbbc5[51]][_0xbbc5[60]] = _0xbbc5[292];
    this[_0xbbc5[243]][_0xbbc5[291]][_0xbbc5[51]][_0xbbc5[61]] = _0xbbc5[292];
    document[_0xbbc5[295]](_0xbbc5[294])[_0xbbc5[293]](
      this[_0xbbc5[243]][_0xbbc5[291]]
    );
    var _0xfbe7x68 = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[296]][_0xbbc5[67]]
    );
    _0xfbe7x68[_0xbbc5[60]] = _0xfbe7x3f;
    _0xfbe7x68[_0xbbc5[61]] = _0xfbe7x40;
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x68);
    this[_0xbbc5[244]] = new PIXI[_0xbbc5[22]].TilingSprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[297]][_0xbbc5[67]],
      _0xfbe7x3f,
      640
    );
    this[_0xbbc5[244]][_0xbbc5[6]][_0xbbc5[7]] = 1;
    this[_0xbbc5[244]][_0xbbc5[7]] = _0xfbe7x40;
    this[_0xbbc5[225]][_0xbbc5[224]](this._paralax1);
    this[_0xbbc5[245]] = new PIXI[_0xbbc5[22]].TilingSprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[298]][_0xbbc5[67]],
      _0xfbe7x3f,
      640
    );
    this[_0xbbc5[245]][_0xbbc5[6]][_0xbbc5[7]] = 1;
    this[_0xbbc5[245]][_0xbbc5[7]] = _0xfbe7x40;
    this[_0xbbc5[225]][_0xbbc5[224]](this._paralax2);
    var _0xfbe7x69 = [];
    for (var _0xfbe7x22 = 1; _0xfbe7x22 < 6; _0xfbe7x22++) {
      _0xfbe7x69[_0xbbc5[300]](
        PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[299] + _0xfbe7x22][_0xbbc5[67]]
      );
    }
    _0xfbe7x69[_0xbbc5[300]](
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[301]][_0xbbc5[67]]
    );
    this[_0xbbc5[249]] = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[302]][_0xbbc5[67]]
    );
    this[_0xbbc5[249]][_0xbbc5[6]][_0xbbc5[5]] = 0.5;
    this[_0xbbc5[249]][_0xbbc5[6]][_0xbbc5[7]] = 0.5;
    this[_0xbbc5[249]][_0xbbc5[303]] = 0;
    this[_0xbbc5[225]][_0xbbc5[224]](this._playerHitArea);
    this[_0xbbc5[251]] = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[304]][_0xbbc5[67]]
    );
    this[_0xbbc5[251]][_0xbbc5[5]] = _0xfbe7x3f * 0.65;
    this[_0xbbc5[251]][_0xbbc5[7]] = _0xfbe7x40 * 0.8;
    this[_0xbbc5[225]][_0xbbc5[305]](this._marine, 2);
    this[_0xbbc5[250]] = new Shark(_0xfbe7x69);
    this[_0xbbc5[225]][_0xbbc5[224]](this._player);
    this[_0xbbc5[250]][_0xbbc5[5]] = 300;
    this[_0xbbc5[250]][_0xbbc5[7]] = 200;
    this[_0xbbc5[250]][_0xbbc5[281]] = false;
    this[_0xbbc5[250]][_0xbbc5[306]] = 0.2;
    this[_0xbbc5[250]][_0xbbc5[34]] = 0.2;
    this[_0xbbc5[225]][_0xbbc5[227]] = true;
    this[_0xbbc5[248]] = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[307]][_0xbbc5[67]]
    );
    this[_0xbbc5[248]][_0xbbc5[6]][_0xbbc5[5]] = 0.5;
    this[_0xbbc5[248]][_0xbbc5[6]][_0xbbc5[7]] = 0.5;
    this[_0xbbc5[248]][_0xbbc5[303]] = 0;
    this[_0xbbc5[225]][_0xbbc5[224]](this._bodyHitArea);
    _0xfbe7x46 = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[308]][_0xbbc5[67]]
    );
    _0xfbe7x46[_0xbbc5[309]] = false;
    _0xfbe7x46[_0xbbc5[6]][_0xbbc5[310]](0.5);
    _0xfbe7x46[_0xbbc5[5]] = _0xfbe7x3f / 2;
    _0xfbe7x46[_0xbbc5[7]] = _0xfbe7x40 / 2.5;
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x46);
    var _0xfbe7x6a = PIXI[_0xbbc5[41]][_0xbbc5[40]];
    _0xfbe7x6a[_0xbbc5[311]] = false;
    _0xfbe7x6a[_0xbbc5[312]]();
    _0xfbe7x6a[_0xbbc5[39]](this[_0xbbc5[237]], this);
    _0xfbe7x49();
    this[_0xbbc5[313]]();
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[288]] = function () {
    var _0xfbe7x6b = document[_0xbbc5[295]](_0xbbc5[294]);
    let _0xfbe7x6c = 0;
    let _0xfbe7x6d = 0;
    var _0xfbe7x6e = window[_0xbbc5[314]] / _0xfbe7x3f;
    var _0xfbe7x6f = window[_0xbbc5[315]] / _0xfbe7x40;
    var _0xfbe7x70 = 0;
    var _0xfbe7x71 = 0;
    if (_0xfbe7x6e < _0xfbe7x6f) {
      _0xfbe7x70 = _0xfbe7x3f * _0xfbe7x6e;
      _0xfbe7x71 = _0xfbe7x40 * _0xfbe7x6e;
      _0xfbe7x6b[_0xbbc5[51]][_0xbbc5[60]] = _0xfbe7x70 + _0xbbc5[316];
      _0xfbe7x6b[_0xbbc5[51]][_0xbbc5[61]] = _0xfbe7x71 + _0xbbc5[316];
    } else {
      _0xfbe7x70 = _0xfbe7x3f * _0xfbe7x6f;
      _0xfbe7x71 = _0xfbe7x40 * _0xfbe7x6f;
      _0xfbe7x6c = (window[_0xbbc5[314]] - _0xfbe7x70) / _0xfbe7x6f;
      _0xfbe7x3f += _0xfbe7x6c;
      _0xfbe7x6b[_0xbbc5[51]][_0xbbc5[60]] = _0xbbc5[292];
      _0xfbe7x6b[_0xbbc5[51]][_0xbbc5[61]] = _0xbbc5[292];
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[313]] = function () {
    this[_0xbbc5[225]][_0xbbc5[236]](
      _0xbbc5[317],
      this[_0xbbc5[318]][_0xbbc5[283]](this)
    );
    this[_0xbbc5[225]][_0xbbc5[236]](
      _0xbbc5[319],
      this[_0xbbc5[320]][_0xbbc5[283]](this)
    );
    this[_0xbbc5[225]][_0xbbc5[236]](_0xbbc5[229], function () {
      if (!_0xfbe7x47) {
        _0xfbe7x47 = true;
        _0xfbe7x46[_0xbbc5[309]] = false;
      }
    });
    this[_0xbbc5[225]][_0xbbc5[236]](_0xbbc5[234], function (_0xfbe7x63) {
      if (!_0xfbe7x47) {
        _0xfbe7x47 = true;
        _0xfbe7x46[_0xbbc5[309]] = false;
      }
      _0xfbe7x48[_0xbbc5[5]] =
        _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[5]];
      _0xfbe7x48[_0xbbc5[7]] =
        _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[7]];
    });
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[318]] = function (_0xfbe7x63) {
    if (!_0xfbe7x47) {
      return;
    }
    let _0xfbe7x72 = {
      x: this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]],
      y: this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[7]],
    };
    _0xfbe7x72[_0xbbc5[5]] +=
      _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[5]] -
      _0xfbe7x48[_0xbbc5[5]];
    _0xfbe7x72[_0xbbc5[7]] +=
      _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[7]] -
      _0xfbe7x48[_0xbbc5[7]];
    if (
      _0xfbe7x72[_0xbbc5[5]] > 0 &&
      _0xfbe7x72[_0xbbc5[5]] < _0xfbe7x3f &&
      _0xfbe7x72[_0xbbc5[7]] > 0 &&
      _0xfbe7x72[_0xbbc5[7]] < _0xfbe7x40
    ) {
      this[_0xbbc5[322]](_0xfbe7x72[_0xbbc5[5]], _0xfbe7x72[_0xbbc5[7]]);
    }
    _0xfbe7x48[_0xbbc5[5]] = _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[5]];
    _0xfbe7x48[_0xbbc5[7]] = _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]][_0xbbc5[7]];
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[320]] = function (_0xfbe7x63) {
    if (!_0xfbe7x47) {
      return;
    }
    var _0xfbe7x73 = _0xfbe7x63[_0xbbc5[71]][_0xbbc5[321]];
    if (
      _0xfbe7x73[_0xbbc5[5]] > 0 &&
      _0xfbe7x73[_0xbbc5[5]] < _0xfbe7x3f &&
      _0xfbe7x73[_0xbbc5[7]] > 0 &&
      _0xfbe7x73[_0xbbc5[7]] < _0xfbe7x40
    ) {
      this[_0xbbc5[322]](_0xfbe7x73[_0xbbc5[5]], _0xfbe7x73[_0xbbc5[7]]);
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[323]] = function (_0xfbe7x74, _0xfbe7x75) {
    this[_0xbbc5[262]][_0xbbc5[324]]();
    this[_0xbbc5[246]] =
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]] - _0xfbe7x74 * _0xfbe7x3f;
    this[_0xbbc5[247]] =
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[7]] - _0xfbe7x75 * _0xfbe7x40;
    if (!this[_0xbbc5[268]]) {
      this[_0xbbc5[268]] = true;
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[325]] = function (_0xfbe7x74, _0xfbe7x75) {
    var _0xfbe7x76 = _0xfbe7x74 * _0xfbe7x3f + this[_0xbbc5[246]];
    var _0xfbe7x77 = _0xfbe7x75 * _0xfbe7x40 + this[_0xbbc5[247]];
    if (_0xfbe7x76 > _0xfbe7x3f) {
      _0xfbe7x76 = _0xfbe7x3f;
    } else {
      if (_0xfbe7x76 < 0) {
        _0xfbe7x76 = 0;
      }
    }
    if (_0xfbe7x77 > _0xfbe7x40) {
      _0xfbe7x77 = _0xfbe7x40;
    } else {
      if (_0xfbe7x77 < 0) {
        _0xfbe7x77 = 0;
      }
    }
    this[_0xbbc5[322]](_0xfbe7x76, _0xfbe7x77);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[322]] = function (_0xfbe7x76, _0xfbe7x77) {
    if (!this[_0xbbc5[241]] && !this[_0xbbc5[240]] && this[_0xbbc5[256]]) {
      this[_0xbbc5[326]]();
    }
    if (this[_0xbbc5[241]]) {
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]] = _0xfbe7x76;
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[7]] = _0xfbe7x77;
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[209]] = function () {
    _0xfbe7x43 = true;
    if (!_0xfbe7x45) {
      _0xfbe7x58();
    }
    this[_0xbbc5[238]] = _0xbbc5[327];
    this[_0xbbc5[328]] = 10;
    this[_0xbbc5[240]] = false;
    this[_0xbbc5[256]] = true;
    this[_0xbbc5[257]] = 0;
    this[_0xbbc5[329]]();
    this[_0xbbc5[260]] = 0;
    this[_0xbbc5[250]][_0xbbc5[5]] = this[_0xbbc5[250]][_0xbbc5[30]][
      _0xbbc5[5]
    ] = _0xfbe7x3f / 2.1;
    this[_0xbbc5[250]][_0xbbc5[7]] = this[_0xbbc5[250]][_0xbbc5[30]][
      _0xbbc5[7]
    ] = _0xfbe7x40 / 3;
    this[_0xbbc5[250]][_0xbbc5[31]]();
    this[_0xbbc5[250]][_0xbbc5[34]] = 0.2;
    this[_0xbbc5[250]][_0xbbc5[17]] = 0.2;
    this[_0xbbc5[250]][_0xbbc5[309]] = true;
    this[_0xbbc5[249]][_0xbbc5[5]] = this[_0xbbc5[248]][_0xbbc5[5]] = this[
      _0xbbc5[250]
    ][_0xbbc5[5]];
    this[_0xbbc5[249]][_0xbbc5[7]] = this[_0xbbc5[248]][_0xbbc5[7]] = this[
      _0xbbc5[250]
    ][_0xbbc5[7]];
    this[_0xbbc5[249]][_0xbbc5[43]][_0xbbc5[5]] = this[_0xbbc5[248]][
      _0xbbc5[43]
    ][_0xbbc5[5]] = this[_0xbbc5[250]][_0xbbc5[43]][_0xbbc5[5]];
    this[_0xbbc5[249]][_0xbbc5[43]][_0xbbc5[7]] = this[_0xbbc5[248]][
      _0xbbc5[43]
    ][_0xbbc5[7]] = this[_0xbbc5[250]][_0xbbc5[43]][_0xbbc5[7]];
    this[_0xbbc5[246]] = 0;
    this[_0xbbc5[247]] = 0;
    this[_0xbbc5[251]][_0xbbc5[5]] = _0xfbe7x3f * 0.77;
    this[_0xbbc5[251]][_0xbbc5[7]] = _0xfbe7x40 * 0.72;
    this[_0xbbc5[251]][_0xbbc5[44]] = 1;
    this[_0xbbc5[251]][_0xbbc5[20]] = 0;
    this[_0xbbc5[330]](this._pool);
    this[_0xbbc5[330]](this._bubbles);
    this[_0xbbc5[330]](this._shadows);
    this[_0xbbc5[252]] = [];
    this[_0xbbc5[253]] = [];
    this[_0xbbc5[254]] = [];
    this[_0xbbc5[255]] = [];
    this[_0xbbc5[265]] = 5;
    this[_0xbbc5[266]] = 0;
    this[_0xbbc5[242]] = 0;
    this[_0xbbc5[267]] = 30 + Math[_0xbbc5[331]]() * 40;
    this[_0xbbc5[264]][_0xbbc5[332]](0);
    this[_0xbbc5[243]][_0xbbc5[333]](this._stage);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[231]] = function () {
    _0xfbe7x47 = false;
    _0xfbe7x46[_0xbbc5[309]] = true;
    this[_0xbbc5[256]] = true;
    this[_0xbbc5[250]][_0xbbc5[5]] = this[_0xbbc5[250]][_0xbbc5[30]][
      _0xbbc5[5]
    ] = _0xfbe7x3f / 2.1;
    this[_0xbbc5[250]][_0xbbc5[7]] = this[_0xbbc5[250]][_0xbbc5[30]][
      _0xbbc5[7]
    ] = _0xfbe7x40 / 3;
    this[_0xbbc5[250]][_0xbbc5[309]] = true;
    this[_0xbbc5[330]](this._pool);
    this[_0xbbc5[252]] = [];
    this[_0xbbc5[264]][_0xbbc5[332]](0);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[326]] = function () {
    this[_0xbbc5[238]] = _0xbbc5[334];
    console[_0xbbc5[212]](">>>",_0xbbc5[335]);
    this[_0xbbc5[336]]();
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[220]] = function () {
    this[_0xbbc5[337]]();
    gamee[_0xbbc5[338]]();
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[210]] = function () {
    _0xfbe7x57(this._score);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[329]] = function () {
    if (this[_0xbbc5[257]] < 30) {
      this[_0xbbc5[258]] = 50;
      this[_0xbbc5[259]] = 0;
    } else {
      if (this[_0xbbc5[257]] < 60) {
        this[_0xbbc5[258]] = 35;
        this[_0xbbc5[259]] = 10;
      } else {
        if (this[_0xbbc5[257]] < 90) {
          this[_0xbbc5[258]] = 25;
          this[_0xbbc5[259]] = 10;
        } else {
          if (this[_0xbbc5[257]] < 120) {
            this[_0xbbc5[258]] = 20;
            this[_0xbbc5[259]] = 20;
          } else {
            if (this[_0xbbc5[257]] < 150) {
              this[_0xbbc5[258]] = 15;
              this[_0xbbc5[259]] = 20;
            } else {
              this[_0xbbc5[258]] = 10;
              this[_0xbbc5[259]] = 30;
            }
          }
        }
      }
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[339]] = function () {
    var _0xfbe7x78 =
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[7]] -
      this[_0xbbc5[250]][_0xbbc5[7]];
    var _0xfbe7x79 =
      this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]] -
      this[_0xbbc5[250]][_0xbbc5[5]];
    if (_0xfbe7x78 == 0 && _0xfbe7x79 == 0) {
      this[_0xbbc5[266]]++;
    } else {
      if (
        this[_0xbbc5[250]][_0xbbc5[5]] <
        this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]]
      ) {
        this[_0xbbc5[250]][_0xbbc5[44]] = -1;
      } else {
        if (
          this[_0xbbc5[250]][_0xbbc5[5]] >
          this[_0xbbc5[250]][_0xbbc5[30]][_0xbbc5[5]]
        ) {
          this[_0xbbc5[250]][_0xbbc5[44]] = 1;
        }
      }
      if (
        Math[_0xbbc5[340]](_0xfbe7x78 * _0xfbe7x78 + _0xfbe7x79 * _0xfbe7x79) <
        this[_0xbbc5[328]]
      ) {
        this[_0xbbc5[250]][_0xbbc5[5]] = this[_0xbbc5[250]][_0xbbc5[30]][
          _0xbbc5[5]
        ];
        this[_0xbbc5[250]][_0xbbc5[7]] = this[_0xbbc5[250]][_0xbbc5[30]][
          _0xbbc5[7]
        ];
      } else {
        var _0xfbe7x7a = Math[_0xbbc5[341]](_0xfbe7x78, _0xfbe7x79);
        this[_0xbbc5[250]][_0xbbc5[5]] +=
          Math[_0xbbc5[342]](_0xfbe7x7a) * this[_0xbbc5[328]];
        this[_0xbbc5[250]][_0xbbc5[7]] +=
          Math[_0xbbc5[46]](_0xfbe7x7a) * this[_0xbbc5[328]];
      }
      this[_0xbbc5[249]][_0xbbc5[5]] = this[_0xbbc5[248]][_0xbbc5[5]] = this[
        _0xbbc5[250]
      ][_0xbbc5[5]];
      this[_0xbbc5[249]][_0xbbc5[7]] = this[_0xbbc5[248]][_0xbbc5[7]] = this[
        _0xbbc5[250]
      ][_0xbbc5[7]];
      this[_0xbbc5[249]][_0xbbc5[43]][_0xbbc5[5]] = this[_0xbbc5[248]][
        _0xbbc5[43]
      ][_0xbbc5[5]] = this[_0xbbc5[250]][_0xbbc5[43]][_0xbbc5[5]];
      this[_0xbbc5[249]][_0xbbc5[43]][_0xbbc5[7]] = this[_0xbbc5[248]][
        _0xbbc5[43]
      ][_0xbbc5[7]] = this[_0xbbc5[250]][_0xbbc5[43]][_0xbbc5[7]];
      if (this[_0xbbc5[266]] > 30) {
        if (!this[_0xbbc5[268]]) {
          this[_0xbbc5[262]][_0xbbc5[324]]();
        }
        this[_0xbbc5[343]](
          this[_0xbbc5[250]][_0xbbc5[5]] + this[_0xbbc5[250]][_0xbbc5[60]] / 2,
          this[_0xbbc5[250]][_0xbbc5[7]] - 75,
          3,
          this[_0xbbc5[250]][_0xbbc5[34]] + 0.2
        );
      }
      this[_0xbbc5[266]] = 0;
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[344]] = function () {
    var _0xfbe7x7b = this[_0xbbc5[253]][_0xbbc5[345]](0);
    for (
      var _0xfbe7x22 = 0;
      _0xfbe7x22 < this[_0xbbc5[253]][_0xbbc5[73]];
      _0xfbe7x22++
    ) {
      _0xfbe7x7b[_0xfbe7x22][_0xbbc5[7]] -= 2;
      _0xfbe7x7b[_0xfbe7x22][_0xbbc5[303]] -= 0.005;
      if (_0xfbe7x7b[_0xfbe7x22][_0xbbc5[7]] < 0) {
        this[_0xbbc5[253]][_0xbbc5[347]](
          this[_0xbbc5[253]][_0xbbc5[346]](_0xfbe7x7b[_0xfbe7x22]),
          1
        );
        this[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x7b[_0xfbe7x22]);
      }
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[348]] = function () {
    this[_0xbbc5[251]][_0xbbc5[20]] += 0.01;
    this[_0xbbc5[251]][_0xbbc5[7]] -=
      Math[_0xbbc5[46]](this[_0xbbc5[251]][_0xbbc5[20]]) / 5;
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[349]] = function () {
    for (
      var _0xfbe7x22 = 0;
      _0xfbe7x22 < this[_0xbbc5[254]][_0xbbc5[73]];
      _0xfbe7x22++
    ) {
      var _0xfbe7x7c = this[_0xbbc5[254]][_0xfbe7x22];
      _0xfbe7x7c[_0xbbc5[5]] -= 0.7 * _0xfbe7x7c[_0xbbc5[43]][_0xbbc5[5]];
      if (
        _0xfbe7x7c[_0xbbc5[5]] < -280 ||
        _0xfbe7x7c[_0xbbc5[5]] >
          _0xfbe7x3f + Math[_0xbbc5[81]](_0xfbe7x7c[_0xbbc5[60]])
      ) {
        this[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x7c);
        this[_0xbbc5[254]][_0xbbc5[347]](_0xfbe7x22, 1);
      }
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[350]] = function () {
    var _0xfbe7x2f = (500 - this[_0xbbc5[250]][_0xbbc5[7]]) / 2;
    this[_0xbbc5[245]][_0xbbc5[7]] =
      _0xfbe7x2f > 0 ? _0xfbe7x40 + _0xfbe7x2f / 10 : _0xfbe7x40;
    this[_0xbbc5[244]][_0xbbc5[7]] =
      _0xfbe7x2f > 0 ? _0xfbe7x40 + _0xfbe7x2f / 5 : _0xfbe7x40;
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[237]] = function (_0xfbe7x66) {
    if (this[_0xbbc5[256]] && _0xfbe7x47) {
      this[_0xbbc5[339]]();
      this[_0xbbc5[344]]();
      this[_0xbbc5[348]]();
      this[_0xbbc5[350]]();
      this[_0xbbc5[349]]();
      var _0xfbe7x7b = this[_0xbbc5[252]][_0xbbc5[345]](0);
      for (
        var _0xfbe7x22 = 0;
        _0xfbe7x22 < _0xfbe7x7b[_0xbbc5[73]];
        _0xfbe7x22++
      ) {
        var _0xfbe7x7c = _0xfbe7x7b[_0xfbe7x22];
        var _0xfbe7x7d = _0xfbe7x7c[_0xbbc5[18]] * _0xfbe7x7c[_0xbbc5[44]];
        if (_0xfbe7x7c[_0xbbc5[15]] == _0xbbc5[351]) {
          _0xfbe7x7c[_0xbbc5[7]] += _0xfbe7x7d;
          if (
            (_0xfbe7x7c[_0xbbc5[7]] > _0xfbe7x40 + _0xfbe7x7c[_0xbbc5[61]] &&
              _0xfbe7x7c[_0xbbc5[44]] == 1) ||
            (_0xfbe7x7c[_0xbbc5[7]] < -196 && _0xfbe7x7c[_0xbbc5[44]] != 1)
          ) {
            this[_0xbbc5[352]](_0xfbe7x7c);
            continue;
          }
        } else {
          _0xfbe7x7c[_0xbbc5[5]] += _0xfbe7x7d;
          _0xfbe7x7c[_0xbbc5[7]] =
            _0xfbe7x7c[_0xbbc5[19]] +
            50 * Math[_0xbbc5[46]](_0xfbe7x7c[_0xbbc5[20]]);
          _0xfbe7x7c[_0xbbc5[20]] += 0.02;
          if (
            (_0xfbe7x7c[_0xbbc5[5]] >
              _0xfbe7x3f + Math[_0xbbc5[81]](_0xfbe7x7c[_0xbbc5[60]]) &&
              _0xfbe7x7c[_0xbbc5[44]] == 1) ||
            (_0xfbe7x7c[_0xbbc5[5]] < -196 && _0xfbe7x7c[_0xbbc5[44]] != 1)
          ) {
            this[_0xbbc5[352]](_0xfbe7x7c);
            continue;
          }
        }
        if (
          _0xfbe7x7c[_0xbbc5[353]] &&
          _0xfbe7x7c[_0xbbc5[17]] <= this[_0xbbc5[250]][_0xbbc5[17]]
        ) {
          _0xfbe7x7c[_0xbbc5[353]][_0xbbc5[309]] = false;
        }
        if (colisions[_0xbbc5[64]](_0xfbe7x7c, this._bodyHitArea)) {
          if (_0xfbe7x7c[_0xbbc5[17]] > this[_0xbbc5[250]][_0xbbc5[17]]) {
            this[_0xbbc5[263]][_0xbbc5[324]]();
            this[_0xbbc5[256]] = false;
            this[_0xbbc5[242]] = 0;
            setTimeout(function () {
              _0xfbe7x5d();
            }, 1000);
          } else {
            if (colisions[_0xbbc5[64]](_0xfbe7x7c, this._playerHitArea)) {
              this[_0xbbc5[261]][_0xbbc5[324]]();
              this[_0xbbc5[352]](_0xfbe7x7c);
              var _0xfbe7x7e =
                _0xfbe7x7c[_0xbbc5[17]] /
                (this[_0xbbc5[250]][_0xbbc5[17]] * 70);
              if (this[_0xbbc5[250]][_0xbbc5[17]] < 0.8) {
                this[_0xbbc5[250]][_0xbbc5[17]] += _0xfbe7x7e;
              }
              this[_0xbbc5[250]][_0xbbc5[354]](1);
              this[_0xbbc5[250]][_0xbbc5[35]]();
              this[_0xbbc5[328]] = 10 - 7 * this[_0xbbc5[250]][_0xbbc5[17]];
              this[_0xbbc5[257]] += _0xfbe7x7c[_0xbbc5[355]];
              this[_0xbbc5[329]]();
              this[_0xbbc5[210]]();
            }
          }
        }
      }
      this[_0xbbc5[267]]--;
      if (this[_0xbbc5[267]] < 0) {
        if (this[_0xbbc5[265]] > 0) {
          this[_0xbbc5[265]]--;
        }
        this[_0xbbc5[267]] = 25 + Math[_0xbbc5[331]]() * 40;
        this[_0xbbc5[356]]();
      }
    } else {
      if (this[_0xbbc5[242]] < 50 && this[_0xbbc5[242]] % 10 == 0) {
        this[_0xbbc5[250]][_0xbbc5[309]] = !this[_0xbbc5[250]][_0xbbc5[309]];
      } else {
        this[_0xbbc5[250]][_0xbbc5[309]] = true;
      }
    }
    this[_0xbbc5[242]]++;
    if (this[_0xbbc5[242]] == 100) {
      this[_0xbbc5[242]] = 0;
    }
    var _0xfbe7x7f = this;
    this[_0xbbc5[243]][_0xbbc5[333]](this._stage);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[352]] = function (_0xfbe7x7c) {
    var _0xfbe7x80 = this[_0xbbc5[252]][_0xbbc5[346]](_0xfbe7x7c);
    if (_0xfbe7x80 > -1) {
      this[_0xbbc5[252]][_0xbbc5[347]](_0xfbe7x80, 1);
      this[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x7c);
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[343]] = function (
    _0xfbe7x81,
    _0xfbe7x82,
    _0xfbe7x83,
    _0xfbe7xe
  ) {
    var _0xfbe7x84 = Math[_0xbbc5[357]](Math[_0xbbc5[331]]());
    for (var _0xfbe7x22 = 0; _0xfbe7x22 < _0xfbe7x83; _0xfbe7x22++) {
      var _0xfbe7x85 = new PIXI.Sprite(
        PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[358]][_0xbbc5[67]]
      );
      _0xfbe7x85[_0xbbc5[5]] = _0xfbe7x81 - 10 + Math[_0xbbc5[331]]() * 20;
      _0xfbe7x85[_0xbbc5[7]] = _0xfbe7x82 + 25 * (_0xfbe7x22 + 1);
      _0xfbe7x85[_0xbbc5[43]][_0xbbc5[5]] = _0xfbe7x85[_0xbbc5[43]][
        _0xbbc5[7]
      ] = _0xfbe7xe - 0.15 * _0xfbe7x22;
      if (_0xfbe7x84) {
        this[_0xbbc5[225]][_0xbbc5[305]](_0xfbe7x85, 2);
      } else {
        this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x85);
      }
      this[_0xbbc5[253]][_0xbbc5[300]](_0xfbe7x85);
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[356]] = function () {
    if (Math[_0xbbc5[331]]() > 0.4) {
      this[_0xbbc5[343]](
        Math[_0xbbc5[331]]() * _0xfbe7x3f,
        _0xfbe7x40 + Math[_0xbbc5[331]]() * 100,
        1 + Math[_0xbbc5[359]](Math[_0xbbc5[331]]() * 4),
        1
      );
    }
    var _0xfbe7x86 = Math[_0xbbc5[331]]() * 100;
    if (this[_0xbbc5[254]][_0xbbc5[73]] < 1 && _0xfbe7x86 > 0.9) {
      this[_0xbbc5[360]]();
    }
    if (_0xfbe7x86 < this[_0xbbc5[259]]) {
      if (_0xfbe7x86 < this[_0xbbc5[259]] / 2) {
        this[_0xbbc5[361]]();
      } else {
        this[_0xbbc5[362]]();
      }
    } else {
      if (
        _0xfbe7x86 <
        this[_0xbbc5[259]] + this[_0xbbc5[258]] + this[_0xbbc5[260]]
      ) {
        if (this[_0xbbc5[260]] > 0) {
          this[_0xbbc5[260]] = 0;
        } else {
          this[_0xbbc5[260]] -= 5;
        }
        this[_0xbbc5[363]]();
      } else {
        if (this[_0xbbc5[260]] < 0) {
          this[_0xbbc5[260]] = 0;
        } else {
          this[_0xbbc5[260]] += 5;
        }
        this[_0xbbc5[364]]();
      }
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[360]] = function () {
    var _0xfbe7x87 = new PIXI.Sprite(
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[365]][_0xbbc5[67]]
    );
    var _0xfbe7x86 = Math[_0xbbc5[331]]();
    if (_0xfbe7x86 > 0.5) {
      _0xfbe7x87[_0xbbc5[5]] = _0xfbe7x3f + _0xfbe7x87[_0xbbc5[60]];
    } else {
      _0xfbe7x87[_0xbbc5[5]] = -100;
      _0xfbe7x87[_0xbbc5[43]][_0xbbc5[5]] = -1;
    }
    _0xfbe7x87[_0xbbc5[7]] = _0xfbe7x40 / 2 + _0xfbe7x86 * 100;
    this[_0xbbc5[225]][_0xbbc5[305]](_0xfbe7x87, 2);
    this[_0xbbc5[254]][_0xbbc5[300]](_0xfbe7x87);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[366]] = function () {
    var _0xfbe7x80 = 0;
    for (
      var _0xfbe7x22 = 0;
      _0xfbe7x22 < init[_0xbbc5[367]][_0xbbc5[73]];
      _0xfbe7x22++
    ) {
      if (
        init[_0xbbc5[367]][_0xfbe7x22][_0xbbc5[17]] <
        this[_0xbbc5[250]][_0xbbc5[17]]
      ) {
        _0xfbe7x80++;
      } else {
        break;
      }
    }
    return _0xfbe7x80;
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[363]] = function () {
    var _0xfbe7x88 = this[_0xbbc5[366]]();
    var _0xfbe7x86 = this[_0xbbc5[368]](_0xfbe7x88);
    var _0xfbe7x89 =
      PIXI[_0xbbc5[223]][_0xbbc5[222]][
        init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[369]]
      ][_0xbbc5[67]];
    var _0xfbe7x8a = new Fish(_0xfbe7x89);
    _0xfbe7x8a[_0xbbc5[18]] = 1 + this[_0xbbc5[368]](3);
    _0xfbe7x8a[_0xbbc5[15]] = _0xbbc5[370];
    _0xfbe7x8a[_0xbbc5[7]] = this[_0xbbc5[368]](
      this[_0xbbc5[270]] - _0xfbe7x89[_0xbbc5[61]]
    );
    _0xfbe7x8a[_0xbbc5[17]] = init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[17]];
    _0xfbe7x8a[_0xbbc5[355]] = _0xfbe7x86 + 1;
    _0xfbe7x8a[_0xbbc5[20]] = 0;
    _0xfbe7x8a[_0xbbc5[19]] = _0xfbe7x8a[_0xbbc5[7]];
    if (init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[353]]) {
      var _0xfbe7x8b = new PIXI.Sprite(
        PIXI[_0xbbc5[223]][_0xbbc5[222]][
          init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[353]]
        ][_0xbbc5[67]]
      );
      _0xfbe7x8b[_0xbbc5[6]][_0xbbc5[310]](0.5);
      _0xfbe7x8a[_0xbbc5[224]](_0xfbe7x8b);
      _0xfbe7x8a[_0xbbc5[353]] = _0xfbe7x8b;
    }
    if (this[_0xbbc5[368]](2)) {
      _0xfbe7x8a[_0xbbc5[5]] = -300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = -1;
      _0xfbe7x8a[_0xbbc5[44]] = 1;
    } else {
      _0xfbe7x8a[_0xbbc5[5]] = _0xfbe7x3f + 300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = 1;
      _0xfbe7x8a[_0xbbc5[44]] = -1;
    }
    this[_0xbbc5[252]][_0xbbc5[300]](_0xfbe7x8a);
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x8a);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[364]] = function () {
    var _0xfbe7x88 = this[_0xbbc5[366]]();
    var _0xfbe7x8c = init[_0xbbc5[367]][_0xbbc5[73]] - 1 - _0xfbe7x88;
    if (_0xfbe7x8c > 5) {
      _0xfbe7x8c = 5;
    }
    var _0xfbe7x86 = Math[_0xbbc5[357]](
      _0xfbe7x88 + Math[_0xbbc5[331]]() * _0xfbe7x8c
    );
    var _0xfbe7x89 =
      PIXI[_0xbbc5[223]][_0xbbc5[222]][
        init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[369]]
      ][_0xbbc5[67]];
    var _0xfbe7x8a = new Fish(_0xfbe7x89);
    _0xfbe7x8a[_0xbbc5[18]] = 1 + this[_0xbbc5[368]](3);
    _0xfbe7x8a[_0xbbc5[15]] = _0xbbc5[370];
    _0xfbe7x8a[_0xbbc5[7]] = this[_0xbbc5[368]](
      this[_0xbbc5[270]] - _0xfbe7x89[_0xbbc5[61]]
    );
    _0xfbe7x8a[_0xbbc5[17]] = init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[17]];
    _0xfbe7x8a[_0xbbc5[355]] = _0xfbe7x86;
    _0xfbe7x8a[_0xbbc5[20]] = 0;
    _0xfbe7x8a[_0xbbc5[19]] = _0xfbe7x8a[_0xbbc5[7]];
    if (init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[353]]) {
      var _0xfbe7x8b = new PIXI.Sprite(
        PIXI[_0xbbc5[223]][_0xbbc5[222]][
          init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[353]]
        ][_0xbbc5[67]]
      );
      _0xfbe7x8b[_0xbbc5[6]][_0xbbc5[310]](0.5);
      _0xfbe7x8a[_0xbbc5[224]](_0xfbe7x8b);
      _0xfbe7x8a[_0xbbc5[353]] = _0xfbe7x8b;
    }
    if (this[_0xbbc5[368]](2)) {
      _0xfbe7x8a[_0xbbc5[5]] = -300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = -1;
      _0xfbe7x8a[_0xbbc5[44]] = 1;
    } else {
      _0xfbe7x8a[_0xbbc5[5]] = _0xfbe7x3f + 300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = 1;
      _0xfbe7x8a[_0xbbc5[44]] = -1;
    }
    this[_0xbbc5[252]][_0xbbc5[300]](_0xfbe7x8a);
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x8a);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[361]] = function () {
    var _0xfbe7x86 = 21;
    var _0xfbe7x89 =
      PIXI[_0xbbc5[223]][_0xbbc5[222]][
        init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[369]]
      ][_0xbbc5[67]];
    var _0xfbe7x8a = new Fish(_0xfbe7x89);
    _0xfbe7x8a[_0xbbc5[18]] = 1 + this[_0xbbc5[368]](3);
    _0xfbe7x8a[_0xbbc5[15]] = _0xbbc5[370];
    _0xfbe7x8a[_0xbbc5[7]] = this[_0xbbc5[368]](
      this[_0xbbc5[270]] - _0xfbe7x89[_0xbbc5[61]]
    );
    _0xfbe7x8a[_0xbbc5[17]] = init[_0xbbc5[367]][_0xfbe7x86][_0xbbc5[17]];
    _0xfbe7x8a[_0xbbc5[20]] = 0;
    _0xfbe7x8a[_0xbbc5[19]] = _0xfbe7x8a[_0xbbc5[7]];
    if (this[_0xbbc5[368]](2)) {
      _0xfbe7x8a[_0xbbc5[5]] = -300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = -1;
      _0xfbe7x8a[_0xbbc5[44]] = 1;
    } else {
      _0xfbe7x8a[_0xbbc5[5]] = _0xfbe7x3f + 300;
      _0xfbe7x8a[_0xbbc5[43]][_0xbbc5[5]] = 1;
      _0xfbe7x8a[_0xbbc5[44]] = -1;
    }
    this[_0xbbc5[252]][_0xbbc5[300]](_0xfbe7x8a);
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x8a);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[362]] = function () {
    var _0xfbe7x89 =
      PIXI[_0xbbc5[223]][_0xbbc5[222]][_0xbbc5[371]][_0xbbc5[67]];
    var _0xfbe7x8a = new Fish(_0xfbe7x89);
    _0xfbe7x8a[_0xbbc5[18]] = 1 + this[_0xbbc5[368]](3);
    _0xfbe7x8a[_0xbbc5[15]] = _0xbbc5[351];
    _0xfbe7x8a[_0xbbc5[5]] = this[_0xbbc5[368]](
      _0xfbe7x3f - _0xfbe7x89[_0xbbc5[60]]
    );
    _0xfbe7x8a[_0xbbc5[17]] = 9999;
    _0xfbe7x8a[_0xbbc5[20]] = 0;
    _0xfbe7x8a[_0xbbc5[19]] = _0xfbe7x8a[_0xbbc5[5]];
    _0xfbe7x8a[_0xbbc5[7]] = _0xfbe7x40 + 300;
    _0xfbe7x8a[_0xbbc5[44]] = -1;
    this[_0xbbc5[252]][_0xbbc5[300]](_0xfbe7x8a);
    this[_0xbbc5[225]][_0xbbc5[224]](_0xfbe7x8a);
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[330]] = function (_0xfbe7x7b) {
    if (_0xfbe7x7b) {
      while (_0xfbe7x7b[_0xbbc5[73]] > 0) {
        try {
          this[_0xbbc5[225]][_0xbbc5[230]](_0xfbe7x7b[_0xbbc5[372]]());
        } catch (err) {
          console[_0xbbc5[212]](err, _0xbbc5[373]);
        }
      }
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[368]] = function (_0xfbe7x9) {
    return Math[_0xbbc5[357]](Math[_0xbbc5[331]]() * (_0xfbe7x9 - 1));
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[336]] = function () {
    if (!this[_0xbbc5[241]]) {
      this[_0xbbc5[241]] = true;
      PIXI[_0xbbc5[41]][_0xbbc5[40]][_0xbbc5[207]]();
      this[_0xbbc5[264]][_0xbbc5[324]]();
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[337]] = function () {
    if (this[_0xbbc5[241]]) {
      this[_0xbbc5[241]] = false;
      PIXI[_0xbbc5[41]][_0xbbc5[40]][_0xbbc5[312]]();
      this[_0xbbc5[264]][_0xbbc5[194]]();
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[284]] = function (_0xfbe7x8d, _0xfbe7x8e) {
    this[_0xbbc5[238]] = _0xbbc5[374];
    this[_0xbbc5[286]]();
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[194]] = function () {
    if (!this[_0xbbc5[240]]) {
      this[_0xbbc5[240]] = true;
      this[_0xbbc5[337]]();
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[197]] = function () {
    if (this[_0xbbc5[240]]) {
      this[_0xbbc5[240]] = false;
      this[_0xbbc5[326]]();
    }
  };
  _0xfbe7x67[_0xbbc5[3]][_0xbbc5[375]] = function () {
    this[_0xbbc5[209]]();
  };
  return _0xfbe7x67;
})();
var game;
window[_0xbbc5[376]] = function () {
  game = new Game();
};
