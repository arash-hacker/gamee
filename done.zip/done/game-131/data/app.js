/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
eval(
  (function () {
    var v = [
      86,
      66,
      72,
      82,
      80,
      76,
      94,
      71,
      90,
      85,
      70,
      89,
      81,
      79,
      65,
      88,
      87,
      60,
      75,
      74,
    ];
    var q = [];
    for (var x = 0; x < v.length; x++) q[v[x]] = x + 1;
    var p = [];
    for (var z = 0; z < arguments.length; z++) {
      var h = arguments[z].split("~");
      for (var t = h.length - 1; t >= 0; t--) {
        var u = null;
        var r = h[t];
        var c = null;
        var f = 0;
        var a = r.length;
        var o;
        for (var b = 0; b < a; b++) {
          var k = r.charCodeAt(b);
          var y = q[k];
          if (y) {
            u = (y - 1) * 94 + r.charCodeAt(b + 1) - 32;
            o = b;
            b++;
          } else if (k == 96) {
            u =
              94 * (v.length - 32 + r.charCodeAt(b + 1)) +
              r.charCodeAt(b + 2) -
              32;
            o = b;
            b += 2;
          } else {
            continue;
          }
          if (c == null) c = [];
          if (o > f) c.push(r.substring(f, o));
          c.push(h[u + 1]);
          f = b + 1;
        }
        if (c != null) {
          if (f < a) c.push(r.substring(f));
          h[t] = c.join("");
        }
      }
      p.push(h[0]);
    }
    var d = p.join("");
    var n = "abcdefghijklmnopqrstuvwxyz";
    var w = [96, 92, 42, 39, 10, 126].concat(v);
    var i = String.fromCharCode(64);
    for (var x = 0; x < w.length; x++)
      d = d.split(i + n.charAt(x)).join(String.fromCharCode(w[x]));
    return d.split(i + "!").join(i);
  })(
    'var _$_1bd9=["VQe","C@uN@g@uS","Math @wVSVQ","VY_wVShttp://jojo.net/?utm_source=html5VV&utm_medium=link&utm_campaign=VY-wVSundefineVXtypeVJee-unknown","location","parent","referrer","href","jojo.net","index@tf","@VWingVJee-mobile","@hasic","VU","text","resume","gVC","sVZ","now","InVQ","InVR,"androiVXdevice","i@tSVJeVR,"showVR,"menuManager","gVCeVXcorrect@jesult","get@jandom@kroblem","stop","width","to","tween","adVXchainedVT","x","center@v","worlVXrandom","+50","None","@lineVSEasing","-100","-50","+100","chain","isVD","VMCrop","DeadVJe@tverVJeEndedVRVIV-=ImV$9[0]VIVV= new V09[3]](640,640,V09[1]],VB2],{init:init,preVW:preVW,create:create})VOaldaEngine= new @uldaEngine(VV,V-,VB4])VKwINV@=2VKwIN_M@u@vV@=0.01VKl@t@tSEV@=4VKuD_@p@j@l=VB5VI@n@uME_T@r@kE=( typeof $VVeNative!V=6])?$VVeNativeV?7]]:VB8VIurl=(windowV?9]]!=windowV?1V49]])?documenV911]]:documenV99V612]VIDIS@k@l@u@r_@uD=urlV?14]](VB13])=== -1VKnameState={@VWing:0,InMenu:1,InVQ:2,Dead:3}VOprogress@harVOproV1VOVYTextVOVUTextVOV+,V:nVOV7=0VOcVH=-1VOVF=-1VOVM@kaused=falseVOV>V*[15]VIVWTime=0VOon@jesVZCalled=falseVOcanSVZVQ=(@n@uME_T@r@kE=V=16])||(V-=V^V$9[17]])VOVYManager;function sVZVQ(){V 18]]=0V\\V-=V^V$9[17V[VUTexV919]]=V 18]]};VF=10;cVH=VF;V 20VPV 21VPV"[22VPV7=DateV?23VPV>V*[24]]V<check@nVCVLV>==V*[25]]&&VWTime!==0&&(canSVZVQ||V327V626]]||V327V628]])){V 31V630]](VB29]);return true};return falseV<buttonDown1VLcheck@nVC()||cVH@x=0||!V"[32]]VE}V\\V"[33V[@VNelse {N@VN;V"[34V/buttonDown2VLcheck@nVC()||cVH@x=0||!V"[32]]VE}V\\!V"[33V[@VNelse {N@VN;V"[34V/@t@y(VA+=@wINV@;VF+=@wIN_M@u@vV@V8>VFVA=VF};V 18]]++V\\V-=V^V$9[17V[VUTexV919]]=V 18]]};V%pV&V+V;VGV+=V5V!proV1)V;7]]({width:(cVH/VF)@cV336]]},150)V?22V/N@t@y(VA-=@l@t@tSEV@V8@x0VA=0};V%pV&V+V;VGV+=V5V!proV1)V;7]]({width:(cVH/VF)@cV336]]},150)V?22VPif( typeof V:n!V=6]){V%V:n)){cV#35V_};V%cV#40]])){cV#4V435V_};V%cV#4V440]])){cV#4V44V435V_}};VYTexV941]]=V343V642]VIbm,bnV\\MathV?44V_@x0.5){V:V2V!mV.V(45V\'V,V);bm=V5V!mV.V(49]},50,V09[48V6V);bV2V!mV.V(45V\'V,V)}else {V:V2V!mV.V(50V\'V,V);bm=V5V!mV.V(51]},50,V09[48V6V);bV2V!mV.V(50V\'V,V)};cV#52]](bm);bmV?52]](bn);cV#22V/isVTVD(blVE ( typeof bl!V=6])&&blV?53]]V<VMV]VL!isVTVD(pV&proV1V;6]]=(cVH/VF)@cV336]]};progress@harV?54V/time@ppdateVLVM@kausedVE};switch(VVState){case V*[24]]:var bo=DateV?23VPcVH-=(bo-V7)/1000V8@x0VA=0};VM@har()V8@x=0){if(!isVTVD(pV&die()}};V7=bo;break}V<die(){V>V*[55]];V 56VPV"[56VPif(V-!V^V$9[0V[V 31V630]](VB57])}}~aldaEngineV?~[39V638]](~VYManager[_$_1bd9~ameraTweenV?~plementation[_$_1bd~if(isTweenVD(~rogress@harVT)){~]},25,@khaser[_$_1b~9[37]]({x:VB~47V646]])~VQState[_$_1bd9~progress@harVT~d9[48V6~@h@pI@lD_T@r@kE~athText)[_$_1bd~]]()V<~@khaser[_$_1bd~gressV]@ject~n=V5~V5[~0V6~VV[_$_1bd9~]]V?~last@ppdate~;if(cVH~tV?~cameraTwee~V?3~}function ~==VB~VVState=~[VB~_SEC@tNDS~){cVH~_$_1bd9[~ameSVZ~@junning~){return~maxTime~5V_};~urTime~]VO~","gam~VO@~(){if(~update~t@y()}~;var ~V_;~@name~Menu"~ar","~Tween~score~game~load~d","~math~tart~]]){~;if(~@har~==Im~]]()'
  )
);
